//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for HUB subsystem of Maradona project
// Dec 22, 2012: initial

//************************************************************

#ifndef MY_HUB_H
#define  MY_HUB_H

#include "stm32f10x.h"
#include "msgcodes.h"
#include "window.h"

//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//event message structure
typedef struct _EMSG
{
	PWND Wnd;		//pointer to window structure
	u32 Type;		//event type code
	u16 ValueX;		//argument
	u16 ValueY;		//argument
	u32 Timestamp;	//event timestamp
}HUB_MSG, *PHUB_MSG;

typedef void (*TIMERPROC)(void);
typedef void (*UARTPROC)(u8);

//PROTOTYPES
u32 HUB_Init();
void HUB_Exit();

// EVENT INPUT FUNCTIONS
//put Touch event to buffer
void HUB_putTouchEvent(u8 type, s16 x, s16 y);
//put dbg event data to hub buffer
void HUB_putDbgEvent(u8 ch);
//put GPS event data to hub buffer
void HUB_putGpsEvent(u8 ch);
//put time 1s event
void HUB_putTime1sEvent(void);
//put alarm event
void HUB_putAlarmEvent(void);
//put Power event data here
void HUB_putPowerEvent(u32 powerState);
//put USB event data here
void HUB_putUsbEvent();

//APP EVENT HANDLER FUNCTIONS
//set timer 1ms handler address or null here
//if set null, handler not used in app and not called by system
void  APIEXPORT HUB_SetTimer1msHandler(TIMERPROC addr);
void  APIEXPORT HUB_SetGpsEventHandler(UARTPROC addr);
void  APIEXPORT HUB_SetDbgEventHandler(UARTPROC addr);

//EVENT QUEUE PROCESSING FUNCTION
//process all event data from systick context
void HUB_SystickProcessEvents(void);
//event processing enable
void HUB_EnableEventProcessing();
void HUB_DisableEventProcessing();
//return state of event processing
u32 HUB_IsEventProcessing();
//********* APPLICATION ACCESS TO QUEUE FUNCTION ***************
//NT-call window handler
u32 APIEXPORT HUB_SendMessage(PWND pWnd, u32 Msg, u32 paramX, u32 paramY);
//NT-create msg and add to queue
//return true if success; return false if any error
//disable interrupts on msg insert time
//wnd=pointer to window structure
//msgCode=message code value
//valX=message X value
//valY=message Y value
u32  APIEXPORT HUB_PostMessage(PWND wnd, u32 msgCode, u32 valX, u32 valY);

//NT-get message from queue
//return 1 if success; return 0 if no messages found
//disable interrupts on msg remove time
//pMsg=pointer to Msg structure
//pWnd=pointer to Wnd structure
//msgFilterMin=min msg code value for search
//msgFilterMax=max msg code value for search
//removeMsg=remove from queue flag 0=not remove;!0=remove;
u32 HUB_PeekMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax, u32 removeMsg);

//NT-get new message from message queue, sleep if no message.
//return 1 if message not Quit; 0 if it is Quit message
//pMsg=pointer to Msg structure
//pWnd=pointer to Wnd structure
//msgFilterMin=min msg code value for search
//msgFilterMax=max msg code value for search
u32  APIEXPORT HUB_GetMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax);

//NT-send message to application window handler for execution
//return value returned by window handler
u32  APIEXPORT HUB_DispatchMessage(PHUB_MSG pMsg);

void inline HUB_setActiveWindow(PWND pWnd);
PWND inline HUB_getActiveWindow();

//print queue content to host
void HUB_DebugOutQueue();

#endif // MY_HUB_H