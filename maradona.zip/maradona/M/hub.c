/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for HUB subsystem of Maradona project
// Dec 22, 2012: initial


***********************************************************/

//INCLUDES
#include "ram_.h"
#include "hub.h"
#include "touch_.h"
#include "debugTerm.h"


//DEFINES
#define HUB_DBG_EVENT_BUFFER_SIZE	16 //or 32 or 64
#define HUB_GPS_EVENT_BUFFER_SIZE	16 //or 32 or 64

typedef struct tagHUB_MsgListItem
{
	u16 relRight;		//relative address of right element in list
	u16 relLeft;		 //relative address of left element in list
//msg struct data
	PWND Wnd;		//pointer to window structure
	u32 Type;		//event type code
	u16 ValueX;		//argument
	u16 ValueY;		//argument
	u32 Timestamp;	//event timestamp
}HUB_MsgListItem, *PHUB_MsgListItem;


//PRIVATE FUNCTIONS
u32 HUB_PutToQueue(u32 wnd, u32 msgCode, u16 valX, u16 valY);
void HUB_CheckQueueItems();

//GLOBAL VARIABLES
//rearrange variables for size optimising 
//DBG event
u8 HUB_DbgEventBuffer[16];
u8 HUB_DbgEventWritePos;
u8 HUB_DbgEventReadPos;
//GPS event
u8 HUB_GpsEventWritePos;
u8 HUB_GpsEventReadPos;
u8 HUB_GpsEventBuffer[16];
//message queue header
RAM_ListItem HUB_EventQueueHdr;
//app timer 1ms handler
TIMERPROC	HUB_timer1msHandler; //todo: check code here 
UARTPROC HUB_uartGpsHandler; //todo: check code here 
UARTPROC HUB_uartDbgHandler; //todo: check code here 
//POWER and TIME flags
u8 HUB_PowerTimeEventFlags;
//TOUCH
u8 HUB_TouchEventType;//click event mode
s16 HUB_TouchCoordX;  //can be u8 (0..239), portrait raw coords
s16 HUB_TouchCoordY; //portrait raw coords
u8 HUB_EnableMessages; //Control queue: 1=add messages to queue, 0=skip adding
PWND HUB_ActiveWindow;	//window receive events
//FUNCTION BODY
//***************** INITIALIZE FUNCTIONS **************************
u32 HUB_Init()
{
	//init variables
	HUB_DbgEventReadPos = 0;
	HUB_DbgEventWritePos = 0;
	HUB_GpsEventReadPos = 0;
	HUB_GpsEventWritePos = 0;
	HUB_PowerTimeEventFlags = 0;
	HUB_timer1msHandler = 0;
	HUB_uartGpsHandler = 0;  
	HUB_uartDbgHandler = 0; 
	HUB_TouchEventType = 0;
	HUB_TouchCoordX = 0;
	HUB_TouchCoordY = 0;
    //������������� ������ ������� ��������� ���������, �� ��������� ����� ��� ��� ����������������.
	HUB_EnableMessages = 0;
	//������������� �������� ���� = 0.
	HUB_ActiveWindow = 0;
	//init msg queue
	RAM_ListInit(&HUB_EventQueueHdr);
	//do other inits

	//add some initiation here
	return 0;
}

void HUB_Exit()
{
	//TODO: Add code here... 
}
//***************** EVENT INPUT FUNCTIONS *********************
//put Touch event to buffer
void HUB_putTouchEvent(u8 type, s16 x, s16 y)
{
	HUB_TouchEventType = type;
	HUB_TouchCoordX = x;
	HUB_TouchCoordY = y;
	return;
}

//put dbg event data to hub buffer
void HUB_putDbgEvent(u8 ch)
{
	//if aplication event handler is set and msg delivery enabled, call it 
	if((HUB_uartDbgHandler != 0) && HUB_EnableMessages)
		HUB_uartDbgHandler(ch);
	else 
    {
        //write event data to queue
        HUB_DbgEventBuffer[HUB_DbgEventWritePos] = ch;
        HUB_DbgEventWritePos++;
        //if writepos > 15, writepos = 0;
        HUB_DbgEventWritePos &= HUB_DBG_EVENT_BUFFER_SIZE - 1; //&= 15
	}
	return;
}


//put GPS event data to hub buffer
void HUB_putGpsEvent(u8 ch)
{
	
    //if aplication event handler is set and msg delivery enabled, call it 
	if((HUB_uartGpsHandler != 0) && HUB_EnableMessages)
		HUB_uartGpsHandler(ch);
	else 
    {
        //write event data
        HUB_GpsEventBuffer[HUB_GpsEventWritePos] = ch;
        HUB_GpsEventWritePos++;
        //if writepos > 15, writepos = 0;
        HUB_GpsEventWritePos &= HUB_GPS_EVENT_BUFFER_SIZE - 1; //&= 15
    }
	return;
}


#define HUB_TIME1S_EVENT_FLAG_MASK  128
#define HUB_ALARM_EVENT_FLAG_MASK	 64
//put time 1s event
void HUB_putTime1sEvent(void)
{
	//set bit 7
	HUB_PowerTimeEventFlags |= HUB_TIME1S_EVENT_FLAG_MASK;//set flag here	
}
//put alarm event
void HUB_putAlarmEvent(void)
{
	//set bit 6
	HUB_PowerTimeEventFlags |= HUB_ALARM_EVENT_FLAG_MASK;//set flag here 
}

//put Power event data here
void HUB_putPowerEvent(u32 powerState)
{
	DBG_addStackInfo(); //TODO: STACK info collect
    //set bits 0..5 as power event flags
	HUB_PowerTimeEventFlags |= powerState;
	//bits 6 7 used as time alarm flags  
}

//put USB event data here
void HUB_putUsbEvent()
{
 //TODO: Add code here... 
}
//***************** ACTIVE WINDOW  *******************************************
void inline HUB_setActiveWindow(PWND pWnd)
{	
	HUB_ActiveWindow = pWnd;
}

PWND inline HUB_getActiveWindow()
{
	return HUB_ActiveWindow;
}

//***************** APPLICATION HANDLER FUNCTIONS ****************************
//set timer 1ms handler address or null here
//if set null, handler not used in app and not called by system

void HUB_SetTimer1msHandler(TIMERPROC addr)
{
	HUB_timer1msHandler = addr;
}
void HUB_SetGpsEventHandler(UARTPROC addr)
{
	HUB_uartGpsHandler = addr;
}
void HUB_SetDbgEventHandler(UARTPROC addr)
{
	HUB_uartDbgHandler = addr;
}

//********* EVENT QUEUE PROCESSING FUNCTION **********************
//NT-process all event data from systick context
void HUB_SystickProcessEvents(void)
{
	//process message queue size and content check
	u32 t1;
    //DBG_setFlag(0); //first step
	//���� ������� �������, ���� �� ���������
	t1 = RAM_ListGetLength(&HUB_EventQueueHdr);
	if(t1 >= 128) //128=4��
		HUB_CheckQueueItems();
    //DBG_setFlag(1); 
	//process touch event
    if(HUB_TouchEventType != TouchEvent_None) //use eventtype as flag for new events
    {
        //get clicked item
        //DBG_setFlag(2);
        t1 = TOUCH_DetectClickedItem(HUB_TouchCoordX, HUB_TouchCoordY);
        //form message number as (item 3bit + clicktype 2 bit)
        t1 = (t1 << 2) | (u32)HUB_TouchEventType;
        //translate coords if display is landscape
        //DBG_setFlag(3);
        TOUCH_TranslateClickCoords(&HUB_TouchCoordX, &HUB_TouchCoordY);
        //t1 contains message type, coords ready to put in queue
        //DBG_setFlag(4);
        if(HUB_EnableMessages)
            HUB_PostMessage(HUB_ActiveWindow, t1,  (u16)HUB_TouchCoordX, (u16)HUB_TouchCoordY);
        HUB_TouchEventType = TouchEvent_None; //clear event flag
    }
	//DBG_setFlag(5); 
	//process power event
	if(HUB_PowerTimeEventFlags != 0) //if events exists
	{
		if(HUB_EnableMessages)
		{
			//process power event - select bits 0-5
			//DBG_setFlag(6);
            t1 = HUB_PowerTimeEventFlags & 63;
			if(t1 != 0)	//if we have events
			{
				HUB_PostMessage(HUB_ActiveWindow, MSG_POWER_EVENT, (u16)t1, 0);				
			}
            //DBG_setFlag(7);
			//process time event
			if(HUB_PowerTimeEventFlags & HUB_TIME1S_EVENT_FLAG_MASK)
			{
				HUB_PostMessage(HUB_ActiveWindow, MSG_TIME_1S_EVENT, 0, 0);
			}
            //DBG_setFlag(8);
			//process alarm event
			if(HUB_PowerTimeEventFlags & HUB_ALARM_EVENT_FLAG_MASK)
			{
				HUB_PostMessage(HUB_ActiveWindow, MSG_TIME_ALARM_EVENT, 0, 0);				
			}
		}
		HUB_PowerTimeEventFlags = 0; //clear all flags
	}

	//process USB event
	//DBG_setFlag(9);
	//process GPS event
	//if something has been written
	while(HUB_GpsEventReadPos != HUB_GpsEventWritePos)
	{
		t1 = (u32)(HUB_GpsEventBuffer[HUB_GpsEventReadPos]);
		HUB_GpsEventReadPos++;
		HUB_GpsEventReadPos &= HUB_GPS_EVENT_BUFFER_SIZE - 1; //&= 15;
        //DBG_setFlag(10);
        if(HUB_EnableMessages)
			HUB_PostMessage(HUB_ActiveWindow, MSG_GPS_CHAR_EVENT, (u16) t1, 0);
	}
    //DBG_setFlag(11);
	//process DBG events
	while(HUB_DbgEventReadPos != HUB_DbgEventWritePos)
	{
		t1 = (u32)(HUB_DbgEventBuffer[HUB_DbgEventReadPos]);
		HUB_DbgEventReadPos++;
		HUB_DbgEventReadPos &= HUB_DBG_EVENT_BUFFER_SIZE - 1; //&= 15;
        //DBG_setFlag(12);
        if(HUB_EnableMessages)
			HUB_PostMessage(HUB_ActiveWindow, MSG_DBGTERM_CHAR_EVENT, (u16) t1, 0);
	}
	//...
	//...
    //DBG_setFlag(13);
	//execute 1mS handler
	if((HUB_timer1msHandler != 0) && HUB_EnableMessages)
		HUB_timer1msHandler();
	//return
	//DBG_setFlag(14);
	return;
}
//event processing enable
void HUB_EnableEventProcessing()
{
	HUB_EnableMessages = 1;
}
void HUB_DisableEventProcessing()
{
	HUB_EnableMessages = 0;
}
//return state of event processing
u32 HUB_IsEventProcessing()
{
	return (u32) HUB_EnableMessages;
}

//NT-walk on queue and remove too old items - simple version
void HUB_CheckQueueItems()
{
	//������ �������
	//���� ������� ��������� ������ ������������� ������, �������� ����������
	//������� / ������� � �������, ����
	//dbg@115200 = 11520
	//dbg@56000 = 5600
	//gps@9600 = 960
	//time1s = 1
	//alarm = 1
	//power = 2
	//touch = 63

	u32 t1, time;
	time = RAM_getTimestamp(); //to avoid use global variable as local by optimiser
	//walk from right to left list item
	PRAM_ListItem pItem, pT;
	PHUB_MsgListItem pMsg;
	PRAM_ListItem pBase = &HUB_EventQueueHdr;
	pItem = pBase;
    //test for reentering
    //DBG_setFlag(15);
	while((pItem = RAM_ListGetBottomRight(pItem)) != pBase)
	{
		//get msg
		pMsg = (PHUB_MsgListItem)pItem;
		//DBG_setFlag(16);
        t1 = time - pMsg->Timestamp;
		//filter messages - if type and time valid, go to next item, else remove item
		//if dbg events older than 10 ms (56max), remove
		if((pMsg->Type == MSG_DBGTERM_CHAR_EVENT) && (t1 < 10))
		{
			continue;
		}
		//if gps events older than 50 ms (48max), remove
		if((pMsg->Type == MSG_GPS_CHAR_EVENT) && (t1 < 50))
		{
			continue;
		}
		//if touch move events older than 200 ms (12max), remove
		//if touch up-down events older than 100ms, remove
		if(pMsg->Type < MSG_TOUCHSCREEN_INVALID_UP + 1)
		{
			if(t1 < 200)	continue;
		}
		//if power event older than 500 ms (5 max), remove
		if((pMsg->Type == MSG_POWER_EVENT) && (t1 < 500))
		{
			continue;
		}
		//if time event older than 1000ms, remove
		if((pMsg->Type == MSG_TIME_1S_EVENT) && (t1 < 1000))
		{
			continue;
		}
		//if alarm event older than 10000ms,remove
		if((pMsg->Type == MSG_TIME_ALARM_EVENT) && (t1 < 10000))
		{
			continue;
		}
		//for all other types of msg - if older than 10 ms, remove
		if((pMsg->Type > MSG_HARDWARE_EVENT_MAX) && (t1 < 10))
		{
			continue;
		}
		//else remove this listitem
		//DBG_setFlag(17);
        pT = pItem;
		pItem = RAM_ListGetTopLeft(pItem); //move to previous item
		//	DBG_setFlag(18);
        RAM_ListRemoveItem(pBase, pT); //remove from list
		//	DBG_setFlag(19);
        RAM_memFree((u8*)pT); //free list item object
		//go next loop
        //	DBG_setFlag(20);
	}
	//DBG_setFlag(21);
    return;
}


//********* APPLICATION ACCESS TO QUEUE FUNCTION ***************
//NT-call window handler
u32 APIEXPORT HUB_SendMessage(PWND pWnd, u32 Msg, u32 paramX, u32 paramY)
{
	//if it is a window and has message handler, execute handler, return handler result
	//else return 0
	//DBG_printfn((u8*) "wnd=", 4);
	//DBG_printval((u32)pWnd);

	if(pWnd == 0) return 0;
	WNDPROC pfnWndProc = pWnd->pClass->lpfnWndProc;
	//DBG_printfn((u8*) "prc=", 4);
	//DBG_printval((u32)pfnWndProc);
	if(pfnWndProc == 0) return 0;
	return pfnWndProc(pWnd, Msg, (u16)paramX, (u16)paramY);
}

//NT-create msg and add to queue
//return true if success; return false if any error
//disable interrupts on msg insert time
//wnd=pointer to window structure
//msgCode=message code value
//valX=message X value
//valY=message Y value
u32 HUB_PostMessage(PWND wnd, u32 msgCode, u32 valX, u32 valY)
{
	//��������� ���������� �� ������ ����������, ���� ������ ��� ������������ ���������� �������.
	//create msg and add to queue
	//return true if success
	//return false if any error
	PHUB_MsgListItem pli;
	//create msg object
	//������ ���������� �������� � �������, ��� �������� 24 + 4 ���� RAM
	//DBG_setFlag(30); 
    pli = (PHUB_MsgListItem)RAM_memAlloc(sizeof(HUB_MsgListItem), RAM_TAG_HUB);
	if(pli == 0)
		return 0; //error alloc
	//DBG_setFlag(31); 
    //DBG_setFlag((u32)pli); 
    pli->Timestamp = RAM_getTimestamp();
	pli->Type = msgCode;
	pli->Wnd = wnd;
	pli->ValueX = (u16)valX;
	pli->ValueY = (u16)valY;
	//insert new item to tail of queue 
    //	DBG_setFlag(32); 
	__disable_irq();//prevent any interrupt while added
	//	DBG_setFlag(33); 
    RAM_ListInsertLeft(&HUB_EventQueueHdr, &HUB_EventQueueHdr, (PRAM_ListItem)pli);
	//	DBG_setFlag(34); 
    __enable_irq();
    //	DBG_setFlag(35); 
	return 1; //success

}

//NT-get message from queue
//return 1 if success; return 0 if no messages found
//disable interrupts on msg remove time
//pMsg=pointer to Msg structure
//pWnd=pointer to Wnd structure. If ==0, no check Wnd field
//msgFilterMin=min msg code value for search
//msgFilterMax=max msg code value for search
//removeMsg=remove from queue flag 0=not remove;!0=remove;
u32 HUB_PeekMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax, u32 removeMsg)
{
	PRAM_ListItem pNextItem;
	PHUB_MsgListItem pMsgItem;
	//check  if no messages in queue - if no messages, return false
	if(RAM_ListGetLength(&HUB_EventQueueHdr) == 0) return 0;
	//have messages
	pNextItem = &HUB_EventQueueHdr;
	while((pNextItem = RAM_ListGetBottomRight(pNextItem)) != &HUB_EventQueueHdr)
	{
		pMsgItem = (PHUB_MsgListItem)pNextItem;
		if((pWnd != 0)&&(pMsgItem->Wnd != pWnd)) continue;
		if(pMsgItem->Type < msgFilterMin) continue;
		if(pMsgItem->Type > msgFilterMax) continue;
		//else we found msg, copy data
		pMsg->Wnd = pMsgItem->Wnd;
		pMsg->Type = pMsgItem->Type;
		pMsg->ValueX = pMsgItem->ValueX;
		pMsg->ValueY = pMsgItem->ValueY;
		//if remove msg, remove from list and memory
		if(removeMsg > 0)
		{
			__disable_irq();//prevent any interrupt while remove
			RAM_ListRemoveItem(&HUB_EventQueueHdr, pNextItem); //remove from list
			RAM_memFree((u8*)pNextItem); //free list item object
        	__enable_irq();
		}
		return 1; //true
	}
	return 0;  //false
}

//NT-get new message from message queue, sleep if no message.
//return 1 if message not Quit; 0 if it is Quit message
//pMsg=pointer to Msg structure
//pWnd=pointer to Wnd structure. If ==0, no check Wnd field
//msgFilterMin=min msg code value for search
//msgFilterMax=max msg code value for search
u32 HUB_GetMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax)
{

	while(!HUB_PeekMessage(pMsg, pWnd, msgFilterMin, msgFilterMax, 1)) //get msg with removing
	{
		//sleep processor
		__ISB();//instruction barrier
		__WFE();//wait for events

	}
	if(pMsg->Type != MSG_QUIT) return 1; else return 0;
}

//NT-send message to application window handler for execution
//return value returned by window handler
u32 HUB_DispatchMessage(PHUB_MSG pMsg)
{
	return HUB_SendMessage(pMsg->Wnd, pMsg->Type, pMsg->ValueX, pMsg->ValueY);
}

//print queue content to host
void HUB_DebugOutQueue()
{
	PHUB_MsgListItem pMsg;
    DBG_printfn((u8*)"\r\nCount:", 8);
    DBG_printval(RAM_ListGetLength(&HUB_EventQueueHdr));
    PRAM_ListItem pBase = &HUB_EventQueueHdr;
    PRAM_ListItem pItem = pBase;
	DBG_printfn((u8*)"\r\nHeader:", 9);
	DBG_printval((u32)pBase);
	DBG_printfn((u8*)"L=", 2);
	DBG_printval((u32)RAM_ListGetTopLeft(pBase));
	DBG_printfn((u8*)"R=", 2);
	DBG_printval((u32)RAM_ListGetBottomRight(pBase));
	DBG_printfn((u8*)"\r\n", 2);	
    while((pItem = RAM_ListGetTopLeft(pItem)) != pBase)
    {
		pMsg = (PHUB_MsgListItem) pItem;
		DBG_printfn((u8*)"Item:", 5);
		DBG_printval((u32)pItem);
		DBG_printfn((u8*)"L=", 2);
		DBG_printval((u32)RAM_ListGetTopLeft(pItem));
		DBG_printfn((u8*)"R=", 2);
		DBG_printval((u32)RAM_ListGetBottomRight(pItem));
        DBG_printfn((u8*)"Wnd=", 4);
        DBG_printval((u32) pMsg->Wnd);
        DBG_printfn((u8*)"Tim=", 4);
        DBG_printval((u32) pMsg->Timestamp);       
        DBG_printfn((u8*)"Msg=", 4);
        DBG_printval((u32) pMsg->Type);
        DBG_printfn((u8*)"X=", 2);
        DBG_printval((u32) pMsg->ValueX);
        DBG_printfn((u8*)"Y=", 2);
        DBG_printval((u32) pMsg->ValueY);
		DBG_printfn((u8*)"\r\n", 2);
    }
    DBG_printfn((u8*)"\r\nEnd\r\n", 7);
}