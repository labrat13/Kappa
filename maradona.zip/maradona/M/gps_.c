/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "gps_.h"
#include "debugTerm.h" //for debug only

//pins
//PB10 tx
//PB11 rx
//PE2 pp_out 1=disable
//FUNCTIONS

//NT-���������������� ���������� � ����������� �������.
void  APIEXPORT GPS_Init()
{
	USART_InitTypeDef USART_InitStructure;
	USART_ClockInitTypeDef usacis;
	GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
	//init usart and pin's
	/* Enable usart3, GPIOA, GPIOD and AFIO clocks */
	//USART3 in APB1 domain
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO, ENABLE);
	//reinit uart for debugging
	//disable uart3 if enabled
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART3, DISABLE);
	USART_Cmd(USART3, DISABLE);

	/* Configure USART3_Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure USART3_Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	//configure PE2 as io pushpull
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	//disable gps (pb2=1)
	GPS_Enable(0);//0=disable

	/* USART1 configuration ------------------------------------------------------*/
	/* USART configured as follow:
	- BaudRate = 9600 baud  
	- Word Length = 8 Bits
	- One Stop Bit
	- No parity
	- Hardware flow control disabled (RTS and CTS signals)
	- Receive and transmit enabled
	*/
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	/* Configure USART1 */
	USART_Init(USART3, &USART_InitStructure);
	//configure clock
	usacis.USART_Clock = USART_Clock_Disable;
	usacis.USART_CPOL = USART_CPOL_Low;
	usacis.USART_CPHA = USART_CPHA_2Edge;
	usacis.USART_LastBit = USART_LastBit_Disable;
	USART_ClockInit(USART3, &usacis);//usart clock init

	//init rx interrupt
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

	/* Enable the USARTx */
	USART_Cmd(USART3, ENABLE);
}
//NT-���������� ���������� � ����������� �������.
void  APIEXPORT GPS_Exit()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	

	//reset and disable uart, free pin's and usart clock
	USART_ITConfig(USART3, USART_IT_RXNE, DISABLE);
	//disable irq channel
	NVIC_DisableIRQ(USART3_IRQn);
	//disable gps module power
	GPS_Enable(0);//0=disable
	//disable uart3 if enabled
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_USART3, DISABLE);
	USART_Cmd(USART3, DISABLE);
	//disable clock
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, DISABLE);
	//free used pin
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	return;
}

//NT-Enable or disable GPS power
void  APIEXPORT GPS_Enable(u32 State)
{
	if(State != 0) //enable
	{
		GPIO_ResetBits(GPIOE, GPIO_Pin_2);
	}
	else
	{
		GPIO_SetBits(GPIOE, GPIO_Pin_2);
	}
	return;
}

//NT-get GPS module power state
//return: 0=disabled, 1=enabled
u32  APIEXPORT GPS_isEnabled()
{
	if(GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_2) == 0)
		return 1; else return 0;
}

//NT-send message string to module with polling 
void  APIEXPORT GPS_SendMsg(u8* msg)
{
	while(*msg != 0)
	{
		/* Write a character to the USART */
		USART_SendData(USART3, (u8) *msg);
		msg++;
		while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET)
		{
		}
	}
	return;
}

////RX interrupt subhandler 
//void GPS_CharEvent(char ch)
//{
//	DBG_putchar(ch); //for test only
//}

