//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for  subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_STRINGS_H
#define  MY_STRINGS_H

#include "stm32f10x.h" //project data types
//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//GLOBAL VARIABLES

//PROTOTYPES


//return position of specified char in string
//return string length if char not exists
//string=ASCII string
//len=length of string
//ch=searched char
u32  APIEXPORT STRINGS_getCharPosition(u8* string, u32 len, u8 ch);

//get length of ASCIIZ string
u32  APIEXPORT STRINGS_strlen(u8* str);

//concatenate two ASCIIZ strings
void  APIEXPORT STRINGS_strcat(u8* dest, u8* src);

//Copy ASCIIZ string
void  APIEXPORT STRINGS_strcpy(u8 * Dest, u8* Src );

//Copy n bytes from second buffer to first. 
//Fill zeroes after s2 ends. Return first buffer.
u8*  APIEXPORT STRINGS_strncpy (u8 *s1, const u8 *s2, u32 n);

//Compare two strings. Return 0 if strings are equal
s32  APIEXPORT STRINGS_strcmp( u8 * s1,  u8 * s2);

//get hex letter from value 0..15
u8 STRINGS_HexChar(u32 val);




#endif // MY_STRINGS_H