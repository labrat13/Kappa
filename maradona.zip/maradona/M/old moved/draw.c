//draw.c - drawing functions

#include "draw.h"

u16 rectGetEndX(LPRECT rc)
{
    return rc->X + rc->Width - 1;
}

u16 rectGetEndY(LPRECT rc)
{
    return rc->Y + rc->Height - 1;
}

void rectSetRect(LPRECT rc, u16 x, u16 y, u16 width, u16 height)
{
    rc->X = x;
    rc->Y = y;
    rc->Width = width;
    rc->Height = height;
}

void rectSetPoint(LPRECT rc, POINT pt)
{
    rc->X = POINT_X(pt);
    rc->Y = POINT_Y(pt);
}

void rectSetSize(LPRECT rc, SIZE sz)
{
    rc->Width = SIZE_W(sz);
    rc->Height = SIZE_H(sz);
}

bool rectPtInRect(LPRECT rc, POINT pt)
{
    u16 x = POINT_X(pt);
    u16 y = POINT_Y(pt);
    return ((x >= rc->X) && (x <= (rc->X + rc->Width - 1)) && (y >= rc->Y) && (y <= (rc->Y + rc->Height - 1)));
}

//Check inner rect in outer rect fully 
bool rectRectInRect(LPRECT rcOuter, LPRECT rcInner)
{
	POINT pt1 = MAKEPOINT(rcInner->X, rcInner->Y);
	POINT pt2 = MAKEPOINT(rectGetEndX(rcInner), rectGetEndY(rcInner));
	return (rectPtInRect(rcOuter, pt1) && rectPtInRect(rcOuter, pt2));
}




//******************* DRAW functions ************************

SIZE drawGetDisplaySize()
{
	SIZE sz;
	if(sysGetFlag(SYSFLAG_DRAWORIENT))
	{
		sz = MAKESIZE(TFT_SIZE_Y, TFT_SIZE_X); //Horiz = 320x240
	}
	else
	{
		sz = MAKESIZE(TFT_SIZE_X, TFT_SIZE_Y); //Vert = 240x320
	}
	return sz;
}

//get rectangle of all dislay
void drawGetDisplayRect(LPRECT rc)
{
	rc->X = 0;
    rc->Y = 0;
	if(sysGetFlag(SYSFLAG_DRAWORIENT))
	{
		rc->Width = TFT_SIZE_Y;
		rc->Height = TFT_SIZE_X; //Horiz = 320x240
	}
	else
	{
		rc->Width = TFT_SIZE_X;
		rc->Height = TFT_SIZE_Y; //Vert = 240x320
	}
}

//set display orientation: 0 = vertical, 1 = horizontal
void drawSetDisplayOrient(u8 orient)
{
	//check global display orient flag
	if(sysGetFlag(SYSFLAG_DRAWORIENT) != orient)
	{
		sysInvertFlag(SYSFLAG_DRAWORIENT); //new orient
		tftSetScanOrder(orient);
	}
}


//draw rect with specified color
void drawRect(
			  u16 x,		//X begin
			  u16 y,		//Y begin
			  u16 width,	//area width 
			  u16 height,	//area height
			  u16 color		//color
			  )
{
	//prepare coords
	u16 xx = x+width - 1;
	u16 yy = height+y - 1;

	//for debug only
	//if(((xx) > DISPLAY_X) || ((yy) > DISPLAY_Y)) throw "Coordinates out of range!";//for debug only
	
	//draw lines
	tftFillRect(x, y, width, 1, color);				//top line
	tftFillRect(x, yy, width, 1, color);			//bottom line
	tftFillRect(x, y, 1, height, color);			//left
	tftFillRect(xx, y, 1, height, color);			//right	
}


//Draw line
void drawLine(
				  u16 x1,	//The x-coordinate of the first line endpoint.
				  u16 y1,	//The y-coordinate of the first line endpoint.
				  u16 x2,	//The x-coordinate of the second line endpoint.
				  u16 y2,	//The y-coordinate of the second line endpoint.
				  u16 color	//Line color
				  )
{
	s16 dx,dy,sdx,sdy,dxabs,dyabs,x,y,px,py;
	u16 i;

#define abs(X) ( ( (X) < 0 ) ? -(X) : (X) )
#define sgn(X) ( ( (X) < 0 ) ? -1 : 1 )

	if ( x1 == x2 )        /* Vertical Line*/
	{
		if ( y1 > y2 )    /* We assume y2>y1 and invert if not*/
		{
			i = y2;
			y2 = y1;
			y1 = i;
		}
		tftFillRect( x1, y1, 1, (y2-y1)+1, color);
		return;
	}
	else if ( y1 == y2 )  /* Horizontal Line*/
	{
		if ( x1 > x2 )   /* We assume x2>x1 and we swap them if not*/
		{
			i = x2;
			x2 = x1;
			x1 = i;
		}
		tftFillRect( x1, y1, (x2-x1)+1, 1, color);
		return;
	}

	dx = x2 - x1;      /* the horizontal distance of the line */
	dy = y2 - y1;      /* the vertical distance of the line */
	dxabs = abs(dx);
	dyabs = abs(dy);
	sdx = sgn(dx);
	sdy = sgn(dy);
	x = dyabs >> 1;
	y = dxabs >> 1;
	px = x1;
	py = y1;

	if (dxabs >= dyabs) /* the line is more horizontal than vertical */
	{
		for(i=0; i < dxabs; i++)
		{
			y+=dyabs;
			if (y>=dxabs)
			{
				y-=dxabs;
				py+=sdy;
			}
			px+=sdx;
			tftSetPixel(px,py,color);
		}
	}
	else /* the line is more vertical than horizontal */
	{
		for(i=0; i < dyabs; i++)
		{
			x+=dxabs;
			if (x>=dyabs)
			{
				x-=dyabs;
				px+=sdx;
			}
			py+=sdy;
			tftSetPixel(px,py,color);
		}
	}
}



void drawFillRect(LPRECT rc, u16 color)
{
	tftFillRect(rc->X, rc->Y, rc->Width, rc->Height, color);
}

//simple draw string w/out check length
void drawString(u8* str,	//string
				u16 len,	//length of string
				u16 X,   //start point of string
                u16 Y,
				u16 color,	//text color
				u16 bgcolor)//back color
{

	while(len)
	{
		tftWriteChar(*str, X, Y, color, bgcolor);
		str++;
		X += CHAR_W;
		len--;
	}
}


























