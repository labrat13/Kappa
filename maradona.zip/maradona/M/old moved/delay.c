#include "stm32f10x.h"
 
//abstraction for all HCLK modes
//generally, OS time system should be used for user application
//this function for OS internal use only
void delay_ms(vu32 ms)
{
    ms = ms * 7500; //~ 1ms for 72mHz
    while(ms > 0)  ms--; //10 HCLK's for 1 step
}
