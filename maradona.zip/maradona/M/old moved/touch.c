
#include "touch.h"

void touchInit()
{
	//Y+ PB1/ADC12_9
	//X+ PB0/ADC12_8

	//clock config

	
    /* ADCCLK = PCLK2/8  = 72/8 = 9MHz*/
  RCC_ADCCLKConfig(RCC_PCLK2_Div8); 

  /* Enable ADC1 and GPIOB/C clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
	//gpio config
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Configure PB0, PB1 as analog input -------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
    //configure PC5 as analog input
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

	//adc config
 /* ADC1 configuration ------------------------------------------------------*/
  ADC_InitTypeDef ADC_InitStructure;

  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;     //Scan group mode
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE; //Single mode
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 3;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* Set injected sequencer length */
  ADC_InjectedSequencerLengthConfig(ADC1, 3);

  /* ADC1  channel configuration */ 
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_239Cycles5); //x+
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_9, 2, ADC_SampleTime_239Cycles5); //y+
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_15, 3, ADC_SampleTime_239Cycles5); //y-

  /* ADC1 injected external trigger configuration */
  ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_None);
  
  /* Enable injected external trigger conversion on ADC1 */
 // ADC_ExternalTrigInjectedConvCmd(ADC1, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);
  ADC_TempSensorVrefintCmd(ENABLE);

  /* Enable ADC1 reset calibration register */   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibaration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
}

//performs click detection. Return 1 if click occured, 0 otherwise.
u8 getConversion(LPADC_TRESULTS lpar)
{
	u16 s = 16;
	u16 t;
	u8 res = 1;
	while(s)
	{
		delay_ms(1);
		ADC_SoftwareStartInjectedConvCmd(ADC1, ENABLE);
		//wait for conversion ends
		while(ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC) == RESET);
		//get and store values
		lpar->TouchX += ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
		t = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
		lpar->TouchY += t;
		if(t > TOUCH_Y_LIMIT) res = 0;
		lpar->TouchT += ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);
		//clear eoc flag
		ADC_ClearFlag(ADC1, ADC_FLAG_JEOC); //NOT cleaned by hardware!
		//now return
        s--;
	}
	//filter values
	lpar->TouchX = lpar->TouchX >> 4;
	lpar->TouchY = lpar->TouchY >> 4;
	lpar->TouchT = lpar->TouchT >> 4;
	return res;
}

void oneConversion(LPADC_TRESULTS lpar)
{
    	ADC_SoftwareStartInjectedConvCmd(ADC1, ENABLE);
		//wait for conversion ends
		while(ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC) == RESET);
		//get and store values
		lpar->TouchX = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
		lpar->TouchY = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
		lpar->TouchT = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);
		//clear eoc flag
		ADC_ClearFlag(ADC1, ADC_FLAG_JEOC); //NOT cleaned by hardware!
}

void resultClear(LPADC_TRESULTS lpar)
{
	lpar->TouchX = 0;
	lpar->TouchY = 0;
	lpar->TouchT = 0;
}


void calcPoint2(LPADC_TRESULTS lpar, u32* pRx, u32* pRy, u32* pRt)
{
    u32 t = 4095 - lpar->TouchY;
	*pRx = (1024 * lpar->TouchX) / t;
	*pRy = (1024 * (lpar->TouchY - lpar->TouchT)) / t;
    *pRt = (1024 * (lpar->TouchT - lpar->TouchX)) / t;
}

