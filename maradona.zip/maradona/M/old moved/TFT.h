//TFT.h - header file for TFT display



#ifndef MY_TFTH
#define MY_TFTH

#ifdef __cplusplus
 extern "C" {
#endif

#include "Font.h" //font table, remap table

//data address = 0x62000000
//cmd address = 0x60000000
#define TFTDATA (u16*) 0x62000000
#define TFTCMD  (u16*) 0x60000000
//some tft commands
#define TFT_NOP     0x00
#define TFT_CASET   0x2A
#define TFT_RASET   0x2B
#define TFT_RAMWR   0x2C
#define TFT_RAMRD   0x2E
#define TFT_COLMOD  0x3A
#define TFT_MADCTL  0x36

//tft size  vertical (default after reset)
#define TFT_SIZE_X 240
#define TFT_SIZE_Y 320


//COLORS
#define tftBLACK	0x0000
#define tftWHITE	0xffff
#define tftRED		63488	//�������
#define tftGREEN	2016	//�������
#define tftBLUE		31		//�����
#define tftYELLOW	65504	//������
#define tftSKY		2047	//�������
#define tftMAGENTA	63519   //����������
#define tftGRAY		33808   //�����
#define tftDGRAY	16904	//�����-�����
#define tftLGRAY	50712	//������-�����


//init tft module at HCLK=72mHz
void tftInitFsmc(void);

// void setTftResetLine()
// void clearTftResetLine()

//disable tft lines
void tftDeinit();

//functions for tft registers reading/writing
inline void tftWriteCmd(u16 val);
inline void tftWriteData(u16 val);
inline u16  tftReadData();

//hard reset tft, need wait for 120 mS min after reset
void tftHardReset();

//tft display initialization
void tftInitDisplay();

//fill all screen with specified color
void tftFillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color);

//send pixels to display (when size is known)
void tftFill(u32 count, u16 color);

//Set rectangle for reading/writing - not used
// void tftSetDrawRect(
// u16 x1, //start column
// u16 y1, //start row
// u16 x2, //end column
// u16 y2); //end row

//set rect for both screen orientations
void tftSetDrawRect2(u16 x, u16 y, u16 w, u16 h);

//read data for already specified rect
//Data from tft comes in rgb666, need convert to rgb565!!!
void tftRead(u16* buf, u16 cnt); //u32?

//write data for already specified rect
void tftWrite(u16* buf, u16 cnt); //u32?

//function draw pixel with specified color
//must be fastest, if used
void tftSetPixel(u16 x, u16 y, u16 color);

//read pixels from specified screen rectangle
void tftReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf);

//write pixels to specified screen rectangle
void tftWriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf); 

u16 pixelRxBG(u16 rx, u16 bg); //helper for tftRead
u16 pixelGRxB(u16 gr, u16 xb); //helper for tftRead
//set new color mode for tft display
void tftSetColorMode(u8 mode);
//set display update order 
void tftSetScanOrder(u8 order);

//Write one char rect
void tftWriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor);




#ifdef __cplusplus
 }
#endif

#endif // MY_TFTH
