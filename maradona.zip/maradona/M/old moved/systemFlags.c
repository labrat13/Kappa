//system flags
#include "systemFlags.h"

void sysSetFlag(u8 flag)
{
	sysFlags = sysFlags | (1 << flag);
}

void sysClearFlag(u8 flag)
{
	sysFlags = sysFlags & (~(1 << flag)); //!!! test it!
}

bool sysGetFlag(u8 flag)
{
	return((sysFlags & (1 << flag)) > 0);
}

void sysInvertFlag(u8 flag)
{
	sysFlags = sysFlags ^ (1 << flag);
}