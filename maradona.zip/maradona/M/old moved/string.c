#include "my_string.h"

	//Get length of ASCIIZ string without ending zero
	//u16 my_strlen(u8* str)
	//{
	//	u16 cnt = 0;
	//	while(*str != 0)
	//	{
	//		cnt++;
	//		str++;
	//	}
	//	return cnt;
	//}
	u16 my_strlen(u8* str)
	{
		u8* s = str;
		while(*s != 0)
			s++;
		//*s = '\0' 
		return s - str;
	}

	//concatenate two strings
	void my_strcat(u8* dest, u8* src)
	{
		//move to end of exists string
		while(*dest != 0) dest++;
		//copy src to dest
		while(*src != 0)
		{
			*dest = *src;
			dest++; src++;
		}
		*dest = 0; //ending zero
	}



//Copy ASCIIZ string
void my_strcpy(u8 * Dest, u8* Src )
{
  while(*Src)
  {
    *Dest++ = *Src++;  
  }
}
//Copy n bytes from second buffer to first. 
//Fill zeroes after s2 ends. Return first buffer.
u8* my_strncpy (u8 *s1, const u8 *s2, u16 n)
{
   while((*s2 != 0) && (n > 0))
   {
      *s1 = *s2;
      s1++; s2++;
      n--;
   }
    //fill zeroes if s2 is ends
    while(n > 0)
    {
       *s1 = 0;
        n--;
    }
   return s1;   
}
//Compare two strings. Return 0 if strings are equal
s8 my_strcmp( u8 * s1,  u8 * s2)
{
   while ((*s1 == *s2) && (*s1 != '\0')) 
   {
      s1++;
      s2++;
   }
   return *s1 - *s2;
}

//************** My printf functions ********************

extern void my_putchar(u8 ch);

//my version of printf without any args
//not tested
void my_printf(u8* str)
{
 
   while(*str != 0)
      {
         my_putchar(*str);
         str++;
      }
}

//my version of printf without any args
//not tested
void my_printfn(s8* str, u8 len)
{
   u8 t = len;
   while(t > 0)
      {
         my_putchar(*str);
         str++;
         t--;
      }
}

void my_printval(u32 val)
{
    u32 i = 1000000000;
    u32 res;
    do
    {
        res = val / i;
        val = val % i;
        res = res + '0';
        my_putchar((u8)res);
        i = i / 10;
    }
    while(i > 1);
    my_putchar((u8)(val + '0'));
}

//u8 hexs[16] = "0123456789ABCDEF";
