//************************************************************
// Copyright (C) 2011 Pavel Selyakov
// String functions for project
// July 30, 2011: initial, not tested

//************************************************************
#ifndef MY_STRINGH
#define MY_STRINGH

#ifdef __cplusplus
 extern "C" {
#endif
 
#include "stm32f10x.h" 
//u8 hexs[16] = "0123456789ABCDEF";

u16 my_strlen(u8* str);//Get length of ASCIIZ string without ending zero
void my_strcat(u8* dest, u8* src);//concatenate two strings
void my_strcpy(u8 * Dest, u8* Src );//Copy ASCIIZ string

//Copy n bytes from second buffer to first. 
//Fill zeroes after s2 ends. Return first buffer.
u8* my_strncpy (u8 *s1, const u8 *s2, u16 n);

//Compare two strings. Return 0 if strings are equal
s8 my_strcmp( u8 * s1,  u8 * s2);

//************** My printf functions ********************
extern void my_putchar(u8 ch);

//my version of printf without any args
//not tested
void my_printf(u8* str);
//my version of printf without any args
//not tested
void my_printfn(s8* str, u8 len);
void my_printval(u32 val);



#ifdef __cplusplus
 }
#endif


#endif //MY_STRINGH

