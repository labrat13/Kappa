//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for POWER subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_POWER_H
#define  MY_POWER_H
//TODO: place header body text here

//DEFINES

//GLOBAL VARIABLES

//PROTOTYPES




#endif // MY_POWER_H