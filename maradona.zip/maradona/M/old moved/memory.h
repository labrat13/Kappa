//************************************************************
// Copyright (C) 2011 Pavel Selyakov
// Memory functions for project
// July 30, 2011: initial

//************************************************************
#ifndef MY_MEMORYH
#define MY_MEMORYH 

//******************* Memory functions *********************** 

	//Zeroes memory
	void memZero(u8* addr, u16 size)
	{
		u8* t = addr + size;
		while(addr < t)
		{
			*addr = 0;
			addr++;
		}
		return;
	}

	//Fill memory
	void memFill(u8* addr, u8 value, u16 size)
	{
		u8* t = addr + size;
		while(addr < t)
		{
			*addr = value;
			addr++;
		}
		return;
	}
	//copy memory block  from src to dest address
	void memCopy(u8* src, u8* dest, u16 size)
	{
		u8* t = src + size;
		while(src < t)
		{
			*dest = *src;
			dest++; src++;
		}
		return;		
	}

//Compare two memory buffers with n bytes.
//Return 0 if equal else return u1-u2
s8 memComp(u8* s1, u8* s2, u16 n)
 {
      u8* t = s1 + n;
	  while(s1 < t)
	  {
         if ( *s1 != *s2)  return (*s1-*s2);
         s1++; s2++;
      }
      return 0;
  }
//******************* Memory allocation functions *********************** 
//heap top and bottom address comes from linker script
extern volatile unsigned long _eusrstack;
extern volatile unsigned long _Stack_Init;

void assert_failed(u8* file, u32 line); //for error reporting 

//Setup heap start and end addresses. Values are volatile.
//You should check real values in linker script
#define MEMTOP		(u32)(((u32)(&_eusrstack)) + 4)	//start of heap, 4 bytes aligned
#define MEMBOTTOM	(u32)(((u32)(&_Stack_Init)) - 4)	//(from linker) begin of stack, end of heap, must be 4 bytes aligned

//define mask for marker state flag
#define ALLOC_USED			0x0001	//bit0 is 1 if block used, 0 for free
#define ALLOC_USED_NMASK	0xfffe	//inverse mask for clear bit0
#define ALLOC_INVALID_FLAG_VALUE 0x0002 //if flag value > limit, marker invalid

//marker for memory blocks
typedef struct _MEMMARKER
{
	u16 Size;	//size of allocated block, in bytes
	u16 flags;
} MEMMARKER, *LPMEMMARKER;

//global variables


/* 
How it work.
Initially only one marker created - at heap begin.
All allocations must be aligned to 4 bytes
Size in markers in dwords, thus minimal allocated 4 byte
When memAlloc() called, it pass trough marker's chain, merge all free blocks.
(Skip free markers and increment overall block size)
If founded free block is bigger than requested size, then
 store it's address and size in temp variables and find next free block until MEMBOTTOM.
If founded free block bigger than requested size but smaller than block stored in temp variable,
 then it's (with size) placed to temp variable.
If founded free block match with requested size, block marked as used and then return.
If MEMBOTTOM is reached, get block from temp variables and create marker at aligned end of block.
If no free blocks, return null.

Optionally, fill allocated memory with value
Optionally, check markers integrity (check flag value and block size)

*/

//initialise allocation 
void initMemAlloc()
{
	//create first marker
	LPMEMMARKER lp = (LPMEMMARKER)(MEMTOP);
	lp->flags = 0;//free block
	lp->Size = (u16)((MEMBOTTOM - sizeof(MEMMARKER) - MEMTOP) / sizeof(MEMMARKER));
}

//get address of next used block in chain
inline LPMEMMARKER getNextUsedBlock(LPMEMMARKER marker)
{
	while((marker < (LPMEMMARKER)(MEMBOTTOM)) && ((marker->flags & ALLOC_USED) == 0))
		marker = marker + marker->Size + 1; 
	return marker;
}


//allocate memory and return 32bit-aligned region 
u8* memAlloc(u16 size)
{
	//size in dwords, aligned
	u16 s = size;
	if((size & 0x03) > 0) s +=4;
	s = s / 4;

	LPMEMMARKER lpn, lpResult, lpNext;

	u16 minSize = 0xFFFF;//max value;
	lpResult = (LPMEMMARKER)0;
    
	lpn = (LPMEMMARKER)(MEMTOP);//init
	while(lpn < (LPMEMMARKER)(MEMBOTTOM))
	{
		if(lpn->flags > ALLOC_INVALID_FLAG_VALUE) //if invalid marker
		{
			//marker is invalid, heap structure invalid, return null or throw exception
            //you can add debug message here
            //throw "Invalid marker!";
            //assert_failed(__FILE__, __LINE__);
            return (u8*)0;
		}
		else
		{
			if((lpn->flags & ALLOC_USED) == 0) //if free block
			{
				lpNext = getNextUsedBlock(lpn);//get size of chain of next free blocks
				lpn->Size = lpNext - lpn - 1;;
				//if it is an appropriate block, then store in lpResult address
				if(lpn->Size >= s)//size match, end search
				{
					if(lpn->Size == s)
					{
						//mark as used and return address;
						lpResult->flags = lpResult->flags | ALLOC_USED;
						return (u8*) (lpResult + 1);
					}
					else //size > s; find minimal block
					{
						if(minSize > lpn->Size) { minSize = lpn->Size; lpResult = lpn; }
					}
				}
			}
			//go to next marker
			lpn = lpn + lpn->Size + 1; 
		}
	}
	//check lpResult and create marker
	if(lpResult == (LPMEMMARKER)0)  return (u8*) 0;//nothing found
	if(lpResult->Size > s + 1) //if free space more than required block + new marker, create new marker
	{
		//create new marker for free space and set sizes for new and used block markers
		lpn = lpResult + s + 1; //get address for new marker
		lpn->flags = 0; //free
		lpn->Size = lpResult->Size - (s + 1); //set size of new free block
		lpResult->Size = s; //set size of new used block
	}
	//mark as used and return address;
	lpResult->flags = lpResult->flags | ALLOC_USED;
	return (u8*) (lpResult + 1);
}

//allocate memory and fill with value. Typical use for debug.
u8* memAllocFill(u16 size, u8 value)
{
	u8* ptr = memAlloc(size);
	if(ptr > 0) memFill(ptr, value, size);
	return ptr;
}


//free memory allocated by memAlloc
void memFree(u8* addr)
{
	LPMEMMARKER lp = (LPMEMMARKER)addr;
	if(addr != (u8*)0)
	{
		lp--;//to marker address
		if(lp->flags > ALLOC_INVALID_FLAG_VALUE) //if invalid marker
		{
			//marker is invalid, heap structure invalid, return null or throw exception
            //you can add debug message here
            //throw "Invalid marker!";
            //assert_failed(__FILE__, __LINE__);
            ;
        }
		else
		{
			lp->flags = lp->flags & ALLOC_USED_NMASK;	//reset USED bit
		}
	}
}

#endif	//MY_MEMORYH