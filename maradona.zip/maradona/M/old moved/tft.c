#include "stm32f10x.h"
#include "tft.h"
#include "systemFlags.h"


void delay_ms(vu32 ms);

//init tft module at HCLK=72mHz
void tftInitFsmc(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
  FSMC_NORSRAMTimingInitTypeDef  read;
  FSMC_NORSRAMTimingInitTypeDef  write;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOG | RCC_APB2Periph_GPIOE, ENABLE);
    /* Enable the FSMC Clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
 /*-- GPIO Configuration ------------------------------------------------------*/ 
/* SRAM Data lines configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 |
                                GPIO_Pin_10 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure); 

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
                                GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | 
                                GPIO_Pin_15;
  GPIO_Init(GPIOE, &GPIO_InitStructure);

  /* SRAM Address lines configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_Init(GPIOG, &GPIO_InitStructure);
     /* NOE and NWE configuration */  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 |GPIO_Pin_5;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  /* NE configuration */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; 
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  
  //reset configuration setup here!!
  //PD3 as manual pushpull
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  // GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
  //set level now
  GPIO_SetBits(GPIOD, GPIO_Pin_3); //resetLine = high
   
/*-- FSMC Configuration ------------------------------------------------------*/
  read.FSMC_AddressSetupTime = 1;  //20ns
  read.FSMC_AddressHoldTime = 1;  //10ns
  read.FSMC_DataSetupTime = 25; //360ns
  read.FSMC_BusTurnAroundDuration = 0; 
  read.FSMC_CLKDivision = 0;       //
  read.FSMC_DataLatency = 0;       //
  read.FSMC_AccessMode = FSMC_AccessMode_A; //modeA
  
  write.FSMC_AddressSetupTime = 1;  //20ns
  write.FSMC_AddressHoldTime = 1;  //10ns
  write.FSMC_DataSetupTime = 2; //50ns
  write.FSMC_BusTurnAroundDuration = 0; 
  write.FSMC_CLKDivision = 0;       //
  write.FSMC_DataLatency = 0;       //
  write.FSMC_AccessMode = FSMC_AccessMode_A; //modeA  
  
  FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
  FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
  FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
  FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
  FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
  FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
  FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
  FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Enable; //
  FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
  FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &read;
  FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &write;

  FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); 

  /* Enable FSMC Bank1_SRAM Bank */
  FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE); 
}

// void setTftResetLine()
// {
	// GPIO_SetBits(GPIOD, GPIO_Pin_3);
// }

// void clearTftResetLine()
// {
	// GPIO_ResetBits(GPIOD, GPIO_Pin_3);
// }

void tftDeinit()
{
//Off LCD power    
//disable all pin's to inputFloating 

}

//
inline void tftWriteCmd(u16 val)
{
    volatile u16* addr = TFTCMD;
    *addr = val;
}

inline void tftWriteData(u16 val)
{
    volatile u16* addr = TFTDATA;
    *addr = val;
}

inline u16 tftReadData()
{
    volatile u16* addr = TFTDATA;
    return *addr;
}

//set new color mode for tft
void tftSetColorMode(u8 mode)
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;
    *cmdaddr = TFT_COLMOD;
	*dataddr = mode; 
}

//hard reset tft, need wait for 120 mS min after reset
inline void tftHardReset()
{
    GPIO_ResetBits(GPIOD, GPIO_Pin_3);
    delay_ms(1);
	GPIO_SetBits(GPIOD, GPIO_Pin_3);
}

//tft display initialization
void tftInitDisplay()
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;

    //reset
    tftHardReset();
    //delay 250 ms (120 min)
    delay_ms(250);
    //sleep out
    *cmdaddr = 0x11; //SLEEP OUT 
    delay_ms(250);
    //set up display
    *cmdaddr = (0xC0); //PWCTR1
    *dataddr = (0x00);
    *cmdaddr = (0xc1); //PWCTR2
    *dataddr = (0xD0);
    *dataddr = (0x01);
    
    //set power in normal full color mode
    *cmdaddr = (0xC2); //PWCTR3
    *dataddr = (0x01);    
    *dataddr = (0xD4);
    *dataddr = (0x85);
    *dataddr = (0x00);
    *dataddr = (0x00);
  //set power control Idle 8color mode 
    *cmdaddr = (0xC3);
    *dataddr = (0x01);
    *dataddr = (0x22);
    *dataddr = (0x00);
    *dataddr = (0x00);
    *dataddr = (0x01); 
    //no power control for Partial mode (PWCTR5 0xc4)! 
    //unknown commands
    *cmdaddr = (0xF4);
    *dataddr = (0xFF);
    *dataddr = (0x3F);
    
    *cmdaddr = (0xF5);
    *dataddr = (0x10);
    //VCOM multimode default, may skip
    *cmdaddr = (0xFB);
    *dataddr = (0x7F);
 //set VCOMH voltage for Normal and Idle mode   
    *cmdaddr = (0xC5);
    *dataddr = (0xB6);
    *dataddr = (0x1A);
 //set VCOMAC voltage in Normal and Idle mode   
    *cmdaddr = (0xC6);
    *dataddr = (0x28);
    *dataddr = (0x00);
 // Idle mode off, Inversion off, Normal mode On (may skip?)   
    *cmdaddr = (0x38);    //IDMOFF
    *cmdaddr = (0x13);    //NORON 
    *cmdaddr = (0x20);    //INVOFF
    
//set frame rate for full-color normal mode
         *cmdaddr = (0xB1);    //FRMCTR1-FRAME RATE CONTROL for the Full color Normal Mode
         *dataddr = (0x3C);   	// 00110000 = 75Hz? ,typical 60Hz@0x3C; max 90Hz@0x28, see datasheet       
         *dataddr = (0x02);   	//  typical         
         *dataddr = (0x02);   	//  typical        
         
//Disable external synchro
         *cmdaddr = (0xBC);    //VSYNCOUT external disable (?)

//Set draw area as display full
         //*cmdaddr = (0x2A);    //  CASET
         //*dataddr = (0x00);   	//        
         //*dataddr = (0x00);   	//  0        
         //*dataddr = (0x00);   	//        
         //*dataddr = (0xEF);   	// 239         
         //*cmdaddr = (0x2B);    // RASET
         //*dataddr = (0x00);   	//        
         //*dataddr = (0x00);   	//  0        
         //*dataddr = (0x01);   	//        
         //*dataddr = (0x3F);   	// 319         

//tearing effect, after reset = 0( may skipped)  
         *cmdaddr = (0x35);    //TEON, Mode 1
         *dataddr = (0x00);   	//default    
//set pixel mode 565
         *cmdaddr = (0x3A);        //COLMOD
         *dataddr = (0x55);       //RGB565 format

//Set scan order
		tftSetScanOrder(0); //vertical orientation
        
                                            
         delay_ms(100);//delay 100 ms ???
        //display on
        *cmdaddr = (0x29); //display_On
}

//fill all screen with specified color
void tftFillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color)
{
    u32 j;

    //set drawing rectangle
    tftSetDrawRect2(x1, y1, width, height);
    //calc pixels count
    j = width * height;
    tftFill(j, color);
}

//send pixels to display (when size is known)
void tftFill(u32 count, u16 color)
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;
    u32 i;

    //send pixels to tft  - (may be to use DMA instead?)
    *cmdaddr = TFT_RAMWR;
    for(i = 0; i < count; i++)
        *dataddr = color;
    *cmdaddr = TFT_NOP; //NOP breaks writing
}

//Set rectangle for reading/writing
// void tftSetDrawRect(
// u16 x1, //start column
// u16 y1, //start row
// u16 x2, //end column
// u16 y2) //end row
// {
    // volatile u16* cmdaddr = TFTCMD;
    // volatile u16* dataddr = TFTDATA;

    
    // *cmdaddr = TFT_CASET;    //  CASET
    // *dataddr = x1 >> 8;   	//        
    // *dataddr = x1 & 0xFF;   	//  0        
    // *dataddr = x2 >> 8;   	//        
    // *dataddr = x2 & 0xFF;   	// 239         
    // *cmdaddr = TFT_RASET;    // RASET
    // *dataddr = y1 >> 8;   	//        
    // *dataddr = y1 & 0xFF;   	//  0        
    // *dataddr = y2 >> 8;   	//        
    // *dataddr = y2 & 0xFF;   	// 319 
// }

////Set rectangle for reading/writing
void tftSetDrawRect2(u16 x, u16 y, u16 w, u16 h)
{
    //all orientations -> X swap Y
    h = y + h - 1; //end point
    w = x + w - 1;

    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;

    *cmdaddr = TFT_CASET;    //  CASET
    *dataddr = y >> 8;   	//        
    *dataddr = y & 0xFF;   	//  0        
    *dataddr = h >> 8;   	//        
    *dataddr = h & 0xFF;   	// 239         
    *cmdaddr = TFT_RASET;    // RASET
    *dataddr = x >> 8;   	//        
    *dataddr = x & 0xFF;   	//  0        
    *dataddr = w >> 8;   	//        
    *dataddr = w & 0xFF;   	// 319 
}

 //helper for tftRead
u16 pixelGRxB(u16 gr, u16 xb)
{
	//gr(15-0) = r5r4r3r2r1r0 0 0 g5g4g3g2g1g0 0 0 
	//xb(15-0) = b5b4b3b2b1b0 0 0 x x x x x x  0 0
	// -------------------------------------------
	//565(15-0)= r4r3r2r1r0g5g4g3 g2g1g0b4b3b2b1b0
	u8 g = (u8) (gr & 0xff);		 //g5g4g3g2g1g000
	u8 b = (u8) ((xb >> 10) & 0x1F); //000b4b3b2b1b0
	u16 res = ((gr >> 2) & 0xFF00);  //00r5r4r3r2r1r0 00000000
	res = (res | g) << 3;			 //r4r3r2r1r0g5g4g3g2g1g0 00000
	res = res | b;					//r4r3r2r1r0g5g4g3g2g1g0b4b3b2b1b0
	return res;
}
 //helper for tftRead
u16 pixelRxBG(u16 rx, u16 bg)
{
	//rx = x x x x x x  0 0 r5r4r3r2r1r0 0 0
	//bg = g5g4g3g2g1g0 0 0 b5b4b3b2b1b0 0 0 
	//--------------------------------------
	//565(15-0)= r4r3r2r1r0g5g4g3 g2g1g0b4b3b2b1b0

	u8 b = (u8)((bg >> 2) & 0x1F);	//000b4b3b2b1b0
	u8 g = (u8)(bg >> 10);			//00g5g4g3g2g1g0
	u16 res = ((rx << 4) | (u16)g); //xx00rrrrrrgggggg
	res = (res << 5) | b;			//rrrrrggggggbbbbb
	return res;
}

//read data for already specified rect
//Data from tft comes in rgb666, need convert to rgb565!!!
void tftRead(u16* buf, u16 cnt) //u32?
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;
	u16 t1, t2;
	
	//change colmod for 18bpp //colmod = 0x66;
    tftSetColorMode(0x66);
    //send cmd for reading
    tftWriteCmd(TFT_RAMRD);
    t1 = *dataddr; //one dummy read

	//read 1.5 word pixels
	while(cnt > 0)
	{
		//read first pixel
		t1 = *dataddr;
		t2 = *dataddr;
		//process and save pixel
		*buf = pixelGRxB(t1, t2);
		cnt--;
		buf++;
		if(cnt > 0)
		{
			t1 = *dataddr; //read second pixel
			cnt--;
			//process and save pixel
			*buf = pixelRxBG(t2, t1);
			buf++;
		}
	}
    tftWriteCmd(TFT_NOP);//break read

	//restore old color mode
    tftSetColorMode(0x55);
}

//write data for already specified rect
void tftWrite(u16* buf, u16 cnt) //u32?
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;

    //send cmd for writing
    *cmdaddr = TFT_RAMWR;
    while(cnt)
    {
         *dataddr = *buf;   
         buf++;
         cnt--;
    }
    *cmdaddr = TFT_NOP;//break read
}

//function draw pixel with specified color
//must be fastest, if used
void tftSetPixel(u16 x, u16 y, u16 color)
{
    volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;

    tftSetDrawRect2(x, y, 1, 1);
    //send cmd for writing
    *cmdaddr = TFT_RAMWR;
    *dataddr = color;
    *cmdaddr = TFT_NOP;
}

//Read pixels from spicified screen rectangle
void tftReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf)
{
    tftSetDrawRect2(x, y, width, height);
    tftRead(buf, width * height);
}

//Write pixels to specified screen rectangle
void tftWriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf)
{
    tftSetDrawRect2(x, y, width, height);
    tftWrite(buf, width * height);
}

//set display update order 
inline void tftSetScanOrder(u8 order)
{
	volatile u16* cmdaddr = TFTCMD;
    volatile u16* dataddr = TFTDATA;

	*cmdaddr = TFT_MADCTL;
	if(order == 0)
	{
		*dataddr = (u16) 32; //MY=1;MX=0;MV=0; vertical
	}
	else
	{
		*dataddr = (u16) 128; //MY=0;MX=0;MV=1; horizontal
	}
}


//get address of u16*7 dotmap for char
//char converted here from ascii code. Do not need (0 - ' ') perform in user application
u16* fontGetChar(u8 ch)
{
    u16* res;
    //char remapping
    if(ch < 32) ch = '?'; //control symbols
    ch = ch - 32;    
    if(ch > 95) ch = remapWin1251[ch - 96]; //for non-ascii symbols #128 - #255
    //get address
    res = fontTable;
    res = res + (ch * 7);
    return res;
}




//Write one char rect
void tftWriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor)
{
    //assume that rect for char drawing already set up
    //simple send pixels to display
    u16* columns;
    u16 val, res;
    u16 i, j;
    volatile u16* dataddr = TFTDATA;

    //get char dotmap
    columns = fontGetChar(ch);
    //set rectangle for one char
    tftSetDrawRect2(X, Y, CHAR_W, CHAR_H);
    //open writing
    tftWriteCmd(TFT_RAMWR);
    //draw 7 columns
    for(i = 0; i < 7; i++)
    {
        val = *columns;
        columns++; //to next column
        *dataddr = bgcolor; //row 1 avoided
        for(j = 0; j < 12; j++)
        {
            res = val & 1;  //get bit
            val = val >> 1; //for next bit
            //put pixel
            if(res > 0) *dataddr = color;
                else *dataddr = bgcolor;
        }
        *dataddr = bgcolor; //row 14 avoided        
    }
    //draw 8-th column (14 rows)
    for(i = 0; i < 14; i++)
    {
        *dataddr = bgcolor;
    }
    //break writing
    tftWriteCmd(TFT_NOP);
}














