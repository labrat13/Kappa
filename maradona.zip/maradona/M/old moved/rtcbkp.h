//**************************************************************
//	rtcbkp.h - header for rtc and backup devices


//**************************************************************
#ifndef MY_RTCBKPH
#define MY_RTCBKPH

#include "stm32f10x.h"

typedef struct
{
	u8 Second;  //0-59
	u8 Minute;  //0-59
	u8 Hour;    //0-23
	u8 Day;		//0-31
	u8 WeekDay; //0-6
	u8 Month;	//0-11
	u16 Year;  //years
} M_DATETIME, *LPM_DATETIME;



//add functions for access/process date
void RTCconfig();
void rtcSetDateTime(LPM_DATETIME lpt);
void rtcGetDateTime(LPM_DATETIME lpt);
u8 rtcIsDateTimeCorrect(LPM_DATETIME lpt);
void rtcDateTimeToString(LPM_DATETIME lpt, u8* buffer, u8 buflen);
u8* rtcGetDayName(u8 day);
u8* rtcGetMonthName(u8 month);



#endif //MY_RTCBKPH
