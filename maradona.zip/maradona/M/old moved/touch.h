//touch.h - touchscreen header file

#ifndef MY_TOUCHH
#define MY_TOUCHH

#include "stm32f10x.h"
#include "types.h"
#include "delay.h"

#ifdef __cplusplus
 extern "C" {
#endif

#define TOUCH_Y_LIMIT 3912 //if Y+ value lower than this limit, click exists
//ADC results
typedef struct
{
	u32 TouchX;		//X+ touchscreen
	u32 TouchY;		//Y+ touchscreen
    u32 TouchT;     //Y- touchscreen
} ADC_TRESULTS, *LPADC_TRESULTS;

void touchInit();
u8 getConversion(LPADC_TRESULTS lpar);
void oneConversion(LPADC_TRESULTS lpar);
void resultClear(LPADC_TRESULTS lpar);
POINT calcPoint(LPADC_TRESULTS lpar);
void calcPoint2(LPADC_TRESULTS lpar, u32* pRx, u32* pRy, u32* pRt);


#ifdef __cplusplus
 }
#endif















#endif // MY_TOUCHH