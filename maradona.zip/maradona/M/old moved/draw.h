//draw.h 

#ifndef MY_DRAWH
#define  MY_DRAWH

#include "stm32f10x.h"
#include "systemFlags.h"
#include "tft.h"
#include "types.h"


typedef struct 
{
    u16 X;
    u16 Y;
    u16 Width;
    u16 Height;
} RECT, *LPRECT;

u16 rectGetEndX(LPRECT rc);
u16 rectGetEndY(LPRECT rc);
bool rectPtInRect(LPRECT rc, POINT pt);
bool rectRectInRect(LPRECT rcOuter, LPRECT rcInner);
void rectSetSize(LPRECT rc, SIZE sz);
void rectSetPoint(LPRECT rc, POINT pt);
void rectSetRect(LPRECT rc, u16 x, u16 y, u16 width, u16 height);
//draw rect with specified color
void drawRect(
			  u16 x,		//X begin
			  u16 y,		//Y begin
			  u16 width,	//area width 
			  u16 height,	//area height
			  u16 color		//color
			  );

//Draw line
void drawLine(
				  u16 x1,	//The x-coordinate of the first line endpoint.
				  u16 y1,	//The y-coordinate of the first line endpoint.
				  u16 x2,	//The x-coordinate of the second line endpoint.
				  u16 y2,	//The y-coordinate of the second line endpoint.
				  u16 color	//Line color
				  );

void drawSetDisplayOrient(u8 orient);//set display orientation: 0 = vertical, 1 = horizontal
//get rectangle of all display
void drawGetDisplayRect(LPRECT rc);
SIZE drawGetDisplaySize();

//fill up specified rectangle
void drawFillRect(LPRECT rc, u16 color);

//simple draw string w/out check length
void drawString(u8* str,	//string
				u16 len,	//length of string
				u16 X,   //start point of string
                u16 Y,
				u16 color,	//text color
				u16 bgcolor);//back color


#endif


