//SystemFlags.h file  - system control values and enums
#ifndef HWSYSFLAGS_H
#define HWSYSFLAGS_H
#include "stm32f10x.h" //project data types

u32 sysFlags; //system control flags. Init on startup, changed by core only, read by core or apps

#define SYSFLAG_HSEFAIL    31 //set by init procedure if HSE fail, HSI used 
#define SYSFLAG_BATTGOOD   30 //1 for good battery
#define SYSFLAG_TEMPGOOD   29 //1 for good MCU temperature
#define SYSFLAG_TOUCHPRESS 28 //1 for pressed touchscreen

#define SYSFLAG_DRAWORIENT 25 //1 for horizontal mode, 0 for vertical; default=0; used;



//*************************************************************************
void sysSetFlag(u8 flag);


void sysClearFlag(u8 flag);


bool sysGetFlag(u8 flag);


void sysInvertFlag(u8 flag);



#endif

