//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for EXTMMC subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_EXTMMC_H
#define  MY_EXTMMC_H

#include "stm32f10x.h" //project data types
//DEFINES

/* Exported types ------------------------------------------------------------*/
typedef enum
{
  /* SDIO specific error defines */
  EXTMMC_CMD_CRC_FAIL                    = (1), /* Command response received (but CRC check failed) */
  EXTMMC_DATA_CRC_FAIL                   = (2), /* Data bock sent/received (CRC check Failed) */
  EXTMMC_CMD_RSP_TIMEOUT                 = (3), /* Command response timeout */
  EXTMMC_DATA_TIMEOUT                    = (4), /* Data time out */
  EXTMMC_TX_UNDERRUN                     = (5), /* Transmit FIFO under-run */
  EXTMMC_RX_OVERRUN                      = (6), /* Receive FIFO over-run */
  EXTMMC_START_BIT_ERR                   = (7), /* Start bit not detected on all data signals in widE bus mode */
  EXTMMC_CMD_OUT_OF_RANGE                = (8), /* CMD's argument was out of range.*/
  EXTMMC_ADDR_MISALIGNED                 = (9), /* Misaligned address */
  EXTMMC_BLOCK_LEN_ERR                   = (10), /* Transferred block length is not allowed for the card or the number of transferred bytes does not match the block length */
  EXTMMC_ERASE_SEQ_ERR                   = (11), /* An error in the sequence of erase command occurs.*/
  EXTMMC_BAD_ERASE_PARAM                 = (12), /* An Invalid selection for erase groups */
  EXTMMC_WRITE_PROT_VIOLATION            = (13), /* Attempt to program a write protect block */
  EXTMMC_LOCK_UNLOCK_FAILED              = (14), /* Sequence or password error has been detected in unlock command or if there was an attempt to access a locked card */
  EXTMMC_COM_CRC_FAILED                  = (15), /* CRC check of the previous command failed */
  EXTMMC_ILLEGAL_CMD                     = (16), /* Command is not legal for the card state */
  EXTMMC_CARD_ECC_FAILED                 = (17), /* Card internal ECC was applied but failed to correct the data */
  EXTMMC_CC_ERROR                        = (18), /* Internal card controller error */
  EXTMMC_GENERAL_UNKNOWN_ERROR           = (19), /* General or Unknown error */
  EXTMMC_STREAM_READ_UNDERRUN            = (20), /* The card could not sustain data transfer in stream read operation. */
  EXTMMC_STREAM_WRITE_OVERRUN            = (21), /* The card could not sustain data programming in stream mode */
  EXTMMC_CID_CSD_OVERWRITE               = (22), /* CID/CSD overwrite error */
  EXTMMC_WP_ERASE_SKIP                   = (23), /* only partial address space was erased */
  EXTMMC_CARD_ECC_DISABLED               = (24), /* Command has been executed without using internal ECC */
  EXTMMC_ERASE_RESET                     = (25), /* Erase sequence was cleared before executing because an out of erase sequence command was received */
  EXTMMC_AKE_SEQ_ERROR                   = (26), /* Error in sequence of authentication. */
  EXTMMC_INVALID_VOLTRANGE               = (27),
  EXTMMC_ADDR_OUT_OF_RANGE               = (28),
  EXTMMC_SWITCH_ERROR                    = (29),
  EXTMMC_SDIO_DISABLED                   = (30),
  EXTMMC_SDIO_FUNCTION_BUSY              = (31),
  EXTMMC_SDIO_FUNCTION_FAILED            = (32),
  EXTMMC_SDIO_UNKNOWN_FUNCTION           = (33),

  /* Standard error defines */
  EXTMMC_INTERNAL_ERROR, 
  EXTMMC_NOT_CONFIGURED,
  EXTMMC_REQUEST_PENDING, 
  EXTMMC_REQUEST_NOT_APPLICABLE, 
  EXTMMC_INVALID_PARAMETER,  
  EXTMMC_UNSUPPORTED_FEATURE,  
  EXTMMC_UNSUPPORTED_HW,  
  EXTMMC_ERROR,  
  EXTMMC_OK,  
} EXTMMC_Error;

/* SDIO Commands  Index */
#define SDIO_GO_IDLE_STATE                       ((uint8_t)0)
#define SDIO_SEND_OP_COND                        ((uint8_t)1)
#define SDIO_ALL_SEND_CID                        ((uint8_t)2)
#define SDIO_SET_REL_ADDR                        ((uint8_t)3) /* SDIO_SEND_REL_ADDR for SD Card */
#define SDIO_SET_DSR                             ((uint8_t)4)
#define SDIO_SDIO_SEN_OP_COND                    ((uint8_t)5)
#define SDIO_HS_SWITCH                           ((uint8_t)6)
#define SDIO_SEL_DESEL_CARD                      ((uint8_t)7)
#define SDIO_HS_SEND_EXT_CSD                     ((uint8_t)8)
#define SDIO_SEND_CSD                            ((uint8_t)9)
#define SDIO_SEND_CID                            ((uint8_t)10)
#define SDIO_READ_DAT_UNTIL_STOP                 ((uint8_t)11) /* SD Card doesn't support it */
#define SDIO_STOP_TRANSMISSION                   ((uint8_t)12)
#define SDIO_SEND_STATUS                         ((uint8_t)13)
#define SDIO_HS_BUSTEST_READ                     ((uint8_t)14)
#define SDIO_GO_INACTIVE_STATE                   ((uint8_t)15)
#define SDIO_SET_BLOCKLEN                        ((uint8_t)16)
#define SDIO_READ_SINGLE_BLOCK                   ((uint8_t)17)
#define SDIO_READ_MULT_BLOCK                     ((uint8_t)18)
#define SDIO_HS_BUSTEST_WRITE                    ((uint8_t)19)
#define SDIO_WRITE_DAT_UNTIL_STOP                ((uint8_t)20) /* SD Card doesn't support it */
#define SDIO_SET_BLOCK_COUNT                     ((uint8_t)23) /* SD Card doesn't support it */
#define SDIO_WRITE_SINGLE_BLOCK                  ((uint8_t)24)
#define SDIO_WRITE_MULT_BLOCK                    ((uint8_t)25)
#define SDIO_PROG_CID                            ((uint8_t)26) /* reserved for manufacturers */
#define SDIO_PROG_CSD                            ((uint8_t)27)
#define SDIO_SET_WRITE_PROT                      ((uint8_t)28)
#define SDIO_CLR_WRITE_PROT                      ((uint8_t)29)
#define SDIO_SEND_WRITE_PROT                     ((uint8_t)30)
#define SDIO_SD_ERASE_GRP_START                  ((uint8_t)32) /* To set the address of the first write
                                                                  block to be erased. (For SD card only) */
#define SDIO_SD_ERASE_GRP_END                    ((uint8_t)33) /* To set the address of the last write block of the
                                                                  continuous range to be erased. (For SD card only) */
#define SDIO_ERASE_GRP_START                     ((uint8_t)35) /* To set the address of the first write block to be erased.
                                                                  (For MMC card only spec 3.31) */

#define SDIO_ERASE_GRP_END                       ((uint8_t)36) /* To set the address of the last write block of the
                                                                  continuous range to be erased. (For MMC card only spec 3.31) */

#define SDIO_ERASE                               ((uint8_t)38)
#define SDIO_FAST_IO                             ((uint8_t)39) /* SD Card doesn't support it */
#define SDIO_GO_IRQ_STATE                        ((uint8_t)40) /* SD Card doesn't support it */
#define SDIO_LOCK_UNLOCK                         ((uint8_t)42)
#define SDIO_APP_CMD                             ((uint8_t)55)
#define SDIO_GEN_CMD                             ((uint8_t)56)
#define SDIO_NO_CMD                              ((uint8_t)64)

/* Following commands are SD Card Specific commands.
   SDIO_APP_CMD should be sent before sending these
   commands. */
#define SDIO_APP_SD_SET_BUSWIDTH                 ((uint8_t)6)  /* For SD Card only */
#define SDIO_SD_APP_STAUS                        ((uint8_t)13) /* For SD Card only */
#define SDIO_SD_APP_SEND_NUM_WRITE_BLOCKS        ((uint8_t)22) /* For SD Card only */
#define SDIO_SD_APP_OP_COND                      ((uint8_t)41) /* For SD Card only */
#define SDIO_SD_APP_SET_CLR_CARD_DETECT          ((uint8_t)42) /* For SD Card only */
#define SDIO_SD_APP_SEND_SCR                     ((uint8_t)51) /* For SD Card only */
#define SDIO_SDIO_RW_DIRECT                      ((uint8_t)52) /* For SD I/O Card only */
#define SDIO_SDIO_RW_EXTENDED                    ((uint8_t)53) /* For SD I/O Card only */

/* Following commands are SD Card Specific security commands.
   SDIO_APP_CMD should be sent before sending these commands. */
#define SDIO_SD_APP_GET_MKB                      ((uint8_t)43) /* For SD Card only */
#define SDIO_SD_APP_GET_MID                      ((uint8_t)44) /* For SD Card only */
#define SDIO_SD_APP_SET_CER_RN1                  ((uint8_t)45) /* For SD Card only */
#define SDIO_SD_APP_GET_CER_RN2                  ((uint8_t)46) /* For SD Card only */
#define SDIO_SD_APP_SET_CER_RES2                 ((uint8_t)47) /* For SD Card only */
#define SDIO_SD_APP_GET_CER_RES1                 ((uint8_t)48) /* For SD Card only */
#define SDIO_SD_APP_SECURE_READ_MULTIPLE_BLOCK   ((uint8_t)18) /* For SD Card only */
#define SDIO_SD_APP_SECURE_WRITE_MULTIPLE_BLOCK  ((uint8_t)25) /* For SD Card only */
#define SDIO_SD_APP_SECURE_ERASE                 ((uint8_t)38) /* For SD Card only */
#define SDIO_SD_APP_CHANGE_SECURE_AREA           ((uint8_t)49) /* For SD Card only */
#define SDIO_SD_APP_SECURE_WRITE_MKB             ((uint8_t)48) /* For SD Card only */

typedef enum
{
  SD_NO_TRANSFER  = 0,
  SD_TRANSFER_IN_PROGRESS
} SDTransferState;

typedef struct
{
  uint16_t TransferredBytes;
  EXTMMC_Error TransferError;
  uint8_t  padding;
} SDLastTransferInfo;

typedef struct       /* Card Specific Data */
{
  __IO uint8_t  CSDStruct;            /* CSD structure */
  __IO uint8_t  SysSpecVersion;       /* System specification version */
  __IO uint8_t  Reserved1;            /* Reserved */
  __IO uint8_t  TAAC;                 /* Data read access-time 1 */
  __IO uint8_t  NSAC;                 /* Data read access-time 2 in CLK cycles */
  __IO uint8_t  MaxBusClkFrec;        /* Max. bus clock frequency */
  __IO uint16_t CardComdClasses;      /* Card command classes */
  __IO uint8_t  RdBlockLen;           /* Max. read data block length */
  __IO uint8_t  PartBlockRead;        /* Partial blocks for read allowed */
  __IO uint8_t  WrBlockMisalign;      /* Write block misalignment */
  __IO uint8_t  RdBlockMisalign;      /* Read block misalignment */
  __IO uint8_t  DSRImpl;              /* DSR implemented */
  __IO uint8_t  Reserved2;            /* Reserved */
  __IO uint32_t DeviceSize;           /* Device Size */
  __IO uint8_t  MaxRdCurrentVDDMin;   /* Max. read current @ VDD min */
  __IO uint8_t  MaxRdCurrentVDDMax;   /* Max. read current @ VDD max */
  __IO uint8_t  MaxWrCurrentVDDMin;   /* Max. write current @ VDD min */
  __IO uint8_t  MaxWrCurrentVDDMax;   /* Max. write current @ VDD max */
  __IO uint8_t  DeviceSizeMul;        /* Device size multiplier */
  __IO uint8_t  EraseGrSize;          /* Erase group size */
  __IO uint8_t  EraseGrMul;           /* Erase group size multiplier */
  __IO uint8_t  WrProtectGrSize;      /* Write protect group size */
  __IO uint8_t  WrProtectGrEnable;    /* Write protect group enable */
  __IO uint8_t  ManDeflECC;           /* Manufacturer default ECC */
  __IO uint8_t  WrSpeedFact;          /* Write speed factor */
  __IO uint8_t  MaxWrBlockLen;        /* Max. write data block length */
  __IO uint8_t  WriteBlockPaPartial;  /* Partial blocks for write allowed */
  __IO uint8_t  Reserved3;            /* Reserded */
  __IO uint8_t  ContentProtectAppli;  /* Content protection application */
  __IO uint8_t  FileFormatGrouop;     /* File format group */
  __IO uint8_t  CopyFlag;             /* Copy flag (OTP) */
  __IO uint8_t  PermWrProtect;        /* Permanent write protection */
  __IO uint8_t  TempWrProtect;        /* Temporary write protection */
  __IO uint8_t  FileFormat;           /* File Format */
  __IO uint8_t  ECC;                  /* ECC code */
  __IO uint8_t  CSD_CRC;              /* CSD CRC */
  __IO uint8_t  Reserved4;            /* always 1*/
} EXTMMC_CSD;

typedef struct      /*Card Identification Data*/
{
  __IO uint8_t  ManufacturerID;       /* ManufacturerID */
  __IO uint16_t OEM_AppliID;          /* OEM/Application ID */
  __IO uint32_t ProdName1;            /* Product Name part1 */
  __IO uint8_t  ProdName2;            /* Product Name part2*/
  __IO uint8_t  ProdRev;              /* Product Revision */
  __IO uint32_t ProdSN;               /* Product Serial Number */
  __IO uint8_t  Reserved1;            /* Reserved1 */
  __IO uint16_t ManufactDate;         /* Manufacturing Date */
  __IO uint8_t  CID_CRC;              /* CID CRC */
  __IO uint8_t  Reserved2;            /* always 1 */
} EXTMMC_CID;

typedef struct
{
  EXTMMC_CSD SD_csd;
  EXTMMC_CID SD_cid;
  uint32_t CardCapacity; /* Card Capacity */
  uint32_t CardBlockSize; /* Card Block Size */
  uint16_t RCA;
  uint8_t CardType;
} EXTMMC_CardInfo;

/* Exported constants --------------------------------------------------------*/
#define EXTMMC_DMA_MODE                     (0x00000000)
#define EXTMMC_INTERRUPT_MODE               (0x00000001)
#define EXTMMC_POLLING_MODE                 (0x00000002)

/* Supported Memory Cards */
#define SDIO_STD_CAPACITY_SD_CARD_V1_1     (0x0)
#define SDIO_STD_CAPACITY_SD_CARD_V2_0     (0x1)
#define SDIO_HIGH_CAPACITY_SD_CARD         (0x2)
#define SDIO_MULTIMEDIA_CARD               (0x3)
#define SDIO_SECURE_DIGITAL_IO_CARD        (0x4)
#define SDIO_HIGH_SPEED_MULTIMEDIA_CARD    (0x5)
#define SDIO_SECURE_DIGITAL_IO_COMBO_CARD  (0x6)
#define SDIO_HIGH_CAPACITY_MMC_CARD        (0x7)

//PROTOTYPES

EXTMMC_Error EXTMMC_Init(void);
void  EXTMMC_Exit();
EXTMMC_Error EXTMMC_PowerON(void);
EXTMMC_Error EXTMMC_PowerOFF(void);
EXTMMC_Error EXTMMC_InitializeCards(void);
EXTMMC_Error EXTMMC_GetCardInfo(EXTMMC_CardInfo *cardinfo);
EXTMMC_Error EXTMMC_EnableWideBusOperation(uint32_t WideMode);
EXTMMC_Error EXTMMC_SetDeviceMode(uint32_t Mode);
EXTMMC_Error EXTMMC_SelectDeselect(uint32_t addr);
EXTMMC_Error EXTMMC_ReadBlock(uint32_t *readbuff, uint32_t addr, uint16_t BlockSize);
EXTMMC_Error EXTMMC_WriteBlock(uint32_t *writebuff, uint32_t addr, uint16_t BlockSize);
SDTransferState EXTMMC_GetTransferState(void);
EXTMMC_Error EXTMMC_StopTransfer(void);
EXTMMC_Error EXTMMC_Erase(uint32_t startaddr, uint32_t endaddr);
EXTMMC_Error EXTMMC_SendStatus(uint32_t *pcardstatus);
EXTMMC_Error EXTMMC_SendSDStatus(uint32_t *psdstatus);
EXTMMC_Error EXTMMC_ProcessIRQSrc(void);






#endif // MY_EXTMMC_H