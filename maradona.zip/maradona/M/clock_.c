/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "clock_.h"
#include "ram_.h"

//FUNCTIONS
void CLOCK_Init2(u16 clkMode);



//init clock by mode number
void CLOCK_Init(u16 clkMode)
{
	//init clocks by clockmode - refactor all initialization
	RCC_DeInit(); //if not after reset 
#ifndef SIMULATOR

	CLOCK_Init2(clkMode); //configure main clocks by clockMode

#else //SIMULATOR defined, this code run only for simulator

	//HSI used as system clock
	/* HCLK = SYSCLK */
	RCC_HCLKConfig(RCC_SYSCLK_Div1);  
	/* PCLK2 = HCLK */
	RCC_PCLK2Config(RCC_HCLK_Div1);  
	/* PCLK1 = HCLK */
	RCC_PCLK1Config(RCC_HCLK_Div1); 
	//use HSI 8mhz as clock source
	/* Select HSI as system clock source */
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
	/* Wait till HSI is used as system clock source */
	while(RCC_GetSYSCLKSource() != 0x00)
	{;
	} 

#endif

	return;

}

//exit clock
void CLOCK_Exit()
{
	RCC_DeInit(); 
}

//clockmodes:
//CLKMODE_12: hclk=12; pclk1=12; pclk2=12; adcclk=pclk2/2=6m; flatency=0;
//CLKMODE_24: hclk=24; pclk1=24; pclk2=24; adcclk=pclk2/4=6m; flatency=0;
//CLKMODE_48: hclk=48; pclk1=24; pclk2=24; adcclk=pclk2/4=6m; flatency=1;
//CLKMODE_72: hclk=72; pclk1=36; pclk2=36; adcclk=pclk2/6=6m; flatency=2;

//helper for all clockmodes
void CLOCK_Init2(u16 clkMode) //0xac lenght
{
	ErrorStatus es;
	u32 tmp;

	/*  Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);

	/* Wait till HSE is ready (RCC_CR.HSERDY be 1)*/
	es = RCC_WaitForHSEStartUp();//HSE IS READY OR FAIL

	/* HCLK = SYSCLK */
	RCC_HCLKConfig(RCC_SYSCLK_Div1); 

	//4)
	//[72][48]
	//PCLK2 = HCLK/2
	//RCC_PCLK2Config(RCC_HCLK_Div2);  
	//[24][12]
	//PCLK2 = HCLK/1
	//RCC_PCLK2Config(RCC_HCLK_Div1);
	if(clkMode > CLKMODE_24) //72 or 48
		tmp = RCC_HCLK_Div2;
	else tmp = RCC_HCLK_Div1; //24 or 12
	RCC_PCLK2Config(tmp);


	//5)
	//[72][48]
	////use HSE 12mhz or HSI 8mhz as clock source, PLL to 72 mhz
	//PCLK1 = HCLK / 2  (bus speed 36 mhz limited)
	//RCC_PCLK1Config(RCC_HCLK_Div2);   
	//[24][12]
	////use HSE 12mhz or HSI 8mhz as clock source, PLL to 48 mhz
	//PCLK1 = HCLK  (bus speed 36 mhz limited)
	//RCC_PCLK1Config(RCC_HCLK_Div1); 
	// if(clkMode > CLKMODE_24) //72 or 48
	// tmp = RCC_HCLK_Div2;
	// else tmp = RCC_HCLK_Div1; //24 or 12
	RCC_PCLK1Config(tmp);

	//6)
	//[72]
	//Flash 2 wait state
	//FLASH_SetLatency(FLASH_Latency_2);
	//[48]
	//Flash 1 wait state
	//FLASH_SetLatency(FLASH_Latency_1);
	//[24][12]
	//Flash 0 wait state
	//FLASH_SetLatency(FLASH_Latency_0);
	if(clkMode == CLKMODE_72) tmp = FLASH_Latency_2;
	else if(clkMode == CLKMODE_48) tmp = FLASH_Latency_1;
	else tmp = FLASH_Latency_0;
	FLASH_SetLatency(tmp);

	//7)
	//[72][48][24][12]
	//Enable Prefetch Buffer 
	FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable); 

	//8)
	if(es == SUCCESS)//HSE success
	{
		//[72]
		//PLLCLK = 12MHz * 6 = 72 MHz 
		//	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_6);
		//[48]
		//PLLCLK = 12MHz * 4 = 48 MHz 
		//	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_4);
		//[24]
		//PLLCLK = 12MHz * 2 = 48 MHz 
		//	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_2);
		if(clkMode != CLKMODE_12)
		{
			if(clkMode == CLKMODE_24) tmp = RCC_PLLMul_2;
			else if(clkMode == CLKMODE_48) tmp = RCC_PLLMul_4;
			else if(clkMode == CLKMODE_72)tmp = RCC_PLLMul_6;
			RCC_PLLConfig(RCC_PLLSource_HSE_Div1, tmp);
		}
		//[12]
		else
		{
			//configure to work without PLL
			//Select HSE as system clock source
			RCC_SYSCLKConfig(RCC_SYSCLKSource_HSE);

			/* Wait till HSE is used as system clock source */
			while(RCC_GetSYSCLKSource() != 0x04)
			{
			}
			//return from function
			return;
		}
	}
	//9)[72][48][24][12]
	else  //HSE fail, HCLK=64mhz max
	{
		//TODO: Set sysFlags for HSEfail

		//10)
		//[72][48][24][12]
		//use HSI 8mhz as clock source
		//Disable HSE 
		RCC_HSEConfig(RCC_HSE_OFF);

		//set sysflag for HSI work
		RAM_sysSetFlag(SYSFLAG_HSEFAIL);

		//11)
		//[72]
		//PLLCLK = 8/2MHz * 16 = 64 MHz. If USB plan use, PLLCLK must be 48MHz! 
		//RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_16);
		//[48]
		//PLLCLK = 8/2MHz * 12 = 48 MHz. If USB plan use, PLLCLK must be 48MHz! 
		//RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_12);
		//[24]
		//PLLCLK = 8/2MHz * 6 = 24 MHz. If USB plan use, PLLCLK must be 48MHz! 
		//RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_6);
		//[12]
		//PLLCLK = 8/2MHz * 3 = 12 MHz. If USB plan use, PLLCLK must be 48MHz!  
		//RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_3);
		if(clkMode == CLKMODE_72) tmp = RCC_PLLMul_16;
		else if(clkMode == CLKMODE_48) tmp = RCC_PLLMul_12;
		else if (clkMode == CLKMODE_24)  tmp = RCC_PLLMul_6;
		else tmp = RCC_PLLMul_3;
		RCC_PLLConfig(RCC_PLLSource_HSI_Div2, tmp);    
	}
	//12)
	//[72][48][24][12]
	//Enable PLL  
	RCC_PLLCmd(ENABLE);

	//13)
	//[72][48][24][12]
	//Wait till PLL is ready 
	while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
	{
	}

	//14)
	//[72][48][24][12]
	//Select PLL as system clock source 
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

	//15)
	//[72][48][24][12]
	//Wait till PLL is used as system clock source 
	while(RCC_GetSYSCLKSource() != 0x08)
	{
	}	

	return;
}


