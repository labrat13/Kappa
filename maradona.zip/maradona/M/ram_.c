/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "ram_.h"

//GLOBAL VARIABLES
u16 RAM_sysFlags; //system control flags. Init on startup, changed by core only, read by core or apps
u16 RAM_sysSave1; //stored in backup register, 8-15=brightlevel; 0-1=clockmode;
u16 RAM_sysSave2; //stored in backup register


//AND mask's
#define SYSFLAG_BACKLIGHT_MASK 0xFF00
#define SYSFLAG_CLKMODE_MASK   0x0003 

//FUNCTIONS
void initMemAlloc(void);

 //init ram subsystem
void RAM_Init()
{
	RAM_sysFlags = 0; //TODO: set sysflags to proper value
    RAM_StampCounter = 0; //init timestamp counter for all subsystems
	initMemAlloc();
}

void RAM_Exit()
{

}

//TIMESTAMP FUNCTIONS

//return timestamp 1mS
u32 APIEXPORT  RAM_getTimestamp()
{
	return RAM_StampCounter;
}

//SYSFLAG FUNCTIONS
void RAM_sysSetFlag(u8 flag)
{
	RAM_sysFlags = RAM_sysFlags | (1 << flag);
}

void RAM_sysClearFlag(u8 flag)
{
	RAM_sysFlags = RAM_sysFlags & (~(1 << flag)); //!!! test it!
}

u32 RAM_sysGetFlag(u8 flag)
{
	if((RAM_sysFlags & (1 << flag)) > 0)
       return 1; else return 0; 
}

void RAM_sysInvertFlag(u8 flag)
{
	RAM_sysFlags = RAM_sysFlags ^ (1 << flag);
}

//return backlight value
//NT
u16 RAM_getSysBackLight()
{
    return (u32)((RAM_sysSave1 & SYSFLAG_BACKLIGHT_MASK) >> 8); 
}

//store backlight value into sysflag variable
//NT
void RAM_storeSysBackLight(u16 val)
{
   RAM_sysSave1 = RAM_sysSave1 & (~(SYSFLAG_BACKLIGHT_MASK)); //clear bits
   RAM_sysSave1 = RAM_sysSave1 | ((val << 8) & SYSFLAG_BACKLIGHT_MASK); //set mode bits
}

//NT-get system clock mode number
u32  APIEXPORT RAM_getSysClockMode()
{
    return (u32)(RAM_sysSave1 & SYSFLAG_CLKMODE_MASK); 
}

//NT-store system clock mode number
void RAM_storeSysClockMode(u16 val)
{
   RAM_sysSave1 = RAM_sysSave1 & (~(SYSFLAG_CLKMODE_MASK)); //clear bits
   RAM_sysSave1 = RAM_sysSave1 | (val & SYSFLAG_CLKMODE_MASK); //set mode bits 
}


//MEMORY FUNCTIONS
//Zeroes memory
void APIEXPORT  RAM_memZero(u8* addr, u32 size)
{
    u8* t = addr + size;
    while(addr < t)
    {
        *addr = 0;
        addr++;
    }
    return;
}

//Fill memory
void  APIEXPORT RAM_memFill(u8* addr, u8 value, u32 size)
{
    u8* t = addr + size;
    while(addr < t)
    {
        *addr = value;
        addr++;
    }
    return;
}

//copy memory block  from src to dest address
void  APIEXPORT RAM_memCopy(u8* dest, u8* src, u32 size)
{
    u8* t = src + size;
    while(src < t)
    {
        *dest = *src;
        dest++; src++;
    }
    return;		
}

//Compare two memory buffers with n bytes.
//Return 0 if equal else return u1-u2
s32  APIEXPORT RAM_memComp(u8* s1, u8* s2, u32 n)
{
    u8* t = s1 + n;
    while(s1 < t)
    {
     if ( *s1 != *s2)  return (s32)(*s1-*s2);
     s1++; s2++;
    }
    return 0;
}

//******************* Memory allocation functions *********************** 
//heap top and bottom address comes from linker script
extern volatile unsigned long _eusrstack;
extern volatile unsigned long _Stack_Init;

void assert_failed(u8* file, u32 line); //for error reporting 

//Setup heap start and end addresses. Values are volatile.
//You should check real values in linker script
#define MEMTOP		(u32)(((u32)(&_eusrstack)) + 4)	//start of heap, 4 bytes aligned
#define MEMBOTTOM	(u32)(((u32)(&_Stack_Init)) - 4)	//(from linker) begin of stack, end of heap, must be 4 bytes aligned

//define mask for marker state flag
#define ALLOC_USED			0x0001	//bit0 is 1 if block used, 0 for free
#define ALLOC_USED_NMASK	0xfffe	//inverse mask for clear bit0
#define ALLOC_INVALID_FLAG_VALUE 0x0001 //if flag value > limit, marker invalid
#define ALLOC_TAG_MASK		0xff00  //mask for tag number
#define ALLOC_TAG_NMASK		0x00ff  //mask for tag number

//marker for memory blocks
typedef struct _MEMMARKER
{
	u16 Size;	//size of allocated block, in bytes
	u16 flags;
} MEMMARKER, *LPMEMMARKER;


/* 
How it work.
Initially only one marker created - at heap begin.
All allocations must be aligned to 4 bytes.
Marker size must be 4 bytes.
Size in markers in dwords, thus minimal allocated 4 bytes.
When memAlloc() called, it pass trough marker's chain, merge all free blocks.
(Skip free markers and increment overall block size in first free marker)
If founded free block is bigger than requested size, then
 store it's address and size in temp variables (lpResult and minSize)and find next free block until MEMBOTTOM.
If founded free block bigger than requested size but smaller than block stored in temp variable,
 then it's (with size) placed to temp variables.
If founded free block match with requested size, block marked as used and then return.
If MEMBOTTOM is reached, get block from temp variables and create marker at aligned end of block.
If no free blocks, return null.

Optionally, fill allocated memory with value
Optionally, check markers integrity (check flag value and block size)
Marker chain not recoverable - thus it be global system fail.
151212 - add marker tag for release all objects by tag number. It for multitasking system, where tag is task identifier. 
  + process ALLOC_INVALID_FLAG_VALUE conditions to avoid collision
  + create removed-by-tag function
*/

//initialise allocation 
void initMemAlloc()
{
	//create first marker
	LPMEMMARKER lp = (LPMEMMARKER)(MEMTOP);
	lp->flags = 0;//free block
	lp->Size = (u16)((MEMBOTTOM - sizeof(MEMMARKER) - MEMTOP) / sizeof(MEMMARKER));
}

//get address of next used block in chain
inline LPMEMMARKER getNextUsedBlock(LPMEMMARKER marker)
{
	while((marker < (LPMEMMARKER)(MEMBOTTOM)) && ((marker->flags & ALLOC_USED) == 0))
		marker = marker + marker->Size + 1; 
	return marker;
}


//allocate memory and return 32bit-aligned region 
//size = memory size in bytes, aligned to 4. Each block have 4+size bytes in memory.
//tag = unical 0..255 value for mark allocated elements as group for next deleting. Typcally, task identifier.
u8* __attribute__ ((malloc)) RAM_memAlloc(u32 size, u32 tag)
{
	//size in dwords, aligned
	u16 s = (u16)size;
	if((size & 0x03) > 0) s +=4;
	s = s / 4;

	//151212 TAG added
	tag = ((tag << 8) & ALLOC_TAG_MASK); //to bits 8-15
	
	LPMEMMARKER lpn, lpResult, lpNext;

	u16 minSize = 0xFFFF;//max value;
	lpResult = (LPMEMMARKER)0;
    
	lpn = (LPMEMMARKER)(MEMTOP);//init
	while(lpn < (LPMEMMARKER)(MEMBOTTOM))
	{
		if((lpn->flags & ALLOC_TAG_NMASK) > ALLOC_INVALID_FLAG_VALUE) //if invalid marker //151212-TAG
		{
			//marker is invalid, heap structure invalid, return null or throw exception
            //you can add debug message here
            //throw "Invalid marker!";
            //assert_failed(__FILE__, __LINE__);
            return (u8*)0;
		}
		else
		{
			if((lpn->flags & ALLOC_USED) == 0) //if free block
			{
				lpNext = getNextUsedBlock(lpn);//get size of chain of next free blocks
				lpn->Size = lpNext - lpn - 1;
				//if it is an appropriate block, then store in lpResult address
				if(lpn->Size >= s)//size match, end search
				{
					if(lpn->Size == s)
					{
                        //full match of size - break loop, return address
                        //mark as used and return address;
                        lpn->flags = lpn->flags | ALLOC_USED;
                        lpn->flags = lpn->flags | tag;		//151212 TAG added
                        return (u8*) (lpn + 1);
					}
					else //size > s; find minimal block
					{
						if(minSize > lpn->Size) { minSize = lpn->Size; lpResult = lpn; }
					}
				}
			}
			//go to next marker
			lpn = lpn + lpn->Size + 1; 
		}
	}
	//check lpResult and create marker
	if(lpResult == (LPMEMMARKER)0)  return (u8*) 0;//nothing found
	if(lpResult->Size > s + 1) //if free space more than required block + new marker, create new marker
	{
		//create new marker for free space and set sizes for new and used block markers
		lpn = lpResult + s + 1; //get address for new marker
		lpn->flags = 0; //free
		lpn->Size = lpResult->Size - (s + 1); //set size of new free block
		lpResult->Size = s; //set size of new used block
	}
	//mark as used and return address;
	lpResult->flags = lpResult->flags | ALLOC_USED;
	lpResult->flags = lpResult->flags | tag;		//151212 TAG added
	return (u8*) (lpResult + 1);
}

//allocate memory and fill with value. Typical use for debug.
u8* RAM_memAllocFill(u32 size, u32 tag, u8 value)
{
	u8* ptr = RAM_memAlloc(size, tag);
	if(ptr > 0) RAM_memFill(ptr, value, size);
	return ptr;
}


//free memory allocated by memAlloc
void  APIEXPORT RAM_memFree(u8* addr)
{
	LPMEMMARKER lp = (LPMEMMARKER)addr;
	if(addr != (u8*)0)
	{
		lp--;//to marker address
		if((lp->flags & ALLOC_TAG_NMASK) > ALLOC_INVALID_FLAG_VALUE) //if invalid marker //151212-TAG
		{
			//marker is invalid, heap structure invalid, return null or throw exception
            //you can add debug message here
            //throw "Invalid marker!";
            //assert_failed(__FILE__, __LINE__);
            ;
        }
		else
		{
			//lp->flags = lp->flags & ALLOC_USED_NMASK;	//reset USED bit
			lp->flags = 0;  //151212-TAG  optimized, ��� ����������������� ������� ������� ������� �����-���� ��������.
		}
	}
}


//count and delete items by tag  //151212 TAG added
//tag=tag of items, values in range 1..255
//del=0 for count only; =1 for deleting items
u32  RAM_memFreeByTag(u32 tag, u32 del)
{
	u32 count = 0;
	tag = tag << 8;
	LPMEMMARKER lpt;

	lpt = (LPMEMMARKER)(MEMTOP);
	while(lpt < (LPMEMMARKER)(MEMBOTTOM))
	{
		//if marker invalid, throw
		if((lpt->flags & ALLOC_TAG_NMASK) > ALLOC_INVALID_FLAG_VALUE)
		{
			//throw "invalid marker or address";
			;
		}
		else
		{
			if((lpt->flags & ALLOC_USED) != 0) //IF used BLOCK
			{
				//used block
				if((lpt->flags & ALLOC_TAG_MASK) == tag) //if block have specified tag
				{
					if(del > 0) lpt->flags = 0;  //release block
					count++;
				}
			}
			lpt = lpt + lpt->Size + 1; //to next block
		}
	}
	return count; //return count of removed items
}

//-------------------- LIST FUNCTIONS --------------

#define RAM_MEM_RELATIVE_START 0x20000000 //start address of ram in device address space


inline  PRAM_ListItem getItemFromRelative(u16 relAddr)
{
	return (PRAM_ListItem) (relAddr + RAM_MEM_RELATIVE_START);
}
inline u16 getRelativeFromItem(PRAM_ListItem addr)
{
	return (u16)((u32)((u8*)addr) - RAM_MEM_RELATIVE_START);
}

//get number of list elements
u32  APIEXPORT RAM_ListGetLength(PRAM_ListItem ListBase)
{
	return ListBase->itemValue;
}

//init list
void  APIEXPORT RAM_ListInit(PRAM_ListItem ListBase)
{
//������������ ������� � ������������ ������ ������� ������ � �������� ����.
//���� ������� �������� �����-���������� ������ � ������������ ���������� ������
	ListBase->relRight = getRelativeFromItem(ListBase); //������������� ����� ������ �������� ��������,
	ListBase->relLeft = getRelativeFromItem(ListBase); //������������� ����� ������ ������� ��������,
	ListBase->itemValue = 0; //����� ��������� ������
}

// insert item to right of specified anchor item
void  APIEXPORT RAM_ListInsertRight(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem)
{
	PRAM_ListItem right;
	right = getItemFromRelative(anchorItem->relRight);

	right->relLeft = getRelativeFromItem(newItem);
	newItem->relRight = getRelativeFromItem(right);
	newItem->relLeft = getRelativeFromItem(anchorItem);
	anchorItem->relRight = getRelativeFromItem(newItem);

	ListBase->itemValue = ListBase->itemValue + 1; //update counter
}

// insert item to right of specified anchor item
void  APIEXPORT RAM_ListInsertLeft(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem)
{
	PRAM_ListItem left;
	left = getItemFromRelative(anchorItem->relLeft);

	left->relRight = getRelativeFromItem(newItem);
	newItem->relLeft = getRelativeFromItem(left);
	newItem->relRight = getRelativeFromItem(anchorItem);
	anchorItem->relLeft = getRelativeFromItem(newItem);

	ListBase->itemValue = ListBase->itemValue + 1; //update counter
}

// remove item 
void  APIEXPORT RAM_ListRemoveItem(PRAM_ListItem ListBase, PRAM_ListItem delItem)
{
	PRAM_ListItem right, left;
	//do not remove list base item
	if(delItem == ListBase) return;
	//get item siblings
	right = getItemFromRelative(delItem->relRight);
	left = getItemFromRelative(delItem->relLeft);
	//connect siblings
	right->relLeft = getRelativeFromItem(left);
	left->relRight = getRelativeFromItem(right);
	//may be clear delItem fields? Skip for performance
	ListBase->itemValue = ListBase->itemValue - 1; //update counter
	return;
}

//remove all items from list use default allocation function 
void  APIEXPORT RAM_ListClear(PRAM_ListItem ListBase)
{
	PRAM_ListItem it;
	u16 cnt = ListBase->itemValue;
	while(cnt > 0)
	{
		it = getItemFromRelative(ListBase->relLeft);
		RAM_ListRemoveItem(ListBase, it);
		RAM_memFree((u8*) it);
		cnt--;
	}
	return;
}

//get left item
PRAM_ListItem  APIEXPORT RAM_ListGetTopLeft(PRAM_ListItem ListBase)
{
	//�������� ������� ����� ������� ������
	return getItemFromRelative(ListBase->relLeft);
}

//get item from bottom
PRAM_ListItem  APIEXPORT RAM_ListGetBottomRight(PRAM_ListItem ListBase)
{
	//�������� ������� ������ ������� ������
	return getItemFromRelative(ListBase->relRight);
}

//get item by index like array. First item have index 0 and is right item
//return 0 if any error
PRAM_ListItem  APIEXPORT RAM_ListGetByIndex(PRAM_ListItem ListBase, u32 index)
{
	PRAM_ListItem it;	
	index++; //������ ��������� � ����, � �������� ������ � �������
	if(index > ListBase->itemValue)	return (PRAM_ListItem) 0;
	//find
	it = ListBase;
	do
	{
		it = getItemFromRelative(it->relRight);
		index--;
	}
	while(index == 0);
	return it;
}

//**************** BITMASK function ********************
//return bitmask size in bytes for bitmap 
u32  APIEXPORT RAM_BitmaskCalcSize(u32 width, u32 height)
{
	u32 res = width * height;
	if((res & 7) > 0) res += 8; //must be integer
	return (res >> 3) + 2; //res / 8 + 2 bytes of sizes
}
//init bitmask internal structure
void  APIEXPORT RAM_BitmaskInit(u8* bitmask, u32 width, u32 height)
{
	u32 size = RAM_BitmaskCalcSize(width, height);
	u32 i;
    for(i = 2; i < size; i++)
		bitmask[i] = 0;
	bitmask[0] = width;
	bitmask[1] = height;
	return;
}
//get bitmask value
u32  APIEXPORT RAM_BitmaskGet(u8* bitmask, u32 x, u32 y)
{
	u32 w, h, t;
	//���� �� ���������������� x<w � y<h, �� ��� � ���� ����� ������?
	w = *bitmask;
	bitmask++; //h skipped
	h = *bitmask;
	bitmask++;
	//convert x y to address and offset
	t = ((y * w) + x);
	bitmask += t / 8;
	//get mask for bit
	h = t & 7;//% 8
	w = (u32)(*bitmask) & (128 >> h);
	return w;
}

//set bitmask value
void  APIEXPORT RAM_BitmaskSet(u8* bitmask, u32 x, u32 y)
{
	u32 w, h, t;
	//���� �� ���������������� x<w � y<h, �� ��� � ���� ����� ������?
	w = *bitmask;
	bitmask++;
	h = *bitmask;
	bitmask++;
	//convert x y to address and offset
	t = ((y * w) + x);
	bitmask += t / 8;
	//get mask for bit
	h = t & 7;//% 8
	*bitmask |= (128 >> h);
	return;
}

