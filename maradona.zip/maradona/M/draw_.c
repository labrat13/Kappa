/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "draw_.h"



//new functions


//get size of rectangle of string 
//string must not contain \t \r and other whitesymbols. Only \n allowed.
void APIEXPORT  DRAW_GetStringSize(u8* string, u32 stringLen, LPGDATA_SIZE sz)
{
	u32 cnt;
	u8 ch;
	u8* endptr;

	endptr = string + stringLen;
	sz->Height = 0;
	sz->Width = 0;
	cnt = 0;
	while(string < endptr)
	{
		ch = *string;
		cnt++; string++;
		if(ch == '\n')
		{
			//max
			cnt--;
			if(sz->Width < cnt) sz->Width = cnt;
			cnt = 0;
			sz->Height++;
		}
	}
	if(sz->Width < cnt) sz->Width = cnt;
	sz->Height++;
	//convert to pixels
	sz->Height *= CHAR_H;
	sz->Width *= CHAR_W;
	return;
}



//******************* DRAW functions ************************
//get current display size
void  APIEXPORT DRAW_GetDisplaySize(LPGDATA_SIZE sz)
{
	if(RAM_sysGetFlag(SYSFLAG_DRAWORIENT)) //TFT_Landscape //Horiz = 320x240
	{
		sz->Width = TFT_SIZE_Y; sz->Height = TFT_SIZE_X; 
	}
	else //TFT_Portrait = Vert = 240x320
	{
		sz->Width = TFT_SIZE_X; sz->Height = TFT_SIZE_Y; 
	}
	return;
}

//get rectangle of all dislay
void APIEXPORT  DRAW_GetDisplayRect(LPGDATA_RECT rc)
{
	rc->X = 0;
    rc->Y = 0;
	if(RAM_sysGetFlag(SYSFLAG_DRAWORIENT)) //TFT_Landscape
	{
		rc->Width = TFT_SIZE_Y;
		rc->Height = TFT_SIZE_X; //Horiz = 320x240
	}
	else //TFT_Portrait
	{
		rc->Width = TFT_SIZE_X;
		rc->Height = TFT_SIZE_Y; //Vert = 240x320
	}
}

//set display orientation: 0 = vertical, 1 = horizontal
void APIEXPORT  DRAW_SetDisplayOrient(TFT_DisplayOrder orient)
{
	//check global display orient flag for current orient
 	if(RAM_sysGetFlag(SYSFLAG_DRAWORIENT) != orient)
	{
		RAM_sysInvertFlag(SYSFLAG_DRAWORIENT); //new orient
		TFT_SetScanOrder(orient);
	}
}

//draw rect with specified color
void  APIEXPORT DRAW_drawRect(
			  u32 x,		//X begin
			  u32 y,		//Y begin
			  u32 width,	//area width 
			  u32 height,	//area height
			  u32 color		//color
			  )
{
	//prepare coords
	u32 xx = (x+width) - 1;
	u32 yy = (height+y) - 1;

	//draw lines
	TFT_FillRect((u16)x, (u16)y, (u16)width, 1, (u16)color);			//top line
	TFT_FillRect((u16)x, (u16)yy, (u16)width, 1, (u16)color);			//bottom line
	TFT_FillRect((u16)x, (u16)y, 1, (u16)height, (u16)color);			//left
	TFT_FillRect((u16)xx, (u16)y, 1, (u16)height, (u16)color);			//right	
}

//Draw line
void  APIEXPORT DRAW_drawLine(
              u16 x1,	//The x-coordinate of the first line endpoint.
              u16 y1,	//The y-coordinate of the first line endpoint.
              u16 x2,	//The x-coordinate of the second line endpoint.
              u16 y2,	//The y-coordinate of the second line endpoint.
              u16 color	//Line color
              )
{
	s16 dx,dy,sdx,sdy,dxabs,dyabs,x,y,px,py;
	u16 i;

#define abs(X) ( ( (X) < 0 ) ? -(X) : (X) )
#define sgn(X) ( ( (X) < 0 ) ? -1 : 1 )

	if ( x1 == x2 )        /* Vertical Line*/
	{
		if ( y1 > y2 )    /* We assume y2>y1 and invert if not*/
		{
			i = y2;
			y2 = y1;
			y1 = i;
		}
		TFT_FillRect( x1, y1, 1, (y2-y1)+1, color);
		return;
	}
	else if ( y1 == y2 )  /* Horizontal Line*/
	{
		if ( x1 > x2 )   /* We assume x2>x1 and we swap them if not*/
		{
			i = x2;
			x2 = x1;
			x1 = i;
		}
		TFT_FillRect( x1, y1, (x2-x1)+1, 1, color);
		return;
	}

	dx = x2 - x1;      /* the horizontal distance of the line */
	dy = y2 - y1;      /* the vertical distance of the line */
	dxabs = abs(dx);
	dyabs = abs(dy);
	sdx = sgn(dx);
	sdy = sgn(dy);
	x = dyabs >> 1;
	y = dxabs >> 1;
	px = x1;
	py = y1;

	if (dxabs >= dyabs) /* the line is more horizontal than vertical */
	{
		for(i=0; i < dxabs; i++)
		{
			y+=dyabs;
			if (y>=dxabs)
			{
				y-=dxabs;
				py+=sdy;
			}
			px+=sdx;
			TFT_SetPixel(px,py,color);
		}
	}
	else /* the line is more vertical than horizontal */
	{
		for(i=0; i < dyabs; i++)
		{
			x+=dxabs;
			if (x>=dyabs)
			{
				x-=dyabs;
				px+=sdx;
			}
			py+=sdy;
			TFT_SetPixel(px,py,color);
		}
	}
}

//draw filled rectangle
void APIEXPORT  DRAW_FillRect(LPGDATA_RECT rc, u32 color)
{
	TFT_FillRect(rc->X, rc->Y, rc->Width, rc->Height, (u16)color);
}

//simple draw text string w/out check length
void APIEXPORT  DRAW_String(u8* str,	//string
				u32 len,	//length of string
				u32 X,   //start point of string
                u32 Y,
				u32 color,	//text color
				u32 bgcolor)//back color
{

	while(len)
	{
		TFT_WriteChar(*str, (u16)X, (u16)Y, (u16)color, (u16)bgcolor);
		str++;
		X += CHAR_W;
		len--;
	}
}

//draw part of picture in specified screen position
//szPath=full ASCIIZ path of picture file, like E:/dir/pict.mbp
//Buf=buffer for picture pixels - must be bigger than drawed width of picture
//rcPict=rectangle of drawed part of picture
//screenX=screen x coordinate of topleft drawing point
//screenY=screen y coordinate of topleft drawing point
void DRAW_PictureFile(u8* szPath, u16* Buf, GDATA_RECT* rcPict, u32 screenX, u32 screenY )
{
	//1) open file
	u32 t1, t2, t3, fpos, rowWidth, endY;
	FS_FILEINFO fi;  //open file info
	DRAW_BmpHeader* pBmph; //bitmap header
	//open file
	t1 = FSS_OpenFile(szPath, FS_READ, &fi);
	if(t1 != FS_OK)
	{
		return; // OPEN_FILE_FAIL
	}
	//2) read file header
	pBmph = (DRAW_BmpHeader*) Buf; //not use stack for bmp header data
	t1 = FSS_ReadFile(&fi, (u8*)pBmph, sizeof(DRAW_BmpHeader), &t2);
	if(t1 != FS_OK)
	{
		FSS_CloseFile(&fi);
        return; // READ_FILE_FAIL
	}
	if((pBmph->FileType != DRAW_BMP_FILE_TYPE) || (pBmph->PixelFormat != DRAW_BMP_PIXELFORMAT_565))
	{
        FSS_CloseFile(&fi);
        return; //INVALID FILE FORMAT
    }
	
	rowWidth = pBmph->Width; //file picture row size in pixels
	
	//3)loop for read and draw pixels
	//pBmph now threated as invalid
	fpos = (rcPict->Y * rowWidth) + rcPict->X;
	fpos = fpos * 2; //in bytes
	fpos = fpos + sizeof(DRAW_BmpHeader);
	endY = GDATA_rectGetEndY(rcPict);
	for(t3 = rcPict->Y; t3 < endY; t3++)
	{
		//read one row and draw on screen
		//set position offset
		FSS_SetFilePosition(&fi, fpos);
		fpos += (rowWidth * 2); //to next row pos
		//read pixels
		t1 = FSS_ReadFile(&fi, (u8*)Buf, rcPict->Width * 2, &t2);
		if(t1 != FS_OK)
		{
			FSS_CloseFile(&fi);
            return; // READ_FILE_FAIL
		}

		//draw pixels
		TFT_WriteRect(screenX, screenY, rcPict->Width, 1, Buf);
		screenY++; //to next row
	}
	
	//end 
    FSS_CloseFile(&fi);
	return;
}

//draw border with specified color
void DRAW_drawBorderAround(
			  u32 x,		//X begin
			  u32 y,		//Y begin
			  u32 width,	//area width 
			  u32 height,	//area height
			  u32 flags     //border styles  
			  )
{
	u16 color;
    //prepare coords
    x = x - 1; y = y - 1; //begin point
    width+=2; height+=2;
    //draw bottom right corner
    if((flags & DRAW_BORDER_INACTIVE) == 0)
    {
        //active state
        if(flags & DRAW_BORDER_BOTRIGHT_LIGHT) color = COLOR_White;
            else color = COLOR_Black;
    }
    else
    {
        //inactive state
        if(flags & DRAW_BORDER_BOTRIGHT_LIGHT) color = COLOR_LightGray;
            else color = COLOR_DarkGray;
    }
	TFT_FillRect((u16) x, (u16)(y + height - 1), (u16)width, 1, (u16)color);	//bottom line
	TFT_FillRect((u16)(x + width - 1), (u16)y, 1, (u16)height, (u16)color);	//right
    //draw top left corner
    if((flags & DRAW_BORDER_INACTIVE) == 0)
    {
        //active state
        if(flags & DRAW_BORDER_TOPLEFT_LIGHT) color = COLOR_White;
            else color = COLOR_Black;
    }
    else
    {
        //inactive state
        if(flags & DRAW_BORDER_TOPLEFT_LIGHT) color = COLOR_LightGray;
            else color = COLOR_DarkGray;
    }
    TFT_FillRect((u16)x, (u16)y, (u16)width, 1, (u16)color);    //top line
	TFT_FillRect((u16)x, (u16)y, 1, (u16)height, (u16)color);	//left
    return;
}



