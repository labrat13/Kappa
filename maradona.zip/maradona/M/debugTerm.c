/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for DEBUGTERM subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "debugTerm.h"
#include "strings_.h"

u32 DBG_Flag;

//FUNCTIONS

void DBG_Init()
{
	USART_InitTypeDef USART_InitStructure;
	USART_ClockInitTypeDef usacis;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	//******* USART1 config  ************************

	/* Enable USART1, GPIOA, GPIOD and AFIO clocks */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	//reinit uart for debugging
	//disable uart1 if enabled
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1, DISABLE);
	USART_Cmd(USART1, DISABLE);

	/* Configure USART1_Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure USART1_Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* USART1 configuration ------------------------------------------------------*/
	/* USART configured as follow:
	- BaudRate = 19200 baud  
	- Word Length = 8 Bits
	- One Stop Bit
	- No parity
	- Hardware flow control disabled (RTS and CTS signals)
	- Receive and transmit enabled
	*/
	USART_InitStructure.USART_BaudRate = 19200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	/* Configure USART1 */
	USART_Init(USART1, &USART_InitStructure);
	//configure clock
	usacis.USART_Clock = USART_Clock_Disable;
	usacis.USART_CPOL = USART_CPOL_Low;
	usacis.USART_CPHA = USART_CPHA_2Edge;
	usacis.USART_LastBit = USART_LastBit_Disable;

	USART_ClockInit(USART1, &usacis);//usart clock init

	//init rx interrupt
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
	/* Enable the USARTx */
	USART_Cmd(USART1, ENABLE);
}

void DBG_Exit()
{
	GPIO_InitTypeDef GPIO_InitStructure;

	//reset and disable uart, free pin's and usart clock
	USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
	//disable irq channel
	NVIC_DisableIRQ(USART1_IRQn);
	//disable uart1 if enabled
	USART_Cmd(USART1, DISABLE);
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1, DISABLE);
	//Disable USART1 clocks
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);
	//DISABLE PINS
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	return;
}

////RX interrupt subhandler 
//void DBG_CharEvent(char ch)
//{
//	DBG_putchar(ch); //for test only
//}

void  APIEXPORT DBG_putchar(u8 ch)
{
	/* Write a character to the USART */
	USART_SendData(USART1, (u8) ch);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
	{
	}
	return;
}

//send string to terminal
void  APIEXPORT DBG_printf(u8* str)
{

	while(*str != 0)
	{
		DBG_putchar(*str);
		str++;
	}
}

//send string to terminal
void  APIEXPORT DBG_printfn(u8* str, u32 len)
{
	u32 t = len;
	while(t > 0)
	{
		DBG_putchar(*str);
		str++;
		t--;
	}
}
//send value to terminal
void  APIEXPORT DBG_printval(u32 val)
{
	u32 i = 1000000000;
	u32 res;
	do
	{
		res = val / i;
		val = val % i;
		res = res + '0';
		DBG_putchar((u8)res);
		i = i / 10;
	}
	while(i > 1);
	DBG_putchar((u8)(val + '0'));
}

//send hex value to terminal
void DBG_printHex(u32 val)
{
    u32 t = val;
    u32 i = 8;
    while(i > 0)
    {
        i--;
        t = val >> (i*4); 
        DBG_putchar((u8) STRINGS_HexChar(t));   
    }
}

//print stack pointers
void DBG_printStackTop(u8* label)
{
	u32 t1, t2;
	t1 = __get_MSP();
	t2 = __get_PSP();
	DBG_printf((u8*)"Stack: ");
	DBG_printf(label);
	DBG_printf((u8*)"\r\nMSP=");
	DBG_printHex(t1);
	DBG_printf((u8*)"\r\nPSP=");
	DBG_printHex(t2);
	DBG_printf((u8*)"\r\n");
	return;
}

//print stack pointers values
void DBG_printStackMin()
{
    DBG_printf((u8*)"\r\nStack Min:");
	DBG_printf((u8*)"\r\nMSP=");
	DBG_printHex(DBG_minStackMSPValue);
	DBG_printf((u8*)"\r\nPSP=");
	DBG_printHex(DBG_minStackPSPValue);
	DBG_printf((u8*)"\r\n"); 
}
//collect stack pointers values
void DBG_addStackInfo()
{
    u32 t1;
	t1 = __get_MSP(); 
    if(DBG_minStackMSPValue > t1) DBG_minStackMSPValue = t1;
	t1 = __get_PSP(); 
    if(DBG_minStackPSPValue > t1) DBG_minStackPSPValue = t1;            
}

//dump entire ram
void DBG_printMemory()
{
	u8* ptr;
	u32 cnt,i;
    u8 t;

	ptr = (u8*) 0x20000000;
	DBG_printfn((u8*) "RAM dump:\r\n", 11);
	for(cnt = 0; cnt < 4096; cnt++) //4096 * 16 bytes = 65536
	{
		DBG_printHex((u32) ptr);
		DBG_putchar((u8) ':');
        DBG_putchar((u8) ' ');
        i = 16;
        while(i > 0)
        {
            i--;
            t = *ptr; ptr++;
            DBG_putchar((u8) STRINGS_HexChar((u32) t >> 4));
            DBG_putchar((u8) STRINGS_HexChar((u32) t));
            DBG_putchar((u8) ' ');
        }
		DBG_printfn((u8*) "\r\n", 2);
	}
	return;
}

//set debug flag value
void DBG_setFlag(u32 val)
{
    DBG_Flag = val;
}

//Print debug flag value
void DBG_printFlag()
{
   	DBG_printfn((u8*) "Flag=", 5);
    DBG_printHex((u32) DBG_Flag);
	DBG_printfn((u8*) "\r\n", 2);
    
}

