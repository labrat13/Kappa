/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for STRINGS subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "strings_.h"


//return position of specified char in string
//return string length if char not exists
//string=string
//len=length of string
//ch=searched char
u32 APIEXPORT  STRINGS_getCharPosition(u8* string, u32 len, u8 ch)
{
	u32 i;
	for(i = 0; i < len; i++)
	{
		if(*string == ch) break;
		string++;
	}
	//if ch exists. return value 0 >= i > len else return len
	return i;
}

//FUNCTIONS
u32  APIEXPORT STRINGS_strlen(u8* str)
{
    u8* s = str;
    while(*s != 0)
        s++;
    return s - str;
}

//concatenate two strings
void  APIEXPORT STRINGS_strcat(u8* dest, u8* src)
{
    //move to end of exists string
    while(*dest != 0) dest++;
    //copy src to dest
    while(*src != 0)
    {
        *dest = *src;
        dest++; src++;
    }
    *dest = 0; //ending zero
}



//Copy ASCIIZ string
void  APIEXPORT STRINGS_strcpy(u8 * Dest, u8* Src )
{
  while(*Src)
  {
    *Dest++ = *Src++;  
  }
}

//Copy n bytes from second buffer to first. 
//Fill zeroes after s2 ends. Return first buffer.
u8*  APIEXPORT STRINGS_strncpy (u8 *s1, const u8 *s2, u32 n)
{
   while((*s2 != 0) && (n > 0))
   {
      *s1 = *s2;
      s1++; s2++;
      n--;
   }
    //fill zeroes if s2 is ends
    while(n > 0)
    {
       *s1 = 0;
        n--;
    }
   return s1;   
}

//Compare two strings. Return 0 if strings are equal
s32  APIEXPORT STRINGS_strcmp( u8 * s1,  u8 * s2)
{
   while ((*s1 == *s2) && (*s1 != '\0')) 
   {
      s1++;
      s2++;
   }
   return (s32)(*s1 - *s2);
}

//get hex letter from value 0..15
u8 STRINGS_HexChar(u32 val)
{
    u32 t = val & 15;
    if(t > 9) t += 55; 
        else t += 48;
    return (u8) t;        
}


