//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for API subsystem of Maradona project
// Nov 22, 2012: refactoring
// This file for user app only, not for API.c or any item of this project
//************************************************************

#ifndef MY_API_H
#define  MY_API_H
//TODO: place header body text here
//***  PART:  DEFINITIONS  ***********************************
//from .h of system project
//TODO: ADD ITEMS HERE...

//***  PART: HUB DEFINITIONS  ***********************************
//from hub.h of system project
typedef void (*TIMERPROC)(void);
typedef void (*UARTPROC)(u8);

//TODO: ADD ITEMS HERE...

//***  PART: WND DEFINITIONS  ***********************************
//from window.h of system project
#include "msgcodes.h"

//Window Styles
#define WND_WS_TITLEBAR		1	//title bar
#define WND_WS_CLOSEBUTTON  2	//close button on title bar
#define WND_WS_VISIBLE      4	//window is visible
#define WND_WS_ENABLED		8	//window is dsabled
#define WND_WS_BORDER		16	//border
#define WND_WS_VSCROLL		32	//vertical scrollbar
#define WND_WS_HSCROLL		64	//hor scrollbar
#define WND_WS_GROUP		128 //window group nested radiobutton controls
#define WND_WS_MENUBAR		256	//menu bar

//wnd procedure pointer
typedef u32 (*WNDPROC)(PWND, u32, u16, u16);
//user concept of pwnd
typedef void* PWND;
//TODO: ADD ITEMS HERE...

//***  PART: TIME DEFINITIONS  ***********************************
//from .h of system project
//TODO: ADD ITEMS HERE...

//***  PART: TFT DEFINITIONS  ***********************************
//from .h of system project
//TODO: ADD ITEMS HERE...

//***  PART: STRINGS DEFINITIONS  ***********************************
//from .h of system project
//TODO: ADD ITEMS HERE...

//***  PART: RAM DEFINITIONS  ***********************************
//from .h of system project
//TODO: ADD ITEMS HERE...

//***  PART: FS DEFINITIONS  ***********************************
//from FS.h of system project
//TODO: ADD ITEMS HERE...

//***  PART: GDATA DEFINITIONS  ***********************************
//from gdata.h of system project

//DATATYPES
//POINT
typedef struct
{
    s16 X; //X coord
    s16 Y; //Y coord
} GDATA_POINT, *LPGDATA_POINT;

//SIZE
typedef struct 
{
    s16 Width;
    s16 Height;
} GDATA_SIZE, *LPGDATA_SIZE;

//RECTANGLE
typedef struct 
{
    u16 X;
    u16 Y;
    u16 Width;
    u16 Height;
} GDATA_RECT, *LPGDATA_RECT;

//RECTANGLE ALIGN FLAGS
#define GDATA_ALIGN_ONLY_TOP		1	//move to top by Y axis
#define GDATA_ALIGN_ONLY_MIDDLE	2	//move to center  by Y axis
#define GDATA_ALIGN_ONLY_BOTTOM	3	//move to bottom  by Y axis
#define GDATA_ALIGN_ONLY_LEFT		4	//move to left  by X axis
#define GDATA_ALIGN_ONLY_CENTER	8	//move to center  by X axis
#define GDATA_ALIGN_ONLY_RIGHT	12  //move to right   by X axis
//COMBINED FLAGS
#define GDATA_ALIGN_TOPLEFT		GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_BOTTOMLEFT	GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_TOPRIGHT	GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_BOTTOMRIGHT	GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_CENTER		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_CENTER
#define GDATA_ALIGN_LEFT		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_RIGHT		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_TOP			GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_CENTER
#define GDATA_ALIGN_BOTTOM		GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_CENTER


//***  PART: GPS DEFINITIONS  ***********************************
//from gps.h of system project
//no items
//***  PART: BACKUP DEFINITIONS  ***********************************
//from backup.h of system project

#define BACKUP_KEY_VALUE 0x55AA		//key value for checking

//backup 16-bit register mapping
#define BACKUP_REG_KEY  ((uint16_t)0x0004) //register store key value for check integrity                          
#define BACKUP_REG2                           ((uint16_t)0x0008)
#define BACKUP_REG3                           ((uint16_t)0x000C)
#define BACKUP_REG4                           ((uint16_t)0x0010)
#define BACKUP_REG5                           ((uint16_t)0x0014)
#define BACKUP_REG6                           ((uint16_t)0x0018)
#define BACKUP_REG7                           ((uint16_t)0x001C)
#define BACKUP_REG8                           ((uint16_t)0x0020)
#define BACKUP_REG9                           ((uint16_t)0x0024)
#define BACKUP_REG10                          ((uint16_t)0x0028)
#define BACKUP_REG11                          ((uint16_t)0x0040)
#define BACKUP_REG12                          ((uint16_t)0x0044)
#define BACKUP_REG13                          ((uint16_t)0x0048)
#define BACKUP_REG14                          ((uint16_t)0x004C)
#define BACKUP_REG15                          ((uint16_t)0x0050)
#define BACKUP_REG16                          ((uint16_t)0x0054)
#define BACKUP_REG17                          ((uint16_t)0x0058)
#define BACKUP_REG18                          ((uint16_t)0x005C)
#define BACKUP_REG19                          ((uint16_t)0x0060)
#define BACKUP_REG20                          ((uint16_t)0x0064)
#define BACKUP_REG21                          ((uint16_t)0x0068)
#define BACKUP_REG22                          ((uint16_t)0x006C)
#define BACKUP_REG23                          ((uint16_t)0x0070)
#define BACKUP_REG24                          ((uint16_t)0x0074)
#define BACKUP_REG25                          ((uint16_t)0x0078)
#define BACKUP_REG26                          ((uint16_t)0x007C)
#define BACKUP_REG27                          ((uint16_t)0x0080)
#define BACKUP_REG28                          ((uint16_t)0x0084)
#define BACKUP_REG29                          ((uint16_t)0x0088)
#define BACKUP_REG30                          ((uint16_t)0x008C)
#define BACKUP_REG31                          ((uint16_t)0x0090)
#define BACKUP_REG32                          ((uint16_t)0x0094)
#define BACKUP_REG33                          ((uint16_t)0x0098)
#define BACKUP_REG34                          ((uint16_t)0x009C)
#define BACKUP_REG35                          ((uint16_t)0x00A0)
#define BACKUP_REG36                          ((uint16_t)0x00A4)
#define BACKUP_REG37                          ((uint16_t)0x00A8)
#define BACKUP_REG38                          ((uint16_t)0x00AC)
#define BACKUP_REG39                          ((uint16_t)0x00B0)
#define BACKUP_REG40                          ((uint16_t)0x00B4)
#define BACKUP_REG41                          ((uint16_t)0x00B8)
#define BACKUP_REG42                          ((uint16_t)0x00BC)


//***  PART: BACKLIGHT DEFINITIONS  ***********************************
//from BLight.h of system project
//backlight bright levels - for example
#define BACKLIGHT_LEVEL_0   1		//min brightness
#define BACKLIGHT_LEVEL_1   32
#define BACKLIGHT_LEVEL_2   64
#define BACKLIGHT_LEVEL_3   96
#define BACKLIGHT_LEVEL_4   128
#define BACKLIGHT_LEVEL_5   160 
#define BACKLIGHT_LEVEL_6   192
#define BACKLIGHT_LEVEL_7   255		//max brightness

//***  PART: BUZZER DEFINITIONS  ***********************************
//from buzzer.h of system project
//no items
//***  PART: DBG DEFINITIONS  ***********************************
//from dbgTerm.h of system project
//no items
//***  PART: API DEFINITIONS  *********************************** 
//DEFINES
typedef u32 (*tAPI_Func) (void);
typedef u32 (*tAPI_Func1) (u32 p1);
typedef u32 (*tAPI_Func2) (u32 p1, u32 p2);
typedef u32 (*tAPI_Func3) (u32 p1, u32 p2, u32 p3);
typedef u32 (*tAPI_Func4) (u32 p1, u32 p2, u32 p3, u32 p4);
typedef u32 (*tAPI_Func5) (u32 p1, u32 p2, u32 p3, u32 p4, u32 p5);
typedef u32 (*tAPI_Func6) (u32 p1, u32 p2, u32 p3, u32 p4, u32 p5, u32 p6);
typedef u32 (*tAPI_Func7) (u32 p1, u32 p2, u32 p3, u32 p4, u32 p5, u32 p6, u32 p7);
typedef u32 (*tAPI_Func8) (u32 p1, u32 p2, u32 p3, u32 p4, u32 p5, u32 p6, u32 p7, u32 p8);
typedef u32 (*tAPI_Func9) (u32 p1, u32 p2, u32 p3, u32 p4, u32 p5, u32 p6, u32 p7, u32 p8, u32 p9);

extern tAPI_Func (*ptrM_API) [];	//define some extern array of pointer to function
#define M_API (*ptrM_API)			//define name as alias of this array

//GLOBAL VARIABLES

//PROTOTYPES

//BACKUP
#define	BACKUP_Read(a)					(u32)	(((tAPI_Func1)(M_API[0])) ((u32)(a)))			//u32 APIEXPORT BACKUP_Read(u32 regNo);
#define	BACKUP_Write(a, b)						(((tAPI_Func2)(M_API[1])) ((u32)(a), (u32)(b)))	//void APIEXPORT BACKUP_Write(u32 regNo, u32 val);
#define	BACKUP_isValid()				(u32)	(((tAPI_Func) (M_API[2])) ())					//u32  APIEXPORT BACKUP_isValid();
//BACKLIGHT
#define BACKLIGHT_Get()					(u32)	(((tAPI_Func) (M_API[3])) ())			//u32  APIEXPORT BACKLIGHT_Get();
#define BACKLIGHT_Set(a)						(((tAPI_Func1)(M_API[4])) ((u32)(a)))	//void  APIEXPORT BACKLIGHT_Set(u32 level);
//BUZZER
#define BUZZER_Break()							(((tAPI_Func) (M_API[5])) ())			//void  APIEXPORT BUZZER_Break();
#define BUZZER_Beep(a)							(((tAPI_Func1)(M_API[6])) ((u32)(a)))	//void  APIEXPORT BUZZER_Beep(u32 Len);
//CLOCK
//DEBUGTERM
#define DBG_putchar(a)							(((tAPI_Func1)(M_API[7])) ((u32)(a)))				//void  APIEXPORT DBG_putchar(u8 ch);
#define DBG_printf(a)							(((tAPI_Func1)(M_API[8])) ((u32)(a)))				//void  APIEXPORT DBG_printf(u8* str);
#define DBG_printfn(a, b)						(((tAPI_Func2)(M_API[9])) ((u32)(a), (u32)(b)))		//void  APIEXPORT DBG_printfn(u8* str, u32 len);
#define DBG_printval(a)							(((tAPI_Func1)(M_API[10])) ((u32)(a)))				//void  APIEXPORT DBG_printval(u32 val);
//DRAW
#define DRAW_GetStringSize(a, b, c)				(((tAPI_Func3)(M_API[11])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT DRAW_GetStringSize(u8* string, u32 stringLen, LPGDATA_SIZE sz);
#define DRAW_GetDisplaySize(a)					(((tAPI_Func1)(M_API[12])) ((u32)(a)))						//void  APIEXPORT DRAW_GetDisplaySize(LPGDATA_SIZE sz);
#define DRAW_GetDisplayRect(a)					(((tAPI_Func1)(M_API[13])) ((u32)(a)))						//void  APIEXPORT DRAW_GetDisplayRect(LPGDATA_RECT rc);
#define DRAW_SetDisplayOrient(a)				(((tAPI_Func1)(M_API[14])) ((u32)(a)))						//void  APIEXPORT DRAW_SetDisplayOrient(TFT_DisplayOrder orient);
#define DRAW_FillRect(a, b)						(((tAPI_Func2)(M_API[15])) ((u32)(a), (u32)(b)))				//void  APIEXPORT DRAW_FillRect(LPGDATA_RECT rc, u32 color);
#define DRAW_drawLine(a, b, c, d, e)			(((tAPI_Func5)(M_API[16])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))			//void  APIEXPORT DRAW_drawLine(u16 x1, u16 y1, u16 x2 u16 y2, u16 color );
#define DRAW_drawRect(a, b, c, d)				(((tAPI_Func4)(M_API[17])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d)))						//void  APIEXPORT DRAW_drawRect(u32 x, u32 y, u32 u32, u32 color );
#define DRAW_String(a, b, c, d, e, f)			(((tAPI_Func6)(M_API[18])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e), (u32)(f)))	//void  APIEXPORT DRAW_String(u8* str,u32 len,	u32 X, u32 Y,u32, u32 bgcolor);

//GDATA
#define GDATA_rectGetEndX(a)				(u32)	(((tAPI_Func1)(M_API[19])) ((u32)(a)))						//u32  APIEXPORT GDATA_rectGetEndX(LPGDATA_RECT rc);
#define GDATA_rectGetEndY(a)				(u32)	(((tAPI_Func1)(M_API[20])) ((u32)(a)))						//u32  APIEXPORT GDATA_rectGetEndY(LPGDATA_RECT rc);
#define GDATA_rectPtInRect(a, b, c)			(u32)	(((tAPI_Func3)(M_API[21])) ((u32)(a), (u32)(b), (u32)(c)))	//u32  APIEXPORT GDATA_rectPtInRect(LPGDATA_RECT rc, u32 x, u32 y);
#define GDATA_rectPtInRect2(a, b)			(u32)	(((tAPI_Func2)(M_API[22])) ((u32)(a), (u32)(b)))				//u32  APIEXPORT GDATA_rectPtInRect2(LPGDATA_RECT rc, LPGDATA_POINT pt);
#define GDATA_rectRectInRect(a, b)			(u32)	(((tAPI_Func2)(M_API[23])) ((u32)(a), (u32)(b)))				//u32  APIEXPORT GDATA_rectRectInRect(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner);
#define GDATA_rectSetSize(a, b)						(((tAPI_Func2)(M_API[24])) ((u32)(a), (u32)(b)))				//void  APIEXPORT GDATA_rectSetSize(LPGDATA_RECT rc, LPGDATA_SIZE sz);
#define GDATA_rectSetPoint(a, b)					(((tAPI_Func2)(M_API[25])) ((u32)(a), (u32)(b)))				//void  APIEXPORT GDATA_rectSetPoint(LPGDATA_RECT rc, LPGDATA_POINT pt);
#define GDATA_rectSetRect(a, b, c, d, e)			(((tAPI_Func5)(M_API[26])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))	//void  APIEXPORT GDATA_rectSetRect(LPGDATA_RECT rc, u32 x, u32 y, u32 width, u32 height);
#define GDATA_rectAlign(a, b, c)					(((tAPI_Func3)(M_API[27])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT GDATA_rectAlign(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner, u32 alignMode);
//EXTMMC

//FS
#define FS_Mount(a, b)							(u32)(((tAPI_Func2)(M_API[28])) ((u32)(a), (u32)(b)))									//u32  APIEXPORT FS_Mount(FS_CardDevice device, u8* scratchbuffer);
#define FS_Unmount(a)							(u32)(((tAPI_Func1)(M_API[29])) ((u32)(a)))												//u32  APIEXPORT FS_Unmount(FS_CardDevice device);
#define FS_ReadSector(a, b, c)					(u32)(((tAPI_Func3)(M_API[30])) ((u32)(a), (u32)(b), (u32)(c)))							//u32  APIEXPORT FS_ReadSector(u32 unit, u8 *buffer, u32 sector);
#define FS_WriteSector(a, b, c)					(u32)(((tAPI_Func3)(M_API[31])) ((u32)(a), (u32)(b), (u32)(c)))							//u32  APIEXPORT FS_WriteSector(u32 unit, u8 *buffer, u32 sector);
#define FS_GetPtnStart(a, b, c, d, e, f)		(u32)(((tAPI_Func6)(M_API[32])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e), (u32)(f)))	//u32  APIEXPORT FS_GetPtnStart(u32 unit, u8 *scratchsector, u32 pnum, u8 *pactive, u8 *pptype, u32 *psize);
#define FS_GetVolInfo(a, b, c, d)				(u32)(((tAPI_Func4)(M_API[33])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d)))				//u32  APIEXPORT FS_GetVolInfo(u32 unit, u8 *scratchsector, u32 startsector, PFS_VOLINFO volinfo);
#define FS_OpenDir(a, b, c)						(u32)(((tAPI_Func3)(M_API[34])) ((u32)(a), (u32)(b), (u32)(c)))							//u32  APIEXPORT FS_OpenDir(PFS_VOLINFO volinfo, u8 * dirname, PFS_DIRINFO dirinfo);
#define FS_GetNext(a, b, c)						(u32)(((tAPI_Func3)(M_API[35])) ((u32)(a), (u32)(b), (u32)(c)))							//u32  APIEXPORT FS_GetNext(PFS_VOLINFO volinfo, PFS_DIRINFO dirinfo, PFS_DIRENT dirent);
#define FS_OpenFile(a, b, c, d, e)				(u32)(((tAPI_Func5)(M_API[36])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))		//u32  APIEXPORT FS_OpenFile(PFS_VOLINFO volinfo, u8 *path, u32 mode, u8 *scratch, PFS_FILEINFO fileinfo);
#define FS_ReadFile(a, b, c, d, e)				(u32)(((tAPI_Func5)(M_API[37])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))		//u32  APIEXPORT FS_ReadFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);
#define FS_WriteFile(a, b, c, d, e)				(u32)(((tAPI_Func5)(M_API[38])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))		//u32  APIEXPORT FS_WriteFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);
#define FS_Seek(a, b, c)						(u32)(((tAPI_Func2)(M_API[39])) ((u32)(a), (u32)(b), (u32)(c)))							//void  APIEXPORT FS_Seek(PFS_FILEINFO fileinfo, u32 offset, u8 *scratch);
#define FS_UnlinkFile(a, b, c)					(u32)(((tAPI_Func3)(M_API[40])) ((u32)(a), (u32)(b), (u32)(c)))							//u32  APIEXPORT FS_UnlinkFile(PFS_VOLINFO volinfo, u8 *path, u8 *scratch);
//GPS 
#define GPS_SendMsg(a)						(((tAPI_Func1)(M_API[41])) ((u32)(a)))		//void  APIEXPORT GPS_SendMsg(u8* msg);
#define GPS_isEnabled()				(u32)	(((tAPI_Func) (M_API[42])) ())				//u32  APIEXPORT GPS_isEnabled();
#define GPS_Enable(a)						(((tAPI_Func1)(M_API[43])) ((u32)(a)))		//void  APIEXPORT GPS_Enable(u32 State);
#define GPS_Exit()							(((tAPI_Func) (M_API[44])) ())				//void  APIEXPORT GPS_Exit();
#define GPS_Init()							(((tAPI_Func) (M_API[45])) ())				//void  APIEXPORT GPS_Init();
//HUB

//INTERRUPTS
//INTMMC
//LOADER
//MATH
#define MATH_power2(a)			(u32)	(((tAPI_Func1)(M_API[46])) ((u32)(a)))		// u32  APIEXPORT MATH_power2(u32 num); 
//POWER
//RAM
#define RAM_getSysClockMode()			(u32)	(((tAPI_Func) (M_API[47])) ())								//u32  APIEXPORT RAM_getSysClockMode();
#define RAM_memZero(a, b)						(((tAPI_Func2)(M_API[48])) ((u32)(a), (u32)(b)))				//void  APIEXPORT RAM_memZero(u8* addr, u32 size);
#define RAM_memFill(a, b, c)					(((tAPI_Func3)(M_API[49])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT RAM_memFill(u8* addr, u8 value, u32 size)
#define RAM_memCopy(a, b, c)					(((tAPI_Func3)(M_API[50])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT RAM_memCopy(u8* dest, u8* src, u32 size);
#define RAM_memComp(a, b, c)			(s32)	(((tAPI_Func3)(M_API[51])) ((u32)(a), (u32)(b), (u32)(c)))	//s32  APIEXPORT RAM_memComp(u8* s1, u8* s2, u32 n)
#define RAM_memAlloc(a, b)				(u32)	(((tAPI_Func2)(M_API[52])) ((u32)(a), (u32)(b)))				//u8*  APIEXPORT RAM_memAlloc(u32 size, u32 tag);
#define RAM_memAllocFill(a, b, c)		(u32)	(((tAPI_Func3)(M_API[53])) ((u32)(a), (u32)(b), (u32)(c)))	//u8*  APIEXPORT RAM_memAllocFill(u32 size,u32 tag, u8 value);
#define RAM_memFree(a)							(((tAPI_Func1)(M_API[54])) ((u32)(a)))						//void  APIEXPORT RAM_memFree(u8* addr);
#define RAM_memFreeByTag(a, b)			(u32)	(((tAPI_Func2)(M_API[55])) ((u32)(a), (u32)(b)))				//u32  APIEXPORT RAM_memFreeByTag(u32 tag, u32 del);
#define RAM_ListInit(a)							(((tAPI_Func1)(M_API[56])) ((u32)(a)))						//void  APIEXPORT RAM_ListInit(PRAM_ListItem ListBase);
#define RAM_ListGetLength(a)			(u32)	(((tAPI_Func1)(M_API[57])) ((u32)(a)))						//u32  APIEXPORT RAM_ListGetLength(PRAM_ListItem ListBase);
#define RAM_ListInsertRight(a, b, c)			(((tAPI_Func3)(M_API[58])) ((u32)(a), (u32)(b), (u32)(c)))	///void  APIEXPORT RAM_ListInsertRight(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem);
#define RAM_ListInsertLeft(a, b, c)				(((tAPI_Func3)(M_API[59])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT RAM_ListInsertLeft(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem);
#define RAM_ListRemoveItem(a, b)				(((tAPI_Func2)(M_API[60])) ((u32)(a), (u32)(b)))				//void APIEXPORT  RAM_ListRemoveItem(PRAM_ListItem ListBase, PRAM_ListItem delItem);
#define RAM_ListClear(a)						(((tAPI_Func1)(M_API[61])) ((u32)(a)))						//void  APIEXPORT RAM_ListClear(PRAM_ListItem ListBase);
#define RAM_ListGetTopLeft(a)			(u32)	(((tAPI_Func1)(M_API[62])) ((u32)(a)))						//PRAM_ListItem  APIEXPORT RAM_ListGetTopLeft(PRAM_ListItem ListBase);
#define RAM_ListGetBottomRight(a)		(u32)	(((tAPI_Func1)(M_API[63])) ((u32)(a)))						//PRAM_ListItem  APIEXPORT RAM_ListGetBottomRight(PRAM_ListItem ListBase);
#define RAM_ListGetByIndex(a, b)		(u32)	(((tAPI_Func2)(M_API[64])) ((u32)(a), (u32)(b)))				//PRAM_ListItem  APIEXPORT RAM_ListGetByIndex(PRAM_ListItem ListBase, u32 index);
#define RAM_BitmaskCalcSize(a, b)		(u32)	(((tAPI_Func2)(M_API[65])) ((u32)(a), (u32)(b)))				//u32  APIEXPORT RAM_BitmaskCalcSize(u32 width, u32 height);
#define RAM_BitmaskInit(a, b, c)				(((tAPI_Func2)(M_API[66])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT RAM_BitmaskInit(u8* bitmask, u32 width, u32 height);
#define RAM_BitmaskGet(a, b, c)			(u32)	(((tAPI_Func3)(M_API[67])) ((u32)(a), (u32)(b), (u32)(c)))	//u32  APIEXPORT RAM_BitmaskGet(u8* bitmask, u32 x, u32 y);
#define RAM_BitmaskSet(a, b, c)					(((tAPI_Func3)(M_API[68])) ((u32)(a), (u32)(b), (u32)(c)))	//void  APIEXPORT RAM_BitmaskSet(u8* bitmask, u32 x, u32 y);
#define RAM_getTimestamp()				(u32)	(((tAPI_Func) (M_API[69])) ())								//u32 APIEXPORT  RAM_getTimestamp()
//STRINGS
#define STRINGS_strlen(a)					(u32)	(((tAPI_Func1)(M_API[70])) ((u32)(a)))						//u32  APIEXPORT STRINGS_strlen(u8* str);
#define STRINGS_strcat(a, b)						(((tAPI_Func2)(M_API[71])) ((u32)(a), (u32)(b)))				//void  APIEXPORT STRINGS_strcat(u8* dest, u8* src);
#define STRINGS_strcpy(a, b)						(((tAPI_Func2)(M_API[72])) ((u32)(a), (u32)(b)))				//void  APIEXPORT STRINGS_strcpy(u8 * Dest, u8* Src );
#define STRINGS_strncpy(a, b, c)			(u32)	(((tAPI_Func3)(M_API[73])) ((u32)(a), (u32)(b), (u32)(c)))	//u8*  APIEXPORT STRINGS_strncpy (u8 *s1, const u8 *s2, u32 n);
#define STRINGS_strcmp(a, b)				(s32)	(((tAPI_Func2)(M_API[74])) ((u32)(a), (u32)(b)))				//s32  APIEXPORT STRINGS_strcmp( u8 * s1,  u8 * s2);
#define STRINGS_getCharPosition(a, b, c)	(u32)	(((tAPI_Func3)(M_API[75])) ((u32)(a), (u32)(b), (u32)(c)))	//u32  APIEXPORT STRINGS_getCharPosition(u8* string, u32 len, u8 ch);
//TFT
#define TFT_FillRect(a, b, c, d, e)				(((tAPI_Func5)(M_API[76])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))	//void  APIEXPORT TFT_FillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color);
#define TFT_SetPixel(a, b, c)					(((tAPI_Func3)(M_API[77])) ((u32)(a), (u32)(b), (u32)(c)))						//void  APIEXPORT TFT_SetPixel(u16 x, u16 y, u16 color);
#define TFT_ReadRect(a, b, c, d, e)				(((tAPI_Func5)(M_API[78])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))	//void  APIEXPORT TFT_ReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf);
#define TFT_WriteRect(a, b, c, d, e)			(((tAPI_Func5)(M_API[79])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))	//void  APIEXPORT TFT_WriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf);
#define TFT_WriteChar(a, b, c, d, e)			(((tAPI_Func5)(M_API[80])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e)))	//void  APIEXPORT TFT_WriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor);
#define TFT_fontGetChar(a)				(u32)	(((tAPI_Func1)(M_API[81])) ((u32)(a)))											//u8*  APIEXPORT TFT_fontGetChar(u8 ch);
//TIME
#define TIME_delay_ms(a)						(((tAPI_Func1)(M_API[82])) ((u32)(a)))		//void  APIEXPORT TIME_delay_ms(vu32 ms);
//TOUCH
#define TOUCH_getVbatMv()				(u32)	(((tAPI_Func) (M_API[83])) ())		//u32  APIEXPORT TOUCH_getVbatMv()
#define TOUCH_getVrefMv()				(u32)	(((tAPI_Func) (M_API[84])) ())		//u32  APIEXPORT TOUCH_getVrefMv()
#define TOUCH_getTemperature()			(s32)	(((tAPI_Func) (M_API[85])) ())		//s32  APIEXPORT TOUCH_getTemperature()
//HUB
#define HUB_SetTimer1msHandler(a)				(((tAPI_Func1)(M_API[86])) ((u32)(a)))			//void  APIEXPORT HUB_SetTimer1msHandler(u32 addr);
#define HUB_SetDbgEventHandler(a)				(((tAPI_Func1)(M_API[87])) ((u32)(a)))			//void  APIEXPORT HUB_SetDbgEventHandler(u32 addr);
#define HUB_SetGpsEventHandler(a)				(((tAPI_Func1)(M_API[88])) ((u32)(a)))			//void  APIEXPORT HUB_SetGpsEventHandler(u32 addr);
#define HUB_PostMessage(a, b, c, d)		(u32)	(((tAPI_Func4)(M_API[89])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d)))	//u32  APIEXPORT HUB_PostMessage(PWND wnd, u32 msgCode, u32 valX, u32 valY);
#define HUB_GetMessage(a, b, c, d)		(u32)	(((tAPI_Func4)(M_API[90])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d)))	//u32  APIEXPORT HUB_GetMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax);
#define HUB_DispatchMessage(a)			(u32)	(((tAPI_Func1)(M_API[91])) ((u32)(a)))			//u32  APIEXPORT HUB_DispatchMessage(PHUB_MSG pMsg);
//WND
#define WND_RegisterClass(a, b, c)		(u32)	(((tAPI_Func3)(M_API[92])) ((u32)(a), (u32)(b), (u32)(c)))		//u32  APIEXPORT WND_RegisterClass(u32 hInstance, WNDPROC lpfnProc, u32 classStyle);
#define WND_UnregisterClass(a)			(u32)	(((tAPI_Func1)(M_API[93])) ((u32)(a)))							//u32 APIEXPORT  WND_UnregisterClass(u32 classId);
#define WND_CreateWindow(a,b,c,d,e,f,g,h,i)	(u32)	(((tAPI_Func9)(M_API[94])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d), (u32)(e), (u32)(f), (u32)(g), (u32)(h), (u32)(i)))	//PWND  APIEXPORT WND_CreateWindow(u32 classId, u32 Style, u32 X, u32 Y, u32 Width, u32 Height, PWND pWndParent, u32 pMenu, u32 hInstance);
#define WND_EnableWindow(a, b)					(((tAPI_Func2)(M_API[95])) ((u32)(a), (u32)(b)))				//void  APIEXPORT WND_EnableWindow(PWND pWnd, u32 enable);
#define WND_ShowWindow(a, b)					(((tAPI_Func2)(M_API[96])) ((u32)(a), (u32)(b)))				//void  APIEXPORT WND_ShowWindow(PWND pWnd, u32 show);
#define WND_GetClientRect(a, b)					(((tAPI_Func2)(M_API[97])) ((u32)(a), (u32)(b)))				//void  APIEXPORT WND_GetClientRect(PWND pWnd, LPGDATA_RECT pRect);
#define WND_UpdateWindow(a)						(((tAPI_Func1)(M_API[98])) ((u32)(a)))							//void  APIEXPORT WND_UpdateWindow(PWND pWnd);
//added later
#define HUB_SendMessage(a, b, c, d)     (u32)	(((tAPI_Func4)(M_API[99])) ((u32)(a), (u32)(b), (u32)(c), (u32)(d)))	//u32 APIEXPORT HUB_SendMessage(PWND pWnd, u32 Msg, u32 paramX, u32 paramY);
#define WND_DestroyWindow(a)			(u32)	(((tAPI_Func1)(M_API[100]))((u32)(a)))							//u32  APIEXPORT WND_DestroyWindow(PWND pWnd);








#endif // MY_API_H