/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "FS.h"
#include "ram_.h"
#include "loader_.h"
#include "debugTerm.h"

typedef struct _LOADER_ElfHeader {
	unsigned char e_ident[16]; //0-15
	unsigned short e_type;		//16-17
	unsigned short e_machine;	//18-19
	unsigned int e_version;		//20-23
	unsigned int e_entry;		//24-27
	unsigned int e_phoff;		//28-31
	unsigned int e_shoff;		//32-35
	unsigned int e_flags;		//36-39
	unsigned short e_ehsize;	//40-41
	unsigned short e_phentsize;	//42-43
	unsigned short e_phnum;		//44-45
	unsigned short e_shentsize;	//46-47
	unsigned short e_shnum;		//48-49
	unsigned short e_shstrndx;	//50-51
} LOADER_ELFHEADER, *P_LOADER_ELFHEADER;

typedef struct _LOADER_ElfSegmentHeader {
	unsigned int p_type;	//0
	unsigned int p_offset;	//4
	unsigned int p_vaddr;		//8
	unsigned int p_paddr;		//12
	unsigned int p_filesz;		//16
	unsigned int p_memsz;		//20
	unsigned int p_flags;		//24
	unsigned int p_align;	//28
}LOADER_ELFSEGHEADER, *P_LOADER_ELFSEGHEADER;



#define LOADER_APPMEMORY_START  0x2000c000
#define LOADER_APPMEMORY_END	0x20010000 

//FUNCTIONS
//init module
void LOADER_Init()
{

}
//exit module
void LOADER_Exit()
{
}




//Load program file. Return error code
//Caller must use defined entrypoint for execute file
//this function consume stack, thus not execute entrypoint directly
//szPath = elf file pathname like I:/dir/file.elf
//readBuf = buffer 64 bytes for reading file
//return = error code
u32 LOADER_Load(u8* szPath, u8* readBuf)
{
	//1) open file
	u32 t1, t2, t3;
	s32 s1, s2;
	FS_FILEINFO fi;  //open file info
	//open file
	t1 = FSS_OpenFile(szPath, FS_READ, &fi);
	if(t1 != FS_OK)
	{
		return LOADER_FILE_FAIL;
	}
	//2) read elf header 
	t1 = FSS_ReadFile(&fi, readBuf, 64, &t2);
	if(t1 != FS_OK)
	{
		FSS_CloseFile(&fi);
		return LOADER_FILE_FAIL;
	}
	//3) check header
    u32* ptr = (u32*)readBuf;
    if((*ptr != 0x464c457f) || (*(ptr+1) != 0x00010101) || (*(ptr+4) != 0x00280002)) 
	// if((readBuf[0] != 0x7F) || (readBuf[1] != 0x45) ||(readBuf[2] != 0x4c) ||(readBuf[3] != 0x46)
		// ||(readBuf[4] != 0x01) ||(readBuf[5] != 0x01) ||(readBuf[6] != 0x01)
		// || (peh->e_type != 2) | (peh->e_machine != 0x28))
	{
		FSS_CloseFile(&fi);
		return LOADER_FORMAT_FAIL;
	}
	//4)get entry, numofsegments, segmentoffsetfile
    P_LOADER_ELFHEADER peh = (P_LOADER_ELFHEADER) readBuf;
	u32 numOfSegments = peh->e_phnum;
	t3 = peh->e_phoff;
	//5)read all loadable segment
	//set file position
	FSS_SetFilePosition(&fi, t3); //to e_phoff
	//read segment structure and find first loadable segment
	P_LOADER_ELFSEGHEADER psh = (P_LOADER_ELFSEGHEADER) readBuf;
	u32 filePos;
    u8* devPtr;
	while(numOfSegments > 0)
	{
		numOfSegments--;
		t1 = FSS_ReadFile(&fi, readBuf, 32, &t3); //32 = sizeof(ELFSEGHEADER)
		if(t1 != FS_OK)
		{
			FSS_CloseFile(&fi);
			return LOADER_FILE_FAIL;
		}
		//check loadable
		if(psh->p_type != 1)//PT_LOAD = loadable segment
			continue; //to next segment
		//load segment
        //store current file position in variable for next segment
		filePos = fi.pointer; 
		//6)get p_vaddr, p_memsz, p_offset, p_filesz
		//if segment begin not in 0x2000C000, cut this image
        devPtr = (u8*) psh->p_vaddr; //start address of segment
		s1 = (s32)LOADER_APPMEMORY_START - psh->p_vaddr; //size of cutting
		if(s1 < 0) s1 = 0; //if segment begin after 0x2000c000, don't cut segment image 		
		//set file position to begin of data
		FSS_SetFilePosition(&fi, psh->p_offset + s1);
		t2 = psh->p_filesz - s1; //num of bytes to copy
        devPtr = devPtr + s1;   //devPtr as begin of cutted segment
		s2 = psh->p_memsz - psh->p_filesz; //num of bytes to add after 
		//7)copy data from file to memory
		t3 = t2 / 512; //while counter in 512 bytes blocks
		u32 t4; //for successcount
		while(t3 > 0)
		{
			t1 = FSS_ReadFile(&fi, devPtr, 512, &t4); //read from file to application segment of chip memory
			if(t1 != FS_OK)
			{
				FSS_CloseFile(&fi);
				return LOADER_FILE_FAIL;
			}
			devPtr += 512;
			t3--;
		}
		//load reminder of 512
		t3 = t2 & 0x1ff; //t2 % 512
		if(t3 > 0)
		{
			t1 = FSS_ReadFile(&fi, devPtr, t3, &t4); //
			if(t1 != FS_OK)
			{
				FSS_CloseFile(&fi);
				return LOADER_FILE_FAIL;
			}
			devPtr += t3;
		}
		//8)add bss data if need
		RAM_memZero(devPtr, (u32)s2);
		//restore file position for next segment in table
		//if not last segment, seek filePos
		if(numOfSegments > 0)//saving time for last segment
			FSS_SetFilePosition(&fi, filePos);
		//go next segment
	} //end of segment's load

	//close file session
	FSS_CloseFile(&fi);
	//11)return success
	return LOADER_SUCCESS;
}

//Load elf program file. Return error code
//Caller must use defined entrypoint for execute file
//this function consume stack, thus not execute entrypoint directly
//szPath = elf file pathname
//return = error code
u32 LOADER_Load2(u8* szPath)
{
	u32 t1;
    //create buffer 64 for sector read
	u8* readBuf = RAM_memAlloc(64, RAM_TAG_LOADER); 
	if(readBuf == 0) 
	{
		t1 = LOADER_ALLOC_FAIL;
        goto exit_0;
	}
	//DBG_printfn((u8*)"W", 1);
    //load file
	t1 = LOADER_Load(szPath, readBuf);
	//free resources
exit_0:   
	RAM_memFree(readBuf);		

	return t1;
}

//Execute loaded application and return result
//Arg0 = buffer or string
//Arg1 = number
//return = application result
inline u32 LOADER_Execute(u8* Arg0, u32 Arg1)
{
	//application entry point address must be in 0x2000c000 memory location
	u32* ptr = (u32*) (LOADER_APPMEMORY_START);
	//application entry point input buffer and value, return value.
	u32(*pFunc)(u8*, u32) = (u32 (*)(u8*, u32)) *ptr;
	return pFunc(Arg0, Arg1);
}



