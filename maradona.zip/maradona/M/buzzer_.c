/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "buzzer_.h"

//INTERNAL VARIABLES
u16 BUZZER_Counter;

//FUNCTIONS
#define BUZZER_PIN  GPIO_Pin_4

//init buzzer resources
void BUZZER_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    BUZZER_Counter = 0;
    //init PA4 pin
    //enable PA clock and power- if not enabled already
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin =  BUZZER_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; //??? for one pin or for all port?
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    //clear line
    GPIO_ResetBits(GPIOA, BUZZER_PIN);
    return;
}

//deinit buzzer resources
void BUZZER_Exit()
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    //BUZZER_Counter = 0;
    //deinit PA4 pin
    //clear line
    //GPIO_ResetBits(GPIOA, BUZZER_PIN);
    BUZZER_Break(); //counter=0; pin=0;
    //not disable PA clock and power
    GPIO_InitStructure.GPIO_Pin = BUZZER_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; //??? for one pin or for all port?
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    return;    
}

//NT-routine for SYSTICK interrupt
void BUZZER_Routine()
{
    if(BUZZER_Counter > 0)
    {
        BUZZER_Counter--;
        if((BUZZER_Counter & 1) == 0) //PA4 = 0 else PA4 = 1
        {
            GPIO_ResetBits(GPIOA, BUZZER_PIN);
        } else {
            GPIO_SetBits(GPIOA, BUZZER_PIN);
        }
    }
    return;
}

//NT-Stop playing sound, buzzer off
void  APIEXPORT BUZZER_Break()
{
    BUZZER_Counter = 0;
    GPIO_ResetBits(GPIOA, BUZZER_PIN);
    return;
}

//NT-Play sound for Len millisecond, max 65 seconds
void  APIEXPORT BUZZER_Beep(u32 Len)
{
    BUZZER_Counter = (u16)Len;
    return;
}