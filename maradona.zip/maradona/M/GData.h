//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for GDATA subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_GDATA_H
#define  MY_GDATA_H


#include "stm32f10x.h"
#include "types.h"

//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//point for display coords
typedef struct
{
    s16 X; //X coord
    s16 Y; //Y coord
} GDATA_POINT, *LPGDATA_POINT;

typedef struct 
{
    s16 Width;
    s16 Height;
} GDATA_SIZE, *LPGDATA_SIZE;

typedef struct 
{
    u16 X;
    u16 Y;
    u16 Width;
    u16 Height;
} GDATA_RECT, *LPGDATA_RECT;

//PUBLIC DEFINES
#define GDATA_ALIGN_ONLY_TOP		1	//move to top by Y axis
#define GDATA_ALIGN_ONLY_MIDDLE	2	//move to center  by Y axis
#define GDATA_ALIGN_ONLY_BOTTOM	3	//move to bottom  by Y axis
#define GDATA_ALIGN_ONLY_LEFT		4	//move to left  by X axis
#define GDATA_ALIGN_ONLY_CENTER	8	//move to center  by X axis
#define GDATA_ALIGN_ONLY_RIGHT	12  //move to right   by X axis
//COMBINED FLAGS
#define GDATA_ALIGN_TOPLEFT		GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_BOTTOMLEFT	GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_TOPRIGHT	GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_BOTTOMRIGHT	GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_CENTER		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_CENTER
#define GDATA_ALIGN_LEFT		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_LEFT
#define GDATA_ALIGN_RIGHT		GDATA_ALIGN_ONLY_MIDDLE	| GDATA_ALIGN_ONLY_RIGHT
#define GDATA_ALIGN_TOP			GDATA_ALIGN_ONLY_TOP		| GDATA_ALIGN_ONLY_CENTER
#define GDATA_ALIGN_BOTTOM		GDATA_ALIGN_ONLY_BOTTOM	| GDATA_ALIGN_ONLY_CENTER

//GLOBAL VARIABLES

//PROTOTYPES
u32  APIEXPORT GDATA_rectGetEndX(LPGDATA_RECT rc);
u32  APIEXPORT GDATA_rectGetEndY(LPGDATA_RECT rc);
u32  APIEXPORT GDATA_rectPtInRect(LPGDATA_RECT rc, u32 x, u32 y);
u32  APIEXPORT GDATA_rectPtInRect2(LPGDATA_RECT rc, LPGDATA_POINT pt);
u32  APIEXPORT GDATA_rectRectInRect(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner);
void  APIEXPORT GDATA_rectSetSize(LPGDATA_RECT rc, LPGDATA_SIZE sz);
void  APIEXPORT GDATA_rectSetPoint(LPGDATA_RECT rc, LPGDATA_POINT pt);
void  APIEXPORT GDATA_rectSetRect(LPGDATA_RECT rc, u32 x, u32 y, u32 width, u32 height);
void  APIEXPORT GDATA_rectAlign(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner, u32 alignMode);



#endif // MY_GDATA_H