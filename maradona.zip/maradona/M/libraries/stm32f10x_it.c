/**
******************************************************************************
* @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
* @author  MCD Application Team
* @version V3.4.0
* @date    10/15/2010
* @brief   Main Interrupt Service Routines.
*          This file provides template for all exceptions handler and 
*          peripherals interrupt service routine.
******************************************************************************
* @copy
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
*/ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x_rtc.h"
#include "debugTerm.h"
#include "buzzer_.h"
#include "touch_.h"
#include "ram_.h" //for StampCounter 
#include "gps_.h" //for usart3 routine
#include "extMMC.h" //for SDIO routine
#include "hub.h" //for event consuming

/** @addtogroup STM32F10x_StdPeriph_Template
* @{
*/

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
* @brief   This function handles NMI exception.
* @param  None
* @retval None
*/
void NMI_Handler(void)__attribute__((__interrupt__));
void NMI_Handler(void)
{
	DBG_printfn((u8*)"#N", 2);
}

/**
* @brief  This function handles Hard Fault exception.
* @param  None
* @retval None
*/
void HardFault_Handler(void)__attribute__((__interrupt__));
void HardFault_Handler(void)
{
	/* Go to infinite loop when Hard Fault exception occurs */
	DBG_printfn((u8*)"#H", 2);
	DBG_printFlag();
	DBG_printMemory();
	HUB_DebugOutQueue();
	while (1)
	{
	}
}

/**
* @brief  This function handles Memory Manage exception.
* @param  None
* @retval None
*/
void MemManage_Handler(void)__attribute__((__interrupt__));
void MemManage_Handler(void)
{
	/* Go to infinite loop when Memory Manage exception occurs */
	DBG_printfn((u8*)"#M", 2);
	while (1)
	{
	}
}

/**
* @brief  This function handles Bus Fault exception.
* @param  None
* @retval None
*/
void BusFault_Handler(void) __attribute__((__interrupt__));
void BusFault_Handler(void)
{
	/* Go to infinite loop when Bus Fault exception occurs */
	DBG_printfn((u8*)"#B", 2);
	while (1)
	{
	}
}

/**
* @brief  This function handles Usage Fault exception.
* @param  None
* @retval None
*/
void UsageFault_Handler(void) __attribute__((__interrupt__));
void UsageFault_Handler(void)
{
	/* Go to infinite loop when Usage Fault exception occurs */
	DBG_printfn((u8*)"#U", 2);
	while (1)
	{
	}
}

/**
* @brief  This function handles SVCall exception.
* @param  None
* @retval None
*/
void SVC_Handler(void) __attribute__((__interrupt__));
void SVC_Handler(void)
{
	DBG_printfn((u8*)"#S", 2);
}

/**
* @brief  This function handles Debug Monitor exception.
* @param  None
* @retval None
*/
void DebugMon_Handler(void) __attribute__((__interrupt__));
void DebugMon_Handler(void)
{
	DBG_printfn((u8*)"#D", 2);
}

/**
* @brief  This function handles PendSVC exception.
* @param  None
* @retval None
*/
void PendSV_Handler(void) __attribute__((__interrupt__));
void PendSV_Handler(void)
{
	DBG_printfn((u8*)"#P", 2);
}

/**
* @brief  This function handles SysTick Handler.
* @param  None
* @retval None
*/
void SysTick_Handler(void) __attribute__((__interrupt__));
void SysTick_Handler(void)
{
	//1mS interval
	BUZZER_Routine(); //for buzzer work
	RAM_StampCounter++; //free overflow counter
	TOUCH_AdcTouchRoutine();
	if((RAM_StampCounter & 15)==0) 
		ADC_SoftwareStartInjectedConvCmd(ADC1, ENABLE);//software start adc1 16mS
	//...
    //process all events
    HUB_SystickProcessEvents();
    DBG_addStackInfo(); //TODO: STACK info collect 
    return;
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_Maradona.c).                                            */
/******************************************************************************/
void RTC_IRQHandler(void)__attribute__((__interrupt__));
void RTC_IRQHandler(void)
{
	if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
	{
		/* Clear the RTC Second interrupt */
		NVIC_ClearPendingIRQ(RTC_IRQn);
		RTC_ClearITPendingBit(RTC_IT_SEC);

		//do something here
		//DBG_printfn("RTC", 3);
        HUB_putTime1sEvent();
		/* Wait until last write operation on RTC registers has finished */
		//RTC_WaitForLastTask(); do not wait for slow device!!!
	}
}

void RTCAlarm_IRQHandler(void) __attribute__((__interrupt__));
void RTCAlarm_IRQHandler(void)
{
	/* Clear the Alarm Pending Bit */
	RTC_ClearITPendingBit(RTC_IT_ALR);
	//NVIC_ClearPendingIRQ(RTCAlarm_IRQn);    TODO: id not found

	//do something here
	//DBG_printfn("RTA", 3);
    HUB_putAlarmEvent();

	/* Wait until last write operation on RTC registers has finished */
	//RTC_WaitForLastTask(); do not wait for slow device!!!
}

void ADC_IRQHandler(void)__attribute__((__interrupt__));
//ADC1 for Vref Vbat Temp
void ADC_IRQHandler(void)
{
	//call routine
	TOUCH_AdcVoltRoutine();
    
}

void USART1_IRQHandler(void)__attribute__((__interrupt__));
void USART1_IRQHandler(void)
{
	u8 ch;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) == RESET) return;

	/* Read one byte from the receive data register */
	ch = USART_ReceiveData(USART1);
	//DBG_CharEvent(ch);
	HUB_putDbgEvent(ch);
	return;
}

void USART3_IRQHandler(void) __attribute__((__interrupt__));
void USART3_IRQHandler(void)
{
	u8 ch;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) == RESET) return;

	/* Read one byte from the receive data register */
	ch = USART_ReceiveData(USART3);
	//GPS_CharEvent(ch);
	HUB_putGpsEvent(ch);
	return;
}

void SDIO_IRQHandler(void) __attribute__((__interrupt__));
void SDIO_IRQHandler(void)
{
	EXTMMC_ProcessIRQSrc();
    DBG_addStackInfo(); //TODO: STACK info collect
}

/**
* @}
*/ 


/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
