/****************** (C) COPYRIGHT 2007-2009 Raisonance S.A.S ******************/
/**
*
* @file     MS_hw_config.c
* @brief    Hardware Configuration & Setup for Mass storage USB
* @author   ST MCD Application Team + Raisonance
* @date     02/2009
*
**/
/******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "circle.h"
#include "stm32f10x_it.h"
#include "MS_hw_config.h"
#include "sdcard.h"
#include "platform_config.h"
#include "mass_mal.h"
#include "usb_desc.h"
#include "usb_pwr.h"
#include "usb_istr.h"
#include "usb_int.h"
#include "dosfs.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define NODEBUG __attribute__ ((section(".non_debuggable_code")))

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
ErrorStatus HSEStartUpStatus;

/* Extern variables ----------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : Set_System
* Description    : Configures Main system clocks & power
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_SetSystem(void)
{

  /* RCC configuration */
  // RCC_Config();

   /* Select PLL as system clock source */
   RCC_SYSCLKConfig( RCC_SYSCLKSource_HSE );

   /* Enable PLL */
   RCC_PLLCmd( DISABLE );
   
   /* PLLCLK = 12MHz * 6 = 72 MHz */
   RCC_PLLConfig( RCC_PLLSource_HSE_Div1, RCC_PLLMul_6 );

   /* Enable PLL */
   RCC_PLLCmd( ENABLE );

   /* Wait till PLL is ready */
   while( RCC_GetFlagStatus( RCC_FLAG_PLLRDY ) == RESET )
      { ; }

   /* Select PLL as system clock source */
   RCC_SYSCLKConfig( RCC_SYSCLKSource_PLLCLK );

   /* Wait till PLL is used as system clock source */
   while( RCC_GetSYSCLKSource() != 0x08 )
      { ; }

  /* Enable and GPIOD clock */
  USB_Disconnect_Config();

  /* MAL configuration */
  USB_MALConfig();
}

/*******************************************************************************
* Function Name  : Set_USBClock
* Description    : Configures USB Clock input (48MHz)
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_SetClock(void)
{
  /* Select USBCLK source */
  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);

  /* Enable USB clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
}

/*******************************************************************************
* Function Name  : Enter_LowPowerMode
* Description    : Power-off system clocks and power while entering suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_Enter_LowPowerMode(void)
{
  /* Set the device state to suspend */
  bDeviceState = SUSPENDED;
}

/*******************************************************************************
* Function Name  : Leave_LowPowerMode
* Description    : Restores system clocks and power while exiting suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_Leave_LowPowerMode(void)
{
  DEVICE_INFO *pInfo = &Device_Info;

  /* Set the device state to the correct state */
  if (pInfo->Current_Configuration != 0)
  {
    /* Device configured */
    bDeviceState = CONFIGURED;
  }
  else
  {
    bDeviceState = ATTACHED;
  }

}

/*******************************************************************************
* Function Name  : USB_Interrupts_Config
* Description    : Configures the USB interrupts
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_Interrupts_Config(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  NVIC_InitStructure.NVIC_IRQChannel = USB_HP_CAN1_TX_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  NVIC_InitStructure.NVIC_IRQChannel = SDIO_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

}

/*******************************************************************************
* Function Name  : USB_Interrupts_Stop.
* Description    : Stop the USB interrupts.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void USB_Interrupts_Stop(void)
   {
   NVIC_InitTypeDef NVIC_InitStructure;
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

   NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3; //FL071018 0
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
   NVIC_Init(&NVIC_InitStructure);

   //Stop USB
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, DISABLE);  
   }


/*******************************************************************************
* Function Name  : USB_Cable_Config
* Description    : Software Connection/Disconnection of USB Cable.
* Input          : None.
* Return         : Status
*******************************************************************************/
NODEBUG void USB_Cable_Config (FunctionalState NewState)
{
  if (NewState != DISABLE)
  {
    GPIO_ResetBits(USB_DISCONNECT, USB_DISCONNECT_PIN);
  }
  else
  {
    GPIO_SetBits(USB_DISCONNECT, USB_DISCONNECT_PIN);
  }
}

/*******************************************************************************
* Function Name  : Get_SerialNum.
* Description    : Create the serial number string descriptor.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_GetSerialNum(void)
{
  u32 Device_Serial0, Device_Serial1, Device_Serial2;

  Device_Serial0 = *(vu32*)(0x1FFFF7E8);
  Device_Serial1 = *(vu32*)(0x1FFFF7EC);
  Device_Serial2 = *(vu32*)(0x1FFFF7F0);

  if (Device_Serial0 != 0)
  {
    MASS_StringSerial[2] = (u8)(Device_Serial0 & 0x000000FF);
    MASS_StringSerial[4] = (u8)((Device_Serial0 & 0x0000FF00) >> 8);
    MASS_StringSerial[6] = (u8)((Device_Serial0 & 0x00FF0000) >> 16);
    MASS_StringSerial[8] = (u8)((Device_Serial0 & 0xFF000000) >> 24);

    MASS_StringSerial[10] = (u8)(Device_Serial1 & 0x000000FF);
    MASS_StringSerial[12] = (u8)((Device_Serial1 & 0x0000FF00) >> 8);
    MASS_StringSerial[14] = (u8)((Device_Serial1 & 0x00FF0000) >> 16);
    MASS_StringSerial[16] = (u8)((Device_Serial1 & 0xFF000000) >> 24);

    MASS_StringSerial[18] = (u8)(Device_Serial2 & 0x000000FF);
    MASS_StringSerial[20] = (u8)((Device_Serial2 & 0x0000FF00) >> 8);
    MASS_StringSerial[22] = (u8)((Device_Serial2 & 0x00FF0000) >> 16);
    MASS_StringSerial[24] = (u8)((Device_Serial2 & 0xFF000000) >> 24);
  }
}


/*******************************************************************************
* Function Name  : MAL_Config
* Description    : MAL_layer configuration
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_MALConfig(void)
{
  MAL_Init(0);
}

/*******************************************************************************
* Function Name  : USB_Disconnect_Config
* Description    : Disconnect pin configuration
* Input          : None.
* Return         : None.
*******************************************************************************/
NODEBUG void USB_Disconnect_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /* Enable GPIO clock */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);
    /* PD.03 used as USB pull-up (disconnect)*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

}

/* Public functions ---------------------------------------------------------*/

/*******************************************************************************
*
*                                Fct_Download_Ini
*
*******************************************************************************/
/**
*  Initialization of the SDCard in Mass storage mode.
*
*  @retval  MENU_CONTINUE_COMMAND.
*
**/
/******************************************************************************/
__attribute__ ((section(".non_debuggable_code")))
enum MENU_code Fct_Download_Ini( void )
    {
    
    static const u16 bmpComputer [] = {
    #include "bmp\Computer-32x32.h"
    };

    // Presence SDCard test
    if ( FS_Mount(MMCSD_SDIO) == 0xFFFFFFFF )
      {
      MENU_Print("No SDCARD");
      }
    else
        {   
        /* Disable TIM2 (MEMS + I2C) interrupt */
        BUZZER_SetMode( BUZZER_OFF );
        TIM_ITConfig( TIM2, TIM_IT_Update, DISABLE );

        USB_SetSystem();
        USB_SetClock();
        USB_Interrupts_Config();
        USB_Init();

        LCD_FillRect ( 0,0,128,128, RGB_WHITE );
        
        DRAW_SetImage( bmpComputer, 48, 80, 32, 32);

        DRAW_SetCursorPos( 5, 60);
        DRAW_Puts("Connect USB to PC\n");
        DRAW_Puts("and navigate.\n\n");
        DRAW_Puts("Push button when\nfinished...");
        }

    return MENU_CONTINUE_COMMAND;
    }

/*******************************************************************************
*
*                                Fct_Download_Handler
*
*******************************************************************************/
/**
*  Wait for the end of mass storage mode by user.
*
*  @retval  MENU_CONTINUE or MENU_LEAVE when finished.
*
**/
/******************************************************************************/
__attribute__ ((section(".non_debuggable_code")))
enum MENU_code Fct_Download_Handler( void )
    {
    
        // When the user pushedthe button, it's time to leave!
    if(  BUTTON_GetState() == BUTTON_PUSHED_FORMAIN )
        {
        //Stop the USB
        USB_Cable_Config(DISABLE);

        //Stop the USB IRQ
        USB_Interrupts_Stop() ;

        /* Restore TIM2 (MEMS + I2C) interrupt */
        TIM_ITConfig( TIM2, TIM_IT_Update, ENABLE );

        return fQuit();
        }
      return MENU_CONTINUE;
    }


/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
