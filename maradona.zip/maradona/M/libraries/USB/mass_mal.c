/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : mass_mal.c
* Author             : MCD Application Team
* Version            : V2.2.1
* Date               : 09/22/2008
* Description        : Medium Access Layer interface
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "platform_config.h"
#include "sdcard.h"
#include "mass_mal.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define NODEBUG __attribute__ ((section(".non_debuggable_code")))

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
u32 Mass_Memory_Size[2];
u32 Mass_Block_Size[2];
u32 Mass_Block_Count[2];
vu32 MassStatus = 0;


SD_CardInfo SDCardInfo;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : MAL_Init
* Description    : Initializes the Media on the STM32
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
NODEBUG u16 MAL_Init(u8 lun)
{
  u16 status = MAL_OK;

  switch (lun)
  {
    case 0:
      MassStatus = SD_Init();
      MassStatus = SD_GetCardInfo(&SDCardInfo);
      MassStatus = SD_SelectDeselect((u32) (SDCardInfo.RCA << 16));
      MassStatus = SD_EnableWideBusOperation(SDIO_BusWide_4b);
      MassStatus = SD_SetDeviceMode(SD_DMA_MODE);
      break;
    default:
      return MAL_FAIL;
  }
  return status;
}
/*******************************************************************************
* Function Name  : MAL_Write
* Description    : Write sectors
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
NODEBUG u16 MAL_Write(u8 lun, u32 Memory_Offset, u32 *Writebuff, u16 Transfer_Length)
{

  switch (lun)
  {
    case 0:
      MassStatus = SD_WriteBlock(Memory_Offset, Writebuff, Transfer_Length);
      if ( MassStatus != SD_OK )
      {
        return MAL_FAIL;
      }      

      break;
    default:
      return MAL_FAIL;
  }
  return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_Read
* Description    : Read sectors
* Input          : None
* Output         : None
* Return         : Buffer pointer
*******************************************************************************/
NODEBUG u16 MAL_Read(u8 lun, u32 Memory_Offset, u32 *Readbuff, u16 Transfer_Length)
{

  switch (lun)
  {
    case 0:
      MassStatus = SD_ReadBlock(Memory_Offset, Readbuff, Transfer_Length);
      if ( MassStatus != SD_OK )
      {
        return MAL_FAIL;
      }
      break;
    default:
      return MAL_FAIL;
  }
  return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_GetStatus
* Description    : Get status
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
NODEBUG u16 MAL_GetStatus (u8 lun)
{

  u32 DeviceSizeMul = 0, NumberOfBlocks = 0;



  if (lun == 0)
  {
    if (SD_Init() == SD_OK)
    {
      SD_GetCardInfo(&SDCardInfo);
      SD_SelectDeselect((u32) (SDCardInfo.RCA << 16));
      DeviceSizeMul = (SDCardInfo.SD_csd.DeviceSizeMul + 2);

      if(SDCardInfo.CardType == SDIO_HIGH_CAPACITY_SD_CARD)
      {
        Mass_Block_Count[0] = (SDCardInfo.SD_csd.DeviceSize + 1) * 1024;
      }
      else
      {
        NumberOfBlocks  = ((1 << (SDCardInfo.SD_csd.RdBlockLen)) / 512);
        Mass_Block_Count[0] = ((SDCardInfo.SD_csd.DeviceSize + 1) * (1 << DeviceSizeMul) << (NumberOfBlocks/2));
      }
      Mass_Block_Size[0]  = 512;

      MassStatus = SD_SelectDeselect((u32) (SDCardInfo.RCA << 16)); 
      MassStatus = SD_EnableWideBusOperation(SDIO_BusWide_4b); 
      if ( MassStatus != SD_OK )
      {
        return MAL_FAIL;
      }
       
      MassStatus = SD_SetDeviceMode(SD_DMA_MODE);         
      if ( MassStatus != SD_OK )
      {
        return MAL_FAIL;
      } 
     
      Mass_Memory_Size[0] = Mass_Block_Count[0] * Mass_Block_Size[0];
//      GPIO_SetBits(USB_LED_PORT, GPIO_Pin_7);
      return MAL_OK;


    }

  }

 // GPIO_ResetBits(USB_LED_PORT, GPIO_Pin_7);
  return MAL_FAIL;
}

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/
