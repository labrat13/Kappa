//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for SHELL subsystem of Maradona project
// Jan 4, 2013: initial
// Main application for system

//************************************************************

#ifndef MY_SHELL_H
#define  MY_SHELL_H

#include "stm32f10x.h"
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif

u32 SHELL_Init();
void SHELL_Exit();

























#endif // MY_SHELL_H