//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for MATH subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_MATH_H
#define  MY_MATH_H

#include "stm32f10x.h" //project data types
//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//PROTOTYPES
u32  APIEXPORT MATH_power2(u32 num); //Returns the power of two for specified number

//NR-test coord calculation
void TestMathCoord();

#endif // MY_MATH_H