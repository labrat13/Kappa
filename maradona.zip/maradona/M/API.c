/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES

#include "ram_.h"
#include "FS.h"
#include "buzzer_.h"
#include "BLight.h"
#include "debugTerm.h"
#include "gps_.h"
#include "Math_.h"
#include "strings_.h"
#include "time_.h"
#include "TFT_.h"
#include "GData.h"
#include "touch_.h"
#include "backup.h"
#include "draw_.h"
#include "hub.h"
#include "window.h"

typedef u32 (*tAPI_Func) (void);//pointer to function


//FUNCTIONS
//Main array of pointers to exported functions
const tAPI_Func M_API[] = 
{
	//����� ������� ��������� � ����� �������, ��������� �������� 0.
	//����� ��������� ���������� ����� ���������� ��������������� ������� ��� �������. 
	//BACKUP
	(tAPI_Func)	BACKUP_Read,				//[0]u32 APIEXPORT BACKUP_Read(u32 regNo);
	(tAPI_Func)	BACKUP_Write,				//void APIEXPORT BACKUP_Write(u32 regNo, u32 val);
	(tAPI_Func)	BACKUP_isValid,				//u32  APIEXPORT BACKUP_isValid();
	//BACKLIGHT
	(tAPI_Func) BACKLIGHT_Get,				//u32  APIEXPORT BACKLIGHT_Get();
	(tAPI_Func) BACKLIGHT_Set,				//void  APIEXPORT BACKLIGHT_Set(u32 level);
	//BUZZER
	(tAPI_Func) BUZZER_Break,				//[5]void  APIEXPORT BUZZER_Break();
	(tAPI_Func) BUZZER_Beep,				//void  APIEXPORT BUZZER_Beep(u32 Len);
	//DEBUGTERM
	(tAPI_Func) DBG_putchar,				//void  APIEXPORT DBG_putchar(u8 ch);
	(tAPI_Func) DBG_printf,					//void  APIEXPORT DBG_printf(u8* str);
	(tAPI_Func) DBG_printfn,				//void  APIEXPORT DBG_printfn(u8* str, u32 len);
	(tAPI_Func) DBG_printval,				//[10]void  APIEXPORT DBG_printval(u32 val);
	//DRAW
	(tAPI_Func) DRAW_GetStringSize,			//void  APIEXPORT DRAW_GetStringSize(u8* string, u32 stringLen, LPGDATA_SIZE sz);
	(tAPI_Func) DRAW_GetDisplaySize,		//void  APIEXPORT DRAW_GetDisplaySize(LPGDATA_SIZE sz);
	(tAPI_Func) DRAW_GetDisplayRect,		//void  APIEXPORT DRAW_GetDisplayRect(LPGDATA_RECT rc);
	(tAPI_Func) DRAW_SetDisplayOrient,		//void  APIEXPORT DRAW_SetDisplayOrient(TFT_DisplayOrder orient);
	(tAPI_Func) DRAW_FillRect,				//[15]void  APIEXPORT DRAW_FillRect(LPGDATA_RECT rc, u32 color);
	(tAPI_Func) DRAW_drawLine,				//void  APIEXPORT DRAW_drawLine(u16 x1, u16 y1, u16 x2 u16 y2, u16 color );
	(tAPI_Func) DRAW_drawRect,				//void  APIEXPORT DRAW_drawRect(u32 x, u32 y, u32 u32, u32 color );
	(tAPI_Func) DRAW_String,				//void  APIEXPORT DRAW_String(u8* str,u32 len,	u32 X, u32 Y,u32, u32 bgcolor);
	//GDATA
	(tAPI_Func) GDATA_rectGetEndX,			//u32  APIEXPORT GDATA_rectGetEndX(LPGDATA_RECT rc);
	(tAPI_Func) GDATA_rectGetEndY,			//[20]u32  APIEXPORT GDATA_rectGetEndY(LPGDATA_RECT rc);
	(tAPI_Func) GDATA_rectPtInRect,			//u32  APIEXPORT GDATA_rectPtInRect(LPGDATA_RECT rc, u32 x, u32 y);
	(tAPI_Func) GDATA_rectPtInRect2,		//u32  APIEXPORT GDATA_rectPtInRect2(LPGDATA_RECT rc, LPGDATA_POINT pt);
	(tAPI_Func) GDATA_rectRectInRect,		//u32  APIEXPORT GDATA_rectRectInRect(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner);
	(tAPI_Func) GDATA_rectSetSize,			//void  APIEXPORT GDATA_rectSetSize(LPGDATA_RECT rc, LPGDATA_SIZE sz);
	(tAPI_Func) GDATA_rectSetPoint,			//[25]void  APIEXPORT GDATA_rectSetPoint(LPGDATA_RECT rc, LPGDATA_POINT pt);
	(tAPI_Func) GDATA_rectSetRect,			//void  APIEXPORT GDATA_rectSetRect(LPGDATA_RECT rc, u32 x, u32 y, u32 width, u32 height);
	(tAPI_Func) GDATA_rectAlign,			//void  APIEXPORT GDATA_rectAlign(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner, u32 alignMode);
	//FS
	(tAPI_Func) FS_Mount,					//u32  APIEXPORT FS_Mount(FS_CardDevice device, u8* scratchbuffer);
	(tAPI_Func) FS_Unmount,					//u32  APIEXPORT FS_Unmount(FS_CardDevice device);
	(tAPI_Func) FS_ReadSector,				//[30]u32  APIEXPORT FS_ReadSector(u32 unit, u8 *buffer, u32 sector);
	(tAPI_Func) FS_WriteSector,				//u32  APIEXPORT FS_WriteSector(u32 unit, u8 *buffer, u32 sector);
	(tAPI_Func) FS_GetPtnStart,				//u32  APIEXPORT FS_GetPtnStart(u32 unit, u8 *scratchsector, u32 pnum, u8 *pactive, u8 *pptype, u32 *psize);
	(tAPI_Func) FS_GetVolInfo,				//u32  APIEXPORT FS_GetVolInfo(u32 unit, u8 *scratchsector, u32 startsector, PFS_VOLINFO volinfo);
	(tAPI_Func) FS_OpenDir,					//u32  APIEXPORT FS_OpenDir(PFS_VOLINFO volinfo, u8 * dirname, PFS_DIRINFO dirinfo);
	(tAPI_Func) FS_GetNext,					//[35]u32  APIEXPORT FS_GetNext(PFS_VOLINFO volinfo, PFS_DIRINFO dirinfo, PFS_DIRENT dirent);
	(tAPI_Func) FS_OpenFile,				//u32  APIEXPORT FS_OpenFile(PFS_VOLINFO volinfo, u8 *path, u32 mode, u8 *scratch, PFS_FILEINFO fileinfo);
	(tAPI_Func) FS_ReadFile,				//u32  APIEXPORT FS_ReadFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);
	(tAPI_Func) FS_WriteFile,				//u32  APIEXPORT FS_WriteFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);
	(tAPI_Func) FS_Seek,					//void  APIEXPORT FS_Seek(PFS_FILEINFO fileinfo, u32 offset, u8 *scratch);
	(tAPI_Func) FS_UnlinkFile,				//[40]u32  APIEXPORT FS_UnlinkFile(PFS_VOLINFO volinfo, u8 *path, u8 *scratch);
	//GPS 
	(tAPI_Func) GPS_SendMsg,				//void  APIEXPORT GPS_SendMsg(u8* msg);
	(tAPI_Func) GPS_isEnabled,				//u32  APIEXPORT GPS_isEnabled();
	(tAPI_Func) GPS_Enable,					//void  APIEXPORT GPS_Enable(u32 State);
	(tAPI_Func) GPS_Exit,					//void  APIEXPORT GPS_Exit();
	(tAPI_Func) GPS_Init,					//[45]void  APIEXPORT GPS_Init();
	//MATH
	(tAPI_Func) MATH_power2,				//u32  APIEXPORT MATH_power2(u32 num); 
	//RAM
	(tAPI_Func) RAM_getSysClockMode,		//u32  APIEXPORT RAM_getSysClockMode();
	(tAPI_Func) RAM_memZero,				//void  APIEXPORT RAM_memZero(u8* addr, u32 size);
	(tAPI_Func) RAM_memFill,				//void  APIEXPORT RAM_memFill(u8* addr, u8 value, u32 size)
	(tAPI_Func) RAM_memCopy,				//[50]void  APIEXPORT RAM_memCopy(u8* dest, u8* src, u32 size);
	(tAPI_Func) RAM_memComp,				//s32  APIEXPORT RAM_memComp(u8* s1, u8* s2, u32 n)
	(tAPI_Func) RAM_memAlloc,				//u8*  APIEXPORT RAM_memAlloc(u32 size, u32 tag);
	(tAPI_Func) RAM_memAllocFill,			//u8*  APIEXPORT RAM_memAllocFill(u32 size,u32 tag, u8 value);
	(tAPI_Func) RAM_memFree,				//void  APIEXPORT RAM_memFree(u8* addr);
	(tAPI_Func) RAM_memFreeByTag,			//[55]u32  APIEXPORT RAM_memFreeByTag(u32 tag, u32 del);
	(tAPI_Func) RAM_ListInit,				//void  APIEXPORT RAM_ListInit(PRAM_ListItem ListBase);
	(tAPI_Func) RAM_ListGetLength,			//u32  APIEXPORT RAM_ListGetLength(PRAM_ListItem ListBase);
	(tAPI_Func) RAM_ListInsertRight,		//void  APIEXPORT RAM_ListInsertRight(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem);
	(tAPI_Func) RAM_ListInsertLeft,			//void  APIEXPORT RAM_ListInsertLeft(PRAM_ListItem ListBase, PRAM_ListItem anchorItem, PRAM_ListItem newItem);
	(tAPI_Func) RAM_ListRemoveItem,			//[60]void APIEXPORT  RAM_ListRemoveItem(PRAM_ListItem ListBase, PRAM_ListItem delItem);
	(tAPI_Func) RAM_ListClear,				//void  APIEXPORT RAM_ListClear(PRAM_ListItem ListBase);
	(tAPI_Func) RAM_ListGetTopLeft,			//PRAM_ListItem  APIEXPORT RAM_ListGetTopLeft(PRAM_ListItem ListBase);
	(tAPI_Func) RAM_ListGetBottomRight,		//PRAM_ListItem  APIEXPORT RAM_ListGetBottomRight(PRAM_ListItem ListBase);
	(tAPI_Func) RAM_ListGetByIndex,			//PRAM_ListItem  APIEXPORT RAM_ListGetByIndex(PRAM_ListItem ListBase, u32 index);
	(tAPI_Func) RAM_BitmaskCalcSize,		//[65]u32  APIEXPORT RAM_BitmaskCalcSize(u32 width, u32 height);
	(tAPI_Func) RAM_BitmaskInit,			//void  APIEXPORT RAM_BitmaskInit(u8* bitmask, u32 width, u32 height);
	(tAPI_Func) RAM_BitmaskGet,				//u32  APIEXPORT RAM_BitmaskGet(u8* bitmask, u32 x, u32 y);
	(tAPI_Func) RAM_BitmaskSet,				//void  APIEXPORT RAM_BitmaskSet(u8* bitmask, u32 x, u32 y);
	(tAPI_Func) RAM_getTimestamp,			//u32 APIEXPORT  RAM_getTimestamp()
	//STRINGS
	(tAPI_Func) STRINGS_strlen,				//[70]u32  APIEXPORT STRINGS_strlen(u8* str);
	(tAPI_Func) STRINGS_strcat,				//void  APIEXPORT STRINGS_strcat(u8* dest, u8* src);
	(tAPI_Func) STRINGS_strcpy,				//void  APIEXPORT STRINGS_strcpy(u8 * Dest, u8* Src );
	(tAPI_Func) STRINGS_strncpy,			//u8*  APIEXPORT STRINGS_strncpy (u8 *s1, const u8 *s2, u32 n);
	(tAPI_Func) STRINGS_strcmp,				//s32  APIEXPORT STRINGS_strcmp( u8 * s1,  u8 * s2);
	(tAPI_Func) STRINGS_getCharPosition,    //[75]u32  APIEXPORT STRINGS_getCharPosition(u8* string, u32 len, u8 ch);
	//TFT
	(tAPI_Func) TFT_FillRect,				//void  APIEXPORT TFT_FillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color);
	(tAPI_Func) TFT_SetPixel,				//void  APIEXPORT TFT_SetPixel(u16 x, u16 y, u16 color);
	(tAPI_Func) TFT_ReadRect,				//void  APIEXPORT TFT_ReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf);
	(tAPI_Func) TFT_WriteRect,				//void  APIEXPORT TFT_WriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf); 
	(tAPI_Func) TFT_WriteChar,				//[80]void  APIEXPORT TFT_WriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor);
	(tAPI_Func) TFT_fontGetChar,			//u8*  APIEXPORT TFT_fontGetChar(u8 ch);
	//TIME
	(tAPI_Func) TIME_delay_ms,				//void  APIEXPORT TIME_delay_ms(vu32 ms);
	//TOUCH
	(tAPI_Func) TOUCH_getVbatMv,			//u32  APIEXPORT TOUCH_getVbatMv()
	(tAPI_Func) TOUCH_getVrefMv,			//u32  APIEXPORT TOUCH_getVrefMv()
	(tAPI_Func) TOUCH_getTemperature,		//[85]s32  APIEXPORT TOUCH_getTemperature()    
	//HUB
	(tAPI_Func) HUB_SetTimer1msHandler,		//void  APIEXPORT HUB_SetTimer1msHandler(u32 addr);
	(tAPI_Func) HUB_SetDbgEventHandler,		//void  APIEXPORT HUB_SetDbgEventHandler(u32 addr);
	(tAPI_Func) HUB_SetGpsEventHandler,		//void  APIEXPORT HUB_SetGpsEventHandler(u32 addr);
	(tAPI_Func) HUB_PostMessage,			//u32  APIEXPORT HUB_PostMessage(PWND wnd, u32 msgCode, u32 valX, u32 valY);
	(tAPI_Func) HUB_GetMessage,				//u32  APIEXPORT HUB_GetMessage(PHUB_MSG pMsg, PWND pWnd, u32 msgFilterMin, u32 msgFilterMax);
	(tAPI_Func) HUB_DispatchMessage,		//u32  APIEXPORT HUB_DispatchMessage(PHUB_MSG pMsg);
	//WND
	(tAPI_Func) WND_RegisterClass,		//u32  APIEXPORT WND_RegisterClass(u32 hInstance, WNDPROC lpfnProc, u32 classStyle);
	(tAPI_Func) WND_UnregisterClass,    //u32 APIEXPORT  WND_UnregisterClass(u32 classId);
	(tAPI_Func) WND_CreateWindow,		//PWND  APIEXPORT WND_CreateWindow(u32 classId, u32 Style, u32 X, u32 Y, u32 Width, u32 Height, PWND pWndParent, u32 pMenu, u32 hInstance);
	(tAPI_Func) WND_EnableWindow,		//void  APIEXPORT WND_EnableWindow(PWND pWnd, u32 enable);
	(tAPI_Func) WND_ShowWindow,			//void  APIEXPORT WND_ShowWindow(PWND pWnd, u32 show);
	(tAPI_Func) WND_GetClientRect,		//void  APIEXPORT WND_GetClientRect(PWND pWnd, LPGDATA_RECT pRect);
	(tAPI_Func) WND_UpdateWindow,		//void  APIEXPORT WND_UpdateWindow(PWND pWnd);
	//added later
    (tAPI_Func) HUB_SendMessage,        //u32 APIEXPORT HUB_SendMessage(PWND pWnd, u32 Msg, u32 paramX, u32 paramY);
    (tAPI_Func) WND_DestroyWindow,        //u32  APIEXPORT WND_DestroyWindow(PWND pWnd);
    
	
	
	
	//USB
	//EXTMMC
	//CLOCK
	//INTERRUPTS
	//INTMMC
	//LOADER
	//POWER
	//(tAPI_Func) ,    //
	//(tAPI_Func) ,    //
	//(tAPI_Func) ,    //
	(tAPI_Func) 0    //Last element, remove after all be ready

};