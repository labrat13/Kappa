/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for WND subsystem of Maradona project
// Dec 22, 2012: initial


***********************************************************/

//INCLUDES
#include "ram_.h"
#include "hub.h"
#include "debugTerm.h"
#include "window.h"
#include "GData.h"


//DEFINES



//PRIVATE VARIABLES
RAM_ListItem WND_ClassesListHeader;	//header for window class list
RAM_ListItem WND_WndListHeader;			//header for window list
u16 WND_ClassCounter;		//counter of classes - for new class id
u16 WND_WindowCounter;      //counter of new window - for new window id

//PRIVATE DECLARATION
PWND_WndClassListItem WND_findClassItem(u32 classId);
PWND WND_findWndItem(u32 wndId);
//FUNCTIONS
u32 WND_Init()
{
	WND_ClassCounter = 1; //for now, no predefined classes here
	WND_WindowCounter = 1; //for now, no predefined windows here
	//init lists
	RAM_ListInit(&WND_ClassesListHeader);
	RAM_ListInit(&WND_WndListHeader);

	return 0;
}

void WND_Exit()
{

}

//NR-register window class
//hInstance=application instance id
//lpfnProc=window handler address
//classStyle=window class style flags
//return=0 if error memalloc; class id if success
u32  APIEXPORT WND_RegisterClass(u32 hInstance, WNDPROC lpfnProc, u32 classStyle)
{
	//������� ������� ������, ����������� ������, �������� � ������, ������� ���������� ������������� ������
	PWND_WndClassListItem pItem = (PWND_WndClassListItem) RAM_memAlloc(sizeof(WND_WndClassListItem), RAM_TAG_WND);
	if(pItem == 0) return 0; //error memalloc
	//copy data
	pItem->ClassId = WND_ClassCounter;
	WND_ClassCounter++;
	pItem->hInstance = (u16) hInstance;
	pItem->lpfnWndProc = lpfnProc;
	pItem->Style = (u16) classStyle;
	//add to list to left
	RAM_ListInsertLeft(&WND_ClassesListHeader, &WND_ClassesListHeader, (PRAM_ListItem)pItem);
	//return class id
	return pItem->ClassId;
}

//NT- get class item by id
//return=0 if not founded, item otherwise
PWND_WndClassListItem WND_findClassItem(u32 classId)
{
	PWND_WndClassListItem pBase = (PWND_WndClassListItem)&WND_ClassesListHeader;
	PWND_WndClassListItem pItem = pBase;
	while((pItem = (PWND_WndClassListItem)RAM_ListGetTopLeft((PRAM_ListItem)pItem)) != pBase)
	{
		if(pItem->ClassId == classId)
					break;
	}
	if(pItem == pBase) return 0;
	else return pItem;
}

//NR-unregister class 
//return 0 if any windows of this class still exists, or class not found
//return !0 if success
u32  APIEXPORT WND_UnregisterClass(u32 classId)
{
	//find and remove class item from class list by classid and instance
	PWND_WndClassListItem pItem = WND_findClassItem(classId);
	if(pItem == 0) return 0;
	RAM_ListRemoveItem(&WND_ClassesListHeader, (PRAM_ListItem)pItem);
    return 1;
}

//NT-create window
//classId=window class identifier
//Style=window styles
//X=window x pos
//Y=window Y pos
//Width=window width
//Height=window height
//pWndParent=window parent window
//pMenu=window menu object
//hInstance=app instance
//return pWnd if success; 0 if any errors
PWND  APIEXPORT WND_CreateWindow(u32 classId, u32 Style, u32 X, u32 Y, u32 Width, u32 Height, PWND pWndParent, u32 pMenu, u32 hInstance)
{
	//create list item
	PWND_WndListItem pItem = (PWND_WndListItem) RAM_memAlloc(sizeof(WND_WndListItem), RAM_TAG_WND);
	if(pItem == 0) return 0; //error memalloc
	//find class
	PWND_WndClassListItem pClassItem = WND_findClassItem(classId);
	if(pClassItem == 0) return 0;
	//copy data
	pItem->pClass = pClassItem;
	pItem->hInstance = hInstance;
	pItem->hMenu = pMenu;
	pItem->pWndParent = pWndParent; 
	pItem->WindowId = (u16)WND_WindowCounter;
	WND_WindowCounter++;
	pItem->WindowStyle = (u16)Style;
	pItem->wndRect.X = (u16)X;
	pItem->wndRect.Y = (u16)Y;
	pItem->wndRect.Width = (u16)Width;
	pItem->wndRect.Height = (u16)Height;
	pItem->Value = 0; //window value - pointer to text or bitmap or any other
	//add to list to left
	RAM_ListInsertLeft(&WND_WndListHeader, &WND_WndListHeader, (PRAM_ListItem) pItem);
	//return window id
	return pItem;
}

////NT- get window item by id
////return=0 if not founded, item otherwise
//PWND WND_findWndItem(u32 wndId)
//{
//	PWND_WndListItem pBase = (PWND_WndListItem)&WND_WndListHeader;
//	PWND_WndListItem pItem = 0;
//	//find by id
//	while((pItem = (PWND_WndListItem) RAM_ListGetTopLeft((PRAM_ListItem)pItem)) != pBase)
//	{
//		if(pItem->WindowId == wndId)
//			break;
//	}
//	if(pItem == pBase) return 0;
//	else return pItem;
//}

//NT-set window visibility
//pWnd=window
//show=0 - hide; !0 - show
void  APIEXPORT WND_ShowWindow(PWND pWnd, u32 show)
{
	//set window style for visibility
	if(show) pWnd->WindowStyle = pWnd->WindowStyle | WND_WS_VISIBLE;
	else pWnd->WindowStyle = pWnd->WindowStyle & (~WND_WS_VISIBLE);
	//if window is top window, make it active
	if(pWnd->pWndParent == 0)
		if(show) 
			HUB_setActiveWindow(pWnd);

}
//NT-set window enabled
//pWnd=window
//enable=0 - disable; !0 - enable
void  APIEXPORT WND_EnableWindow(PWND pWnd, u32 enable)
{
	if(enable) pWnd->WindowStyle = pWnd->WindowStyle | WND_WS_ENABLED;
	else pWnd->WindowStyle = pWnd->WindowStyle & (~WND_WS_ENABLED);
}

//NT-update specified window
void  APIEXPORT WND_UpdateWindow(PWND pWnd)
{
	//send message MSG_PAINT, MSG_NCPAINT
	HUB_SendMessage(pWnd, MSG_PAINT, 0, 0);
    HUB_SendMessage(pWnd, MSG_NCPAINT, 0, 0);
    //send messages for all childs
    PWND pBase, pItem;
    pBase = (PWND_WndListItem)&WND_WndListHeader;
    pItem = pBase;
    //find all child and paint its
    while((pItem = (PWND_WndListItem) RAM_ListGetTopLeft((PRAM_ListItem)pItem)) != pBase)
    {
        if(pItem->pWndParent == pWnd)
        {
            HUB_SendMessage(pItem, MSG_PAINT, 0, 0);
            HUB_SendMessage(pItem, MSG_NCPAINT, 0, 0);
        }
    }
}

#define WND_TITLE_MENU_BAR_HEIGHT	18	//������ ���� � ��������� � ��������.

//NT-get client rect of window
//pWnd=window
//pRect=out rectangle with client size and coords
//return unmodified rectangle if window is null or not visible
void  APIEXPORT WND_GetClientRect(PWND pWnd, LPGDATA_RECT pRect)
{
	//calculate and return client rectangle
	s32 t, m; u32 st;
	if(pWnd != 0)
	{
		st = pWnd->WindowStyle;
		t = pWnd->wndRect.Y;
		m = pWnd->wndRect.Height;
        m = m + t; //end point Y
		//calc Y
		if(st & WND_WS_TITLEBAR)
			t += WND_TITLE_MENU_BAR_HEIGHT;
		if(st & WND_WS_MENUBAR)
			t += WND_TITLE_MENU_BAR_HEIGHT;
		if(st & WND_WS_BORDER) 
		{
			t += 1; //border width top line
			m -= 1; //bottom line
		}
		pRect->Y = t; 
		//height
		if(st & WND_WS_HSCROLL)
			m -= WND_TITLE_MENU_BAR_HEIGHT;
		m = m - t;
		if(m < 0) m = 0;
		pRect->Height = m;
		//X calc
		m = pWnd->wndRect.Width;
		t = pWnd->wndRect.X;
        m = m + t; //end point X
		if(st & WND_WS_BORDER)
		{
			t += 1;
			m -= 1;
		}
		if(st & WND_WS_VSCROLL)
			t += WND_TITLE_MENU_BAR_HEIGHT;
		pRect->X = t;
		m = m - t;
		if(m < 0) m = 0;
		pRect->Width = m;
		return;
	}
	else
	{
		//return dummy rectangle
		RAM_memZero((u8*)pRect, sizeof(GDATA_RECT));
	}
	return;
}


//Nt-process messages default 
u32 WND_DefWindowProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval)
{
	PWND resWnd;
	u32 resultcode = 0;
	switch(msgCode)
	{
		case MSG_TOUCHSCREEN_SCREEN_DOWN:
			resWnd = WND_FromPoint(pWnd, (u32)Xval, (u32)Yval);
			if(resWnd == 0)
			{
				//click not in current window - lost focus
				HUB_PostMessage(pWnd, MSG_LOSTFOCUS, (u32) Xval, (u32) Yval);
			}
			else
				HUB_PostMessage(resWnd, MSG_STILUS_DOWN, (u32)Xval, (u32)Yval);
			break;
		case MSG_TOUCHSCREEN_SCREEN_MOVE:
			resWnd = WND_FromPoint(pWnd, (u32)Xval, (u32)Yval);
			if(resWnd == 0)
			{
				//click not in current window - lost focus
				HUB_PostMessage(pWnd, MSG_LOSTFOCUS, (u32) Xval, (u32) Yval);
			}
			else
				HUB_PostMessage(resWnd, MSG_STILUS_MOVE, (u32)Xval, (u32)Yval);
			break;
		case MSG_TOUCHSCREEN_SCREEN_UP:
			resWnd = WND_FromPoint(pWnd, (u32)Xval, (u32)Yval);
			if(resWnd == 0)
			{
				//click not in current window - lost focus
				HUB_PostMessage(pWnd, MSG_LOSTFOCUS, (u32) Xval, (u32) Yval);
			}
			else
				HUB_PostMessage(resWnd, MSG_STILUS_UP, (u32)Xval, (u32)Yval);
			break;
		default:

			break;
	}
	return resultcode;
}

//The DestroyWindow function destroys the specified window. 
//The function sends DESTROY and NCDESTROY messages to the window
//to deactivate it and remove the focus from it. 
//If the specified window is a parent or owner window, DestroyWindow 
//automatically destroys the associated child or owned windows when it 
//estroys the parent or owner window. The function first destroys child 
//or owned windows, and then it destroys the parent or owner window.

//Destroy window and childs
u32  APIEXPORT WND_DestroyWindow(PWND pWnd)
{
	//remove window and all child from list
	//send MSG_DESTROY to window handler

	//1 remove all child window recursively
	PWND_WndListItem pBase = (PWND_WndListItem)&WND_WndListHeader;
	PWND_WndListItem pItem = pBase;
	//find by id
	while((pItem = (PWND_WndListItem) RAM_ListGetTopLeft((PRAM_ListItem)pItem)) != pBase)
	{
		if(pItem->pWndParent == pWnd)
			WND_DestroyWindow(pItem);
	}
	//2 send MSG_DESTROY to window handler
	HUB_SendMessage(pWnd, MSG_DESTROY, 0, 0);
	HUB_SendMessage(pWnd, MSG_NCDESTROY, 0, 0);
	//3 remove main window
	RAM_ListRemoveItem((PRAM_ListItem)pBase, (PRAM_ListItem)pWnd);
	RAM_memFree((u8*) pWnd);
	return 0;
}

//NT- is window visible
//return 0 if window invisible, !0 if visible
u32 WND_isVisible(PWND pwnd)
{
	if(pwnd == 0) return 0;
	else return ((u32)pwnd->WindowStyle & WND_WS_VISIBLE);
}

//get window from click point
//return 0 if wnd not clicked
//return pwnd of clicked window
PWND WND_FromPoint(PWND baseWnd, u32 X, u32 Y)
{
	PWND_WndListItem pBase, pItem;
	PWND child;
	//check visibility of current window
	if(WND_isVisible(baseWnd) == 0) return 0;
	//copy window rect - remove for optimization stack using
	//GDATA_RECT rc;
	//GDATA_rectSetRect(&rc, baseWnd->wndRect.X, baseWnd->wndRect.Y, baseWnd->wndRect.Width, baseWnd->wndRect.Height);
	//check point
	//if((x >= rc->X) && (x <= (rc->X + rc->Width - 1)) && (y >= rc->Y) && (y <= (rc->Y + rc->Height - 1)))
	//if(GDATA_rectPtInRect(&rc, X, Y) != 0)
	if((X >= baseWnd->wndRect.X) && (Y >= baseWnd->wndRect.Y) && (X <= (baseWnd->wndRect.X + baseWnd->wndRect.Width - 1))  && (Y <= (baseWnd->wndRect.Y + baseWnd->wndRect.Height - 1)))
	{
		//click in current window or child
		pBase = (PWND_WndListItem)&WND_WndListHeader;
		pItem = pBase;
		//find child
		while((pItem = (PWND_WndListItem) RAM_ListGetTopLeft((PRAM_ListItem)pItem)) != pBase)
		{
			if(pItem->pWndParent == baseWnd)
			{
				child = WND_FromPoint(pItem, X, Y);
				if(child != 0) return child;
			}
		}
		//if no child at point
		return baseWnd; //click in current window
	}
	else return 0; //click not in current window
}

//translate coord from screen to window client view
//return window and client coords
PWND WND_ScreenToClient(PWND wnd, LPGDATA_POINT pPt)
{









}

//translate coord from window client view to screen 
//return screen coords
u32 WND_ClientToScreen(PWND wnd, LPGDATA_POINT pPt)
{









}