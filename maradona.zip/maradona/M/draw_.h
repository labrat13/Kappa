//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for DRAW subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_DRAW_H
#define MY_DRAW_H


#include "stm32f10x.h"
#include "ram_.h"
#include "TFT_.h"
#include "types.h"
#include "GData.h" //rect point size types
#include "FS.h"
#include "colors.h"


//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//bitmap file header
typedef struct _BmpHeader
{
	u8 FileType;  //'G'
	u8 PixelFormat;		//0=rgb565 1=rgb888
	u16 Width;			//width in pixel
	u16 Height;			//height in pixel
	u32 AlphaColor;		//color of mask
} DRAW_BmpHeader, *PDRAW_BmpHeader;

#define DRAW_BMP_FILE_TYPE			(u8) 'G'
#define DRAW_BMP_PIXELFORMAT_565	0
#define DRAW_BMP_PIXELFORMAT_888	1

//base border flags
#define DRAW_BORDER_INACTIVE            1
#define DRAW_BORDER_TOPLEFT_LIGHT       2
#define DRAW_BORDER_BOTRIGHT_LIGHT      4
//combined border flags
#define DRAW_BORDER_ACTIVE_SOLID        0  
#define DRAW_BORDER_ACTIVE_PUSHED       DRAW_BORDER_BOTRIGHT_LIGHT  
#define DRAW_BORDER_ACTIVE_POPPED       DRAW_BORDER_TOPLEFT_LIGHT
#define DRAW_BORDER_INACTIVE_SOLID      DRAW_BORDER_INACTIVE 
#define DRAW_BORDER_INACTIVE_PUSHED     DRAW_BORDER_INACTIVE | DRAW_BORDER_BOTRIGHT_LIGHT  
#define DRAW_BORDER_INACTIVE_POPPED     DRAW_BORDER_INACTIVE | DRAW_BORDER_TOPLEFT_LIGHT 

//GLOBAL VARIABLES

//PROTOTYPES

//get size of required rectangle for string drawing 
//string must not contain \t \r and other whitesymbols. Only \n allowed.
void  APIEXPORT DRAW_GetStringSize(u8* string, u32 stringLen, LPGDATA_SIZE sz);
//get current orientation display size
void  APIEXPORT DRAW_GetDisplaySize(LPGDATA_SIZE sz);
//get rectangle of all display
void  APIEXPORT DRAW_GetDisplayRect(LPGDATA_RECT rc);
//set display orientation: 0 = vertical, 1 = horizontal
void  APIEXPORT DRAW_SetDisplayOrient(TFT_DisplayOrder orient);

//draw rect with specified color
void  APIEXPORT DRAW_drawRect(
			  u32 x,		//X begin
			  u32 y,		//Y begin
			  u32 width,	//area width 
			  u32 height,	//area height
			  u32 color		//color
			  );

//Draw line
void  APIEXPORT DRAW_drawLine(
              u16 x1,	//The x-coordinate of the first line endpoint.
              u16 y1,	//The y-coordinate of the first line endpoint.
              u16 x2,	//The x-coordinate of the second line endpoint.
              u16 y2,	//The y-coordinate of the second line endpoint.
              u16 color	//Line color
              );

//fill up specified rectangle
void  APIEXPORT DRAW_FillRect(LPGDATA_RECT rc, u32 color);

//simple draw string w/out check length
void  APIEXPORT DRAW_String(u8* str,	//string
				u32 len,	//length of string
				u32 X,   //start point of string
                u32 Y,
				u32 color,	//text color
				u32 bgcolor);//back color

//draw part of picture in specified screen position
//szPath=full ASCIIZ path of picture file, like E:/dir/pict.mbp
//Buf=buffer for picture pixels - must be bigger than drawed width of picture
//rcPict=rectangle of drawed part of picture
//screenX=screen x coordinate of topleft drawing point
//screenY=screen y coordinate of topleft drawing point
void DRAW_PictureFile(u8* szPath, u16* Buf, GDATA_RECT* rcPict, u32 screenX, u32 screenY);

//draw border with specified color around rectangle 
void DRAW_drawBorderAround(
			  u32 x,		//X begin
			  u32 y,		//Y begin
			  u32 width,	//area width 
			  u32 height,	//area height
			  u32 flags     //border styles  
			  );

#endif // MY_DRAW_H