/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "time_.h"
#include "ram_.h"
#include "clock_.h"

//u8 dayNames[] = "SuMoTuWeThFrSa"; //day names as N * 2, length=2
//u8 monthNames[] = "JanFebMarAprMayJunJulAugSepOctNowDec"; //month names as N * 3, length=3




//FUNCTIONS

//abstraction for all HCLK modes
//generally, OS time system should be used for user application
//this function for OS internal use only
void  APIEXPORT TIME_delay_ms(vu32 ms)
{
    u16 tmp = RAM_getSysClockMode();
    if(tmp == CLKMODE_12) tmp = 1250;
    else tmp = tmp * 2500;
    //delay
    ms = ms * tmp; //~ 1ms for 72mHz=7500, 48m=5000, 24m=2500 12m=1250
    while(ms > 0)  ms--; //10 HCLK's for 1 step
}


//void RTCconfig()
//{
//	//!!! Remove all trash from code here!!!
//
//	NVIC_InitTypeDef NVIC_InitStructure;
//
//	/* Configure one bit for preemption priority */
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//
//	/* Enable the RTC Interrupt */
//	NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);
//	  // /* Enable the RTC Alarm Interrupt */
//  // NVIC_InitStructure.NVIC_IRQChannel = RTCAlarm_IRQn;
//  // NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//  // NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//  // NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  // NVIC_Init(&NVIC_InitStructure);
//
//  		/* Enable PWR and BKP clocks */
//		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
//
//	if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)
//	{
//		/* Backup data register value is not correct or not yet programmed (when
//		the first time the program is executed) */
//
//		DBG_printf("RTC not yet configured\r\n");
//
//		/* RTC Configuration */
//		/* Enable PWR and BKP clocks */
//		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
//
//		/* Allow access to BKP Domain */
//		PWR_BackupAccessCmd(ENABLE);
//
//		/* Reset Backup Domain */
//		//BKP_DeInit();
//
//		/* Enable LSE */
//		RCC_LSEConfig(RCC_LSE_ON); //TODO: not work
//
//    /* Disable the LSI OSC */
//    //RCC_LSICmd( ENABLE );
//
//        DBG_printfn("LSE", 3);
//		/* Wait till LSE is ready */
//     while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
//     {
//     }
//        DBG_printfn("on ", 3);
//		/* Select LSE as RTC Clock Source */
//		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
//
//		/* Enable RTC Clock */
//		RCC_RTCCLKCmd(ENABLE);
//        //RTC_WaitForLastTask();
//		/* Wait for RTC registers synchronization */
//		RTC_WaitForSynchro();
//        DBG_printfn("syn", 3);
//		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
//        DBG_printfn("IT ", 3);
//		/* Enable the RTC Second */
//		RTC_ITConfig(RTC_IT_SEC, ENABLE);
//
//		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
//
//		/* Set RTC prescaler: set RTC period to 1sec */
//		RTC_SetPrescaler(32765); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */
//
//		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
//
//		DBG_printf("\r\n RTC configured");
//
//		/* Adjust time */
//		//Time_Adjust();
//		/* Wait until last write operation on RTC registers has finished */
//		//RTC_WaitForLastTask();
//		/* Change the current time */
//		RTC_SetCounter(0x12345678);
//		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
//		BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
//	}
//	else
//	{
//		/* Check if the Power On Reset flag is set */
//		if (RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET)
//		{
//			DBG_printf("\r\n\n Power On Reset occured");
//		}
//		/* Check if the Pin Reset flag is set */
//		else if (RCC_GetFlagStatus(RCC_FLAG_PINRST) != RESET)
//		{
//			DBG_printf("\r\n\n External Reset occured");
//		}
//
//		DBG_printf("\r\n No need to configure RTC");
//		/* Wait for RTC registers synchronization */
//		RTC_WaitForSynchro();
//
//		/* Enable the RTC Second */
//		RTC_ITConfig(RTC_IT_SEC, ENABLE);
//		/* Wait until last write operation on RTC registers has finished */
//		RTC_WaitForLastTask();
//	}
//	/* Clear reset flags */
//	RCC_ClearFlag();
//}
//
////set datetime to rtc counter
//void rtcSetDateTime(LPM_DATETIME lpt)
//{
////TODO: set valid code here
//	u32 res;
//	res = (lpt->Hour * 60) + lpt->Minute;
//	res = (res * 60) + lpt->Second;
//	RTC_SetCounter(res);
//	RTC_WaitForLastTask();
//}
//
////get datetime from rtc counter
//void rtcGetDateTime(LPM_DATETIME lpt)
//{
//	//TODO: set valid code here
//	u32 res = RTC_GetCounter();
//	//seconds
//	lpt->Second = (u8)(res % 60);
//	res = res / 60;
//	//minutes
//	lpt->Minute = (u8)(res % 60);
//	res = res / 60;
//	//hours
//	lpt->Hour = (u8)(res % 24);
//	res = res / 24;
//	//days
//	lpt->Day = (u8)(res % 30);
//	res = res / 30;
//	//months
//	lpt->Month = (u8)(res % 12);
//	//years
//	lpt->Year = res / 12;
//    return;
//}
//
////check that datetime is correct
//u8 rtcIsDateTimeCorrect(LPM_DATETIME lpt)
//{
//	return 0;
//}
//
////create datetime string
//void rtcDateTimeToString(LPM_DATETIME lpt, u8* buffer, u8 buflen)
//{
//}
//
////return day name by number
//u8* rtcGetDayName(u8 day)
//{
//	u8* ptr = (u8*)dayNames;
//	ptr = ptr + (day * 2);
//	return ptr;
//}
//
////return month name by number
//u8* rtcGetMonthName(u8 month)
//{
//	u8* ptr = (u8*)monthNames;
//	ptr = ptr + (month * 3);
//	return ptr;
//}


