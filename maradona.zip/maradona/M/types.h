//project types

#ifndef MY_TYPESH
#define MY_TYPESH

//attributes in GCC
#if __GNUC__ >= 3  //for gnu c only
#undef inline
#define inline __attribute__ ((always_inline)) //always threat function as inline
#define __noinline __attribute__ ((noinline))  //never inline function
#define __pure __attribute__ ((pure))           //pure functions - only read global variables and params; strlen() as example
#define __const __attribute__ ((const))         //constant functions - only read params, not pointers. abs() sin() cos(), for example
#define __noreturn __attribute__ ((noreturn))   //function not returned any values (because an exception, f. e.)
#define __malloc __attribute__ ((malloc))       //function returns unique pointer to memory
#define __must_check __attribute__ ((warn_unused_results))  //check returned value
#define __deprecated __attribute__ ((deprecated)) //function deprecated warning
#define __used __attribute__ ((used))           //force compile function
#define __unused __attribute__ ((unused))       //suppress warning "function or param not used"
#define __packed __attribute__ ((packed))       //struct elements packed without align
#define __align(x) __attribute__ ((aligned(x))) //struct elements aligned by x bytes

#else
#define inline __attribute__ ((always_inline))
#define __noinline 
#define __pure 
#define __const 
#define __noreturn 
#define __malloc 
#define __must_check 
#define __deprecated 
#define __used 
#define __unused 
#define __packed 
#define __align(x) 

#endif










#endif