/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for TOUCH subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES

#include "touch_.h"
#include "TFT_.h"  //for tft size defines
#include "clock_.h"
#include "debugTerm.h"
#include "buzzer_.h"
#include "ram_.h"
#include "hub.h" //events consuming

//PRIVATE DEFINES
#define TOUCH_Y_LIMIT 3000 //if Y+ value lower than this limit, click detected
#define TOUCH_T_LIMIT 850     //if Rt value lower this limit, click valid
#define TOUCH_ADCSIZE 4096  //device adc size 12bit=4096
#define TOUCH_VREFINT_DATASHEETMV 1200  //vRefInt in mV, from datasheet
#define TOUCH_TEMPERATURE_COEFFICIENT  4403 //AVgslope in mV*1024 from datasheet
#define TOUCH_BASE_TEMPERATURE_VALUE  1430 //mV for 25degrees
#define TOUCH_TEMPERATURE_BASE 25 //degrees for base

//PRIVATE VARIABLES
ADC_VRESULTS TOUCH_AdcVoltFiltering;    //filter volt values
ADC_TRESULTS TOUCH_AdcTouchFiltering;   //filter touch values
GDATA_POINT  TOUCH_ClickCoord;          //old click coords or 0xFFFF's. For event generation only!
//PUBLIC VARIABLES
s16          TOUCH_Temperature;         //current temperature
u16          TOUCH_VrefMv;              //Vref millivolts
u16          TOUCH_VbatMv;              //Vbat millivolts

//PRIVATE FUNCTION DECLARATION
void TOUCH_CreateTouchEvents(s16 newX, s16 newY);
u32 TOUCH_DetectVoltEvents();
void TOUCH_TouchEvent(TOUCH_EventType eventType, s16 X, s16 Y);
void TOUCH_calcPoint3(LPADC_TRESULTS lpar, LPGDATA_POINT lppt);


//FUNCTIONS

//adc full init
void TOUCH_Init(u16 clkMode)
{
	//Y+ PB1/ADC12_9
	//X+ PB0/ADC12_8
	//Y- PC5/ADC12_15
	//temp ADC1_16
	//Vref ADC1_17
	//Vbat PA3/ADC_3
	//clock config

	//ADCCLK = PCLK2/n  = 6MHz
	u32 tmp;
	if(clkMode == CLKMODE_72) tmp = RCC_PCLK2_Div6; //36/6=6m
	else if(clkMode == CLKMODE_48) tmp =  RCC_PCLK2_Div4; //24/6=6m;
	else if(clkMode == CLKMODE_24)tmp =  RCC_PCLK2_Div4; //24/6=6m;
	else tmp =  RCC_PCLK2_Div2; //12/6=6m;        

	RCC_ADCCLKConfig(tmp); 

	/* Enable ADC1 ADC2 and GPIOA/B/C clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_ADC2 | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
	//gpio config
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Configure PB0, PB1 as analog input -------------------------*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	//configure PC5 as analog input
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	//configure PA3 as analog input
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOA, &GPIO_InitStructure);   

	/* ADC1 configuration ------------------------------------------------------*/
	ADC_InitTypeDef ADC_InitStructure;

	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;     //Scan group mode
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE; //Single mode
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//no external triggers
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//right-aligned result
	ADC_InitStructure.ADC_NbrOfChannel = 3;
	ADC_Init(ADC1, &ADC_InitStructure);

	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;     //Scan group mode
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE; //Single mode
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//no external triggers
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//right-aligned result
	ADC_InitStructure.ADC_NbrOfChannel = 3;
	ADC_Init(ADC2, &ADC_InitStructure);  

	/* Set injected sequencer length */
	ADC_InjectedSequencerLengthConfig(ADC1, 3);
	ADC_InjectedSequencerLengthConfig(ADC2, 3); 

	/* ADC  channel configuration */ 
	ADC_InjectedChannelConfig(ADC2, ADC_Channel_8, 1, ADC_SampleTime_239Cycles5); //x+
	ADC_InjectedChannelConfig(ADC2, ADC_Channel_9, 2, ADC_SampleTime_239Cycles5); //y+
	ADC_InjectedChannelConfig(ADC2, ADC_Channel_15, 3, ADC_SampleTime_239Cycles5); //y-

	ADC_InjectedChannelConfig(ADC1, ADC_Channel_16, 1, ADC_SampleTime_41Cycles5); //temp 5-17uS
	ADC_InjectedChannelConfig(ADC1, ADC_Channel_17, 2, ADC_SampleTime_239Cycles5); //vref
	ADC_InjectedChannelConfig(ADC1, ADC_Channel_3,  3, ADC_SampleTime_239Cycles5); //vbat

	/* ADC injected external trigger configuration */
	ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_None);
	ADC_ExternalTrigInjectedConvConfig(ADC2, ADC_ExternalTrigInjecConv_None);

	/* Enable injected external trigger conversion on ADC1 */
	ADC_ExternalTrigInjectedConvCmd(ADC1, ENABLE);
	ADC_ExternalTrigInjectedConvCmd(ADC2, ENABLE);  



	//enable interrupts for adc1 adc2
	NVIC_InitTypeDef NVIC_InitStructure;
	// /* Configure and enable ADC interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	/* Enable ADC1 JEOC interupt */
	ADC_ITConfig(ADC1, ADC_IT_JEOC, ENABLE);

	/* Enable ADC1 */
	ADC_Cmd(ADC1, ENABLE);
	ADC_TempSensorVrefintCmd(ENABLE);
	/* Enable ADC1 reset calibration register */   
	ADC_ResetCalibration(ADC1);
	/* Check the end of ADC1 reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC1));
	/* Start ADC1 calibaration */
	ADC_StartCalibration(ADC1);
	/* Check the end of ADC1 calibration */
	while(ADC_GetCalibrationStatus(ADC1));

	/* Enable ADC2 */
	ADC_Cmd(ADC2, ENABLE);
	/* Enable ADC2 reset calibration register */   
	ADC_ResetCalibration(ADC2);
	/* Check the end of ADC2 reset calibration register */
	while(ADC_GetResetCalibrationStatus(ADC2));
	/* Start ADC2 calibaration */
	ADC_StartCalibration(ADC2);
	/* Check the end of ADC2 calibration */
	while(ADC_GetCalibrationStatus(ADC2));

	//init variables  
	RAM_memZero((u8*)&TOUCH_AdcVoltFiltering, sizeof(ADC_VRESULTS)); //TOUCH_VoltClear(&TOUCH_AdcVoltFiltering);
	RAM_memZero((u8*)&TOUCH_AdcTouchFiltering, sizeof(ADC_TRESULTS));
	TOUCH_ClickCoord.X = TOUCH_INVALID_COORD;
	TOUCH_ClickCoord.Y = TOUCH_INVALID_COORD;
	TOUCH_Temperature = 0;//current temperature
	TOUCH_VrefMv = 0;     //Vref millivolts
	TOUCH_VbatMv = 0;   

	return;
}

void TOUCH_Exit()
{
	
	ADC_TempSensorVrefintCmd(DISABLE);
	ADC_Cmd(ADC2, DISABLE);
	ADC_Cmd(ADC1, DISABLE);

	/* Disable ADC1 JEOC interupt */
	ADC_ITConfig(ADC1, ADC_IT_JEOC, DISABLE);
	NVIC_DisableIRQ(ADC1_2_IRQn);

	//reset adc1 adc2
	RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, DISABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC2, ENABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC2, DISABLE);
	
	/* Disable ADC1 ADC2 clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_ADC2, DISABLE);

}


//accessor for global variables
u32  APIEXPORT TOUCH_getVbatMv()
{
	return (u32) TOUCH_VbatMv;
}
u32  APIEXPORT TOUCH_getVrefMv()
{
	return (u32) TOUCH_VrefMv;
}
s32  APIEXPORT TOUCH_getTemperature()
{
	return (s32) TOUCH_Temperature;
}

//adc1 interrupt routine
void TOUCH_AdcVoltRoutine()
{
	u16 t;
	s32 tmp;
	
	u32 powerState;

	//1)add values to filter, increment counter
	t = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);//temperature
	TOUCH_AdcVoltFiltering.Temp += t;
	t = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);//Vref
	TOUCH_AdcVoltFiltering.Vref += t;
	t = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);//Vbat
	TOUCH_AdcVoltFiltering.Vbat += t;    
	TOUCH_AdcVoltFiltering.Count++; 
	//2)if(counter < filtersize) exit
	if(TOUCH_AdcVoltFiltering.Count > 31) //32 averaging
	{
		//3)else filter values
		TOUCH_AdcVoltFiltering.Temp = TOUCH_AdcVoltFiltering.Temp >> 5;
		TOUCH_AdcVoltFiltering.Vref = TOUCH_AdcVoltFiltering.Vref >> 5;
		TOUCH_AdcVoltFiltering.Vbat = TOUCH_AdcVoltFiltering.Vbat >> 5;// /32
		//4)convert values to output values
		//5)store to output variables
		TOUCH_VrefMv = (u16)((TOUCH_ADCSIZE * TOUCH_VREFINT_DATASHEETMV) / TOUCH_AdcVoltFiltering.Vref);
		TOUCH_VbatMv = (u16) (((TOUCH_VREFINT_DATASHEETMV * 2) * TOUCH_AdcVoltFiltering.Vbat)/TOUCH_AdcVoltFiltering.Vref);
		//Temp - get mV
		tmp = (s32) ((TOUCH_VREFINT_DATASHEETMV * TOUCH_AdcVoltFiltering.Temp)/TOUCH_AdcVoltFiltering.Vref); 
		//Temp - get degrees
		TOUCH_Temperature = (s16) ((((TOUCH_BASE_TEMPERATURE_VALUE - tmp) * 1024) / TOUCH_TEMPERATURE_COEFFICIENT) + TOUCH_TEMPERATURE_BASE); 
		//check asm listing
		RAM_memZero((u8*)&TOUCH_AdcVoltFiltering,  sizeof(ADC_VRESULTS));//TOUCH_VoltClear(&TOUCH_AdcVoltFiltering); //clear filter   
		//6)check values and generate events
		powerState = TOUCH_DetectVoltEvents();
		if(powerState != TOUCH_POWER_EVENT_NONE)
			HUB_putPowerEvent(powerState);
	}
	//Need to clear interrupt flags here
	ADC_ClearFlag(ADC1, ADC_FLAG_JEOC); //NOT cleaned by hardware!
	return;
}

//NT-detect type of Volt event
//return 0 if all ok else return flags
u32 TOUCH_DetectVoltEvents()
{
	u32 res = 0; //TOUCH_POWER_EVENT_NONE
	//check Vbat
	if(TOUCH_VbatMv > TOUCH_VBAT_LIMIT_HIGH) res |= TOUCH_POWER_EVENT_VBAT_HIGH;
	if(TOUCH_VbatMv < TOUCH_VBAT_LIMIT_LOW) res |= TOUCH_POWER_EVENT_VBAT_LOW;
	if(TOUCH_VrefMv > TOUCH_VREF_LIMIT_HIGH) res |= TOUCH_POWER_EVENT_VREF_HIGH;
	if(TOUCH_VrefMv < TOUCH_VREF_LIMIT_LOW) res |= TOUCH_POWER_EVENT_VREF_LOW;
	if(TOUCH_Temperature > TOUCH_TEMPERATURE_LIMIT_HIGH) res |= TOUCH_POWER_EVENT_TEMP_HIGH;
	if(TOUCH_Temperature > TOUCH_TEMPERATURE_LIMIT_LOW) res |= TOUCH_POWER_EVENT_TEMP_LOW;
	return res;
}


//adc2 software conversion routine
//launch every systick, get values from adc, start new adc conversion, process data
//no adc interrupt used
void TOUCH_AdcTouchRoutine()
{
	u16 x, yp, ym;
	GDATA_POINT pt;//local point coords
	//get and check Y+ value
	//if click not occured and no results in filter, skip all work, clear filter, return.
	//if click not occured and filter have samples (counter > 0), clear filter and return invalid coord =>UP event
	//if click occured and filter count < limit, add values to filter, increment counter
	//if filter count >= limit, process filter and next
	
	//first conversion will be invalid data, next will be valid
	//flag is set, get data and start new conversion
	yp = ADC_GetInjectedConversionValue(ADC2, ADC_InjectedChannel_2);
	ym = ADC_GetInjectedConversionValue(ADC2, ADC_InjectedChannel_3);
	x = ADC_GetInjectedConversionValue(ADC2, ADC_InjectedChannel_1);
	//start new conversion
	ADC_ClearFlag(ADC2, ADC_FLAG_JEOC); //NOT cleaned by hardware!
	ADC_SoftwareStartInjectedConvCmd(ADC2, ENABLE);
	//process all data
	//TOUCH_TestY = y; //for debug only
	//BUZZER_Beep(10); //for debug only
	if(yp > TOUCH_Y_LIMIT) //touchscreen not pressed
	{
		if(TOUCH_AdcTouchFiltering.Count > 0)  //clear filter
			RAM_memZero((u8*)&TOUCH_AdcTouchFiltering,  sizeof(ADC_TRESULTS));//TOUCH_TouchClear(&TOUCH_AdcTouchFiltering);
		//return invalid coord
		pt.X = TOUCH_INVALID_COORD;
		pt.Y = TOUCH_INVALID_COORD; 
	}
	else //touchscreen pressed
	{
		//add values to filter
		TOUCH_AdcTouchFiltering.TouchY += yp; //Y+
		TOUCH_AdcTouchFiltering.TouchX += x;  //X
		//TOUCH_TestX = t; //for debug only
		TOUCH_AdcTouchFiltering.TouchT += ym; //Y-
		TOUCH_AdcTouchFiltering.Count++;        

		if(TOUCH_AdcTouchFiltering.Count < 16) //16 values average
			return; //return without any events - for new filtering data
		else
		{
			//filter values /16
			TOUCH_AdcTouchFiltering.TouchY = TOUCH_AdcTouchFiltering.TouchY >> 4;
			TOUCH_AdcTouchFiltering.TouchX = TOUCH_AdcTouchFiltering.TouchX >> 4;
			TOUCH_AdcTouchFiltering.TouchT = TOUCH_AdcTouchFiltering.TouchT >> 4;            
			//convert values to output values and store in global variables
			TOUCH_calcPoint3(&TOUCH_AdcTouchFiltering, &pt);
			//clear filter
			RAM_memZero((u8*)&TOUCH_AdcTouchFiltering, sizeof(ADC_TRESULTS)); //TOUCH_TouchClear(&TOUCH_AdcTouchFiltering);
		}
	}
	//check values and generate events
	TOUCH_CreateTouchEvents(pt.X, pt.Y);
	return;
}

//convert touch to display, return Success with coords or Error for invalid state
void TOUCH_calcPoint3(LPADC_TRESULTS lpar, LPGDATA_POINT lppt)
{
	//optimize it!
	s32 t, Rt, Rx, Ry, X, Y;
	if(lpar->TouchY < TOUCH_Y_LIMIT)
	{
		//click detected
		t = 4095 - lpar->TouchY;
		Rt = (1024 * (lpar->TouchT - lpar->TouchX)) / t;
		if(Rt < TOUCH_T_LIMIT)   
		{
			//click valid
			Rx = (1024 * lpar->TouchX) / t; 
			Ry = (1024 * (lpar->TouchY - lpar->TouchT)) / t;
			//calc coords
			//s32 resX = ((332.95 * 1024) - (Rx * 1024)) / (1.295 * 1024);
			//s32 resY = ((Ry * 1024) - 29.8*1024)/ (1.72 * 1024);
			Rx = Rx * 1024; X = (340941 - Rx)/1326;
			Ry = Ry * 1024; Y = (Ry - 30515)/1761; 
			//check output values
			if((X > -10) && (X < 250) && (Y > -10) && (Y < 350)) // +-10points allowed as small mistakes
			{
				//coords allowed
				//patch X to range 0..239
				if(X < 0) X = 0;
				else if(X > 239) X = 239;
				//patch Y to range 0..340 (0..319 display, 320..340 button bar)    
				if(Y < 0) Y = 0;
				else if(Y > 340) Y = 340;                    
				//write to output value
				lppt->X = (s16)X; lppt->Y = (s16)Y;
				return; //success
			}
		}            
	}
	//return value for invalid coords
	lppt->X = TOUCH_INVALID_COORD;
	lppt->Y = TOUCH_INVALID_COORD; 
	return; //error
}

//NT-Generate events for new point data
void TOUCH_CreateTouchEvents(s16 newX, s16 newY)
{
	s16 X; s16 Y; 
	//TOUCH_EventType tet;

	//TOUCH_ClickCoord stores old coords
	if(TOUCH_ClickCoord.X == TOUCH_INVALID_COORD)
	{
		if(newX == TOUCH_INVALID_COORD)
		{
			return;    //BAD + BAD = NOEVENTS
		}
		else 
		{
			//BAD + GOOD = DOWN(new)  //tet = TouchEvent_Down;
			//store new values to old     
			TOUCH_ClickCoord.X = newX;
			TOUCH_ClickCoord.Y = newY;            
			//TOUCH_TouchEvent(TouchEvent_Down, newX, newY); 
			HUB_putTouchEvent(TouchEvent_Down, newX, newY);
			return;
		};
	}
	else
	{
		if(newX == TOUCH_INVALID_COORD)
		{
			X = TOUCH_ClickCoord.X; Y = TOUCH_ClickCoord.Y;
			//store new values to old     
			TOUCH_ClickCoord.X = newX;
			TOUCH_ClickCoord.Y = newY;           
			//GOOD + BAD = UP(old); tet = TouchEvent_Up; X = TOUCH_ClickCoord.X; Y = TOUCH_ClickCoord.Y; 
			HUB_putTouchEvent(TouchEvent_Up, X, Y);
			return;
		}
		else
		{
			if((TOUCH_ClickCoord.X == newX) && (TOUCH_ClickCoord.Y == newY))
			{
				return;//GOODa + GOODa = NO EVENTS 
			}
			else
			{
				//GOODa + GOODb = MOVE(new); tet = TouchEvent_Move;
				//store new values to old     
				TOUCH_ClickCoord.X = newX;
				TOUCH_ClickCoord.Y = newY;               
				HUB_putTouchEvent(TouchEvent_Move, newX, newY);
				return;
			}            
		}
	}
	return;
}

//------------------ DETECT CLICKED ITEM FUNCTION -------------------------------------------

//CLICKED BUTTON RESULT CODES
#define TOUCH_CLICKED_SCREEN			0	//screen clicked
#define TOUCH_CLICKED_TOUCHBUTTON_BAR	1	//button bar clicked, not button
#define TOUCH_CLICKED_TOUCHBUTTON_1		2	//button 1
#define TOUCH_CLICKED_TOUCHBUTTON_2		3	//button 2
#define TOUCH_CLICKED_TOUCHBUTTON_3		4	//button 3
#define TOUCH_CLICKED_TOUCHBUTTON_4		5	//button 4
#define TOUCH_CLICKED_TOUCHBUTTON_5		6	//button 5
#define TOUCH_CLICKED_INVALIDCOORD		7	//invalid input coord
//private defines
#define BUTTON_TOPLINE      322  //top y coord of button
#define BUTTON_BOTTOMLINE   337  //bottom y coord of button
#define BUTTON_MASK     7    //mask for detection

//divide clicks to button and screen clicks
//return clicked item code as defined
u16 TOUCH_DetectClickedItem(s16 x, s16 y)
{
//button centered at y = 330, x = 240/5*2: 24, 72, 120, 168, 216 (����� 48)
//button size y = 14; x = 36; 

	u32 tmp;
	//check input coords
	if((y == TOUCH_INVALID_COORD) ||(x == TOUCH_INVALID_COORD)) return TOUCH_CLICKED_INVALIDCOORD;
    //portrait orient of incoming coords
	if(y < TFT_SIZE_Y)
	{
		//click in screen part
		if((y >= 0) && (x >= 0) && (x < TFT_SIZE_X)) //click on screen rect
			return TOUCH_CLICKED_SCREEN;
	}
	else
	{
		//click in button part
		if((y > BUTTON_TOPLINE) && (y < BUTTON_BOTTOMLINE))
		{
			//y valid for buttons
			//�������� ��� ����� ������ (240) �� ����� �� 6, ����� ���� ������ ������ �� 0 �� 7 ������, 
			//����� 0 � 7 �� ������ � ������, � ������� ������� ���������� ����� ������.
			tmp = x / 6; 
            if(((tmp & BUTTON_MASK) > 0) && ((tmp & BUTTON_MASK) < 7))
			{
				//button number from 0 to 4 (or 5 if x >= 240)
				return 2 + (tmp >> 3); //from 2 to 6, 7 = invalid
			}
		}
		else return TOUCH_CLICKED_TOUCHBUTTON_BAR; //button bar but not button
	}
	return TOUCH_CLICKED_INVALIDCOORD; //not valid click coords
}

//translate click coords for current display orientation
void TOUCH_TranslateClickCoords(s16* x, s16* y)
{
	u16 t;
	//coord comes as portrait, thus translate if landscape only
	if(RAM_sysGetFlag(SYSFLAG_DRAWORIENT)) //TFT_Landscape //Horiz = 320x240
	{
		t = *x;
		*x = *y;
		*y = (TFT_SIZE_X - 1) - t;
	}
	return;
}







//get volts by one manual conversion
//void TOUCH_getVoltConversion(LPADC_VRESULTS lpvr)
//{
//     ADC_SoftwareStartInjectedConvCmd(ADC1, ENABLE);
//     //wait for conversion ends
//	 while(ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC) == RESET);
//     //get values
//     lpvr->Temp = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
//     lpvr->Vref = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
//     lpvr->Vbat = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);
//     ADC_ClearFlag(ADC2, ADC_FLAG_JEOC); //NOT cleaned by hardware!
//}

//performs click detection. Return Success if click occured, Error otherwise (data fail).
//ErrorStatus TOUCH_getConversion(LPADC_TRESULTS lpar)
//{
//	u16 s = 8;
//	u16 t;
//    
//    TOUCH_TouchClear(lpar); //clear results 
//	//do 8 samples. If any sample no clicked - break all, because result data will be invalid
//    while(s)
//	{
//		ADC_SoftwareStartInjectedConvCmd(ADC3, ENABLE);
//       //time=6000000hz /255 + 255 + 255 cycles = 7812 loops per second=0.128mS
//		//wait for conversion ends
//		while(ADC_GetFlagStatus(ADC3, ADC_FLAG_JEOC) == RESET);
//		//get and store values
//		t = ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_2);
//		if(t > TOUCH_Y_LIMIT) return ERROR;
//                
//        lpar->TouchY += t;
//		lpar->TouchX += ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_1);
//		lpar->TouchT += ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_3);
//		//clear eoc flag
//		ADC_ClearFlag(ADC3, ADC_FLAG_JEOC); //NOT cleaned by hardware!
//		//next loop
//        s--;
//	}
//	//filter values /8
//	lpar->TouchX = lpar->TouchX >> 3;
//	lpar->TouchY = lpar->TouchY >> 3;
//	lpar->TouchT = lpar->TouchT >> 3;
//	return SUCCESS;
//}

//void TOUCH_oneConversion(LPADC_TRESULTS lpar)
//{
//	ADC_SoftwareStartInjectedConvCmd(ADC3, ENABLE);
//	//wait for conversion ends
//	while(ADC_GetFlagStatus(ADC3, ADC_FLAG_JEOC) == RESET);
//	//get and store values
//	lpar->TouchX = ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_1);
//	lpar->TouchY = ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_2);
//	lpar->TouchT = ADC_GetInjectedConversionValue(ADC3, ADC_InjectedChannel_3);
//	//clear eoc flag
//	ADC_ClearFlag(ADC3, ADC_FLAG_JEOC); //NOT cleaned by hardware!
//}

// void TOUCH_calcPoint2(LPADC_TRESULTS lpar, u32* pRx, u32* pRy, u32* pRt)
// {
// u32 t = 4095 - lpar->TouchY;
// *pRx = (1024 * lpar->TouchX) / t;
// *pRy = (1024 * (lpar->TouchY - lpar->TouchT)) / t;
// *pRt = (1024 * (lpar->TouchT - lpar->TouchX)) / t;
// }

