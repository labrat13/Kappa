/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "interrupts.h"
#include "core_cm3.h"
#include "clock_.h"

//FUNCTIONS
//initialize interrupts accord to current clockmode
void INTERRUPTS_Init(u16 clkMode)
{
    u32 tmp;
    //NVIC_InitTypeDef NVIC_InitStructure;
    
    /* Set the Vector Table base location at 0x20000200 for run via bootloader or 0x20000000 for run otherwise */ 
    NVIC_SetVectorTable(NVIC_VectTab_RAM, 0); 	
    
      /* Configure two bits for preemption priority */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //priority 0-3 (preemption), subpriority 0-3 (no preemption in group)
    
    //set SYSTICK divider value for clockmode for 1mS interval
    if(clkMode == CLKMODE_72) tmp = 72000000/1000;
    else if(clkMode == CLKMODE_48) tmp = 48000000/1000;
    else if(clkMode == CLKMODE_24) tmp = 24000000/1000;
    else  tmp = 12000000/1000;        
    SysTick_Config(tmp); //see core_cm3.h  priority = 0b11110000 = lowest priority in system
    
    //other inits
    
}

//deinitialize interrupts
void INTERRUPTS_Exit()
{
	//disable systick (see core_cm3.h)
	SysTick->CTRL = 0;
	//disable systick irq channel
	//NVIC_DisableIRQ(SysTick_IRQn); - special case for systick - no function
}

//disable irq channel - replace by NVIC_DisableIRQ
