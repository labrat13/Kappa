//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for HUB subsystem of Maradona project
// Dec 22, 2012: initial

//************************************************************

#ifndef MY_MSGCODE_H
#define  MY_MSGCODE_H

//range 0 - 31 - TOUCHSCREEN CLICK events
//bit0-1 = event code
//bit2-4 = touch area code
//do not change this values
//msg.valX = X coord; msg.valY = Y coord;
#define  MSG_TOUCHSCREEN_SCREEN_NONE			0	// no events
#define  MSG_TOUCHSCREEN_SCREEN_DOWN			1	// pressed
#define  MSG_TOUCHSCREEN_SCREEN_MOVE			2	// moved
#define  MSG_TOUCHSCREEN_SCREEN_UP			3	// released
#define  MSG_TOUCHSCREEN_BUTTONBAR_NONE		4	// no events
#define  MSG_TOUCHSCREEN_BUTTONBAR_DOWN		5	// pressed
#define  MSG_TOUCHSCREEN_BUTTONBAR_MOVE		6	// moved
#define  MSG_TOUCHSCREEN_BUTTONBAR_UP		7	// released
#define  MSG_TOUCHSCREEN_BUTTON_1_NONE		8	// no events
#define  MSG_TOUCHSCREEN_BUTTON_1_DOWN		9	// pressed
#define  MSG_TOUCHSCREEN_BUTTON_1_MOVE		10	// moved
#define  MSG_TOUCHSCREEN_BUTTON_1_UP			11	// released
#define  MSG_TOUCHSCREEN_BUTTON_2_NONE		12	// no events
#define  MSG_TOUCHSCREEN_BUTTON_2_DOWN		13	// pressed
#define  MSG_TOUCHSCREEN_BUTTON_2_MOVE		14	// moved
#define  MSG_TOUCHSCREEN_BUTTON_2_UP			15	// released
#define  MSG_TOUCHSCREEN_BUTTON_3_NONE		16	// no events
#define  MSG_TOUCHSCREEN_BUTTON_3_DOWN		17	// pressed
#define  MSG_TOUCHSCREEN_BUTTON_3_MOVE		18	// moved
#define  MSG_TOUCHSCREEN_BUTTON_3_UP			19	// released
#define  MSG_TOUCHSCREEN_BUTTON_4_NONE		20	// no events
#define  MSG_TOUCHSCREEN_BUTTON_4_DOWN		21	// pressed
#define  MSG_TOUCHSCREEN_BUTTON_4_MOVE		22	// moved
#define  MSG_TOUCHSCREEN_BUTTON_4_UP			23	// released
#define  MSG_TOUCHSCREEN_BUTTON_5_NONE		24	// no events
#define  MSG_TOUCHSCREEN_BUTTON_5_DOWN		25	// pressed
#define  MSG_TOUCHSCREEN_BUTTON_5_MOVE		26	// moved
#define  MSG_TOUCHSCREEN_BUTTON_5_UP			27	// released
#define  MSG_TOUCHSCREEN_INVALID_NONE		28	// no events
#define  MSG_TOUCHSCREEN_INVALID_DOWN		29	// pressed
#define  MSG_TOUCHSCREEN_INVALID_MOVE		30	// moved
#define  MSG_TOUCHSCREEN_INVALID_UP			31	// released

//range  -  TIME events
//msg.valX=msg.valY = 0;
#define  MSG_TIME_1S_EVENT					32	//time 1s event
#define  MSG_TIME_ALARM_EVENT				33	//alarm event

//power events
//msg.valX contains power state flags as come from event source
//msg.valY = 0
#define  MSG_POWER_EVENT					34	//power event. 

//gps event
//msg.X = u8 character from gps, msg.Y = 0
#define  MSG_GPS_CHAR_EVENT					35

//dbg terminal event
//msg.X = u8 character from usart, msg.Y = 0
#define  MSG_DBGTERM_CHAR_EVENT				36

//max code for hardware event messages
#define  MSG_HARDWARE_EVENT_MAX				37 

//paint non-client area of window
#define  MSG_NCPAINT                        38
//paint client area of window
#define  MSG_PAINT                          39

//command
//valX contains ...
//valY contains ...
#define  MSG_COMMAND						40

#define MSG_DESTROY                         41
#define MSG_NCDESTROY                       42

#define MSG_CLOSE                           43

//window lost focus - user clicked another place
//msg.valX = X coord; msg.valY = Y coord;
#define MSG_LOSTFOCUS						44

//stilus action messages for window reaction
//this messages act as top of user input for any window
//msg.valX = X coord; msg.valY = Y coord;
#define MSG_STILUS_DOWN						48
#define MSG_STILUS_MOVE						49
#define MSG_STILUS_UP						50

//application quit message
//valX contains result for return from application
#define MSG_QUIT							64




//message with maximum number
#define MSG_MAX								0xFFFF
#define MSG_MIN								0x0000
#endif // MY_MSGCODE_H