//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for BACKLIGHT subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_BACKLIGHT_H
#define  MY_BACKLIGHT_H
#include "stm32f10x.h" //project data types
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif

//DEFINES
//backlight bright levels
#define BACKLIGHT_LEVEL_0   1
#define BACKLIGHT_LEVEL_1   32
#define BACKLIGHT_LEVEL_2   64
#define BACKLIGHT_LEVEL_3   96
#define BACKLIGHT_LEVEL_4   128
#define BACKLIGHT_LEVEL_5   160 
#define BACKLIGHT_LEVEL_6   192
#define BACKLIGHT_LEVEL_7   255
//GLOBAL VARIABLES

//PROTOTYPES
//Set backlight level (1..255)
void  APIEXPORT BACKLIGHT_Set(u32 level);
void BACKLIGHT_Init(u16 clkMode);
void BACKLIGHT_Exit();
//get current backlight level - for showing to user
u32  APIEXPORT BACKLIGHT_Get();

#endif // MY_BACKLIGHT_H