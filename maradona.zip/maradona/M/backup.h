//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for BACKUP subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_BACKUP_H
#define  MY_BACKUP_H
#include "stm32f10x.h" //project data types
//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//backup register mapping  u16 type
#define BACKUP_REG_KEY   BKP_DR1 // key value for data check
#define BACKUP_REG_1     BKP_DR2 // 
#define BACKUP_REG_2     BKP_DR3 // 
#define BACKUP_REG_3     BKP_DR4 // 
#define BACKUP_REG_4     BKP_DR5 // 
#define BACKUP_REG_5     BKP_DR6 // 
#define BACKUP_REG_6     BKP_DR7 // 
#define BACKUP_REG_7     BKP_DR8 // 
#define BACKUP_REG_8     BKP_DR9 //Chip backup 16-bit register 
#define BACKUP_REG_9     BKP_DR10 //Chip backup 16-bit register
#define BACKUP_REG_10     BKP_DR11 //Chip backup 16-bit register
#define BACKUP_REG_11     BKP_DR12 //Chip backup 16-bit register 
#define BACKUP_REG_12     BKP_DR13 //Chip backup 16-bit register
#define BACKUP_REG_13     BKP_DR14 //Chip backup 16-bit register
#define BACKUP_REG_14     BKP_DR15 //Chip backup 16-bit register 
#define BACKUP_REG_15     BKP_DR16 //Chip backup 16-bit register
#define BACKUP_REG_16     BKP_DR17 //Chip backup 16-bit register
#define BACKUP_REG_17     BKP_DR18 //Chip backup 16-bit register 
#define BACKUP_REG_18     BKP_DR19 //Chip backup 16-bit register
#define BACKUP_REG_19     BKP_DR20 //Chip backup 16-bit register
#define BACKUP_REG_20     BKP_DR21 //Chip backup 16-bit register 
#define BACKUP_REG_21     BKP_DR22 //Chip backup 16-bit register
#define BACKUP_REG_22     BKP_DR23 //Chip backup 16-bit register
#define BACKUP_REG_23     BKP_DR24 //Chip backup 16-bit register 
#define BACKUP_REG_24     BKP_DR25 //Chip backup 16-bit register
#define BACKUP_REG_25     BKP_DR26 //Chip backup 16-bit register
#define BACKUP_REG_26     BKP_DR27 //Chip backup 16-bit register 
#define BACKUP_REG_27     BKP_DR28 //Chip backup 16-bit register
#define BACKUP_REG_28     BKP_DR29 //Chip backup 16-bit register
#define BACKUP_REG_29     BKP_DR30 //Chip backup 16-bit register 
#define BACKUP_REG_30     BKP_DR31 //Chip backup 16-bit register
#define BACKUP_REG_31     BKP_DR32 //Chip backup 16-bit register
#define BACKUP_REG_32     BKP_DR33 //Chip backup 16-bit register 
#define BACKUP_REG_33     BKP_DR34 //Chip backup 16-bit register
#define BACKUP_REG_34     BKP_DR35 //Chip backup 16-bit register
#define BACKUP_REG_35     BKP_DR36 //Chip backup 16-bit register 
#define BACKUP_REG_36     BKP_DR37 //Chip backup 16-bit register
#define BACKUP_REG_37     BKP_DR38 //Chip backup 16-bit register
#define BACKUP_REG_38     BKP_DR39 //Chip backup 16-bit register 
#define BACKUP_REG_39     BKP_DR40 //Chip backup 16-bit register
#define BACKUP_REG_40     BKP_DR41 //Chip backup 16-bit register
#define BACKUP_REG_41     BKP_DR42 //Chip backup 16-bit register 

//GLOBAL VARIABLES

//PROTOTYPES
//init access to backup registers
void BACKUP_Init();
//deinit backup subsystem, stop PWR and BKP clocks (RTC access breaks)
void BACKUP_Exit();
//read backup register
u32 APIEXPORT BACKUP_Read(u32 regNo);
//write backup register
void APIEXPORT BACKUP_Write(u32 regNo, u32 val);
//return 0 if key invalid, return 1 if key valid
u32  APIEXPORT BACKUP_isValid();

#endif // MY_BACKUP_H