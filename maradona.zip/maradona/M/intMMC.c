/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "intMMC.h"
#include "debugTerm.h"


//FUNCTIONS
//73  PB12 SPI2_NSS   MMCint CS  ������������ ��� ����.
//74  PB13 SPI2_SCK   MMC CLK
//75  PB14 SPI2_MISO  MMC DO
//76  PB15 SPI2_MOSI  MMC DI
//Select SD Card: ChipSelect pin low
#define INTMMC_CS_LOW()     GPIO_ResetBits(GPIOB, GPIO_Pin_12) 
//Deselect SD Card: ChipSelect pin high 
#define INTMMC_CS_HIGH()    GPIO_SetBits(GPIOB, GPIO_Pin_12) 
/**
  * @brief  Start Data tokens:
  *         Tokens (necessary because at nop/idle (and CS active) only 0xff is 
  *         on the data/command line)  
  */
#define INTMMC_START_DATA_SINGLE_BLOCK_READ    0xFE  /*!< Data token start byte, Start Single Block Read */
#define INTMMC_START_DATA_MULTIPLE_BLOCK_READ  0xFE  /*!< Data token start byte, Start Multiple Block Read */
#define INTMMC_START_DATA_SINGLE_BLOCK_WRITE   0xFE  /*!< Data token start byte, Start Single Block Write */
#define INTMMC_START_DATA_MULTIPLE_BLOCK_WRITE 0xFD  /*!< Data token start byte, Start Multiple Block Write */
#define INTMMC_STOP_DATA_MULTIPLE_BLOCK_WRITE  0xFD  /*!< Data toke stop byte, Stop Multiple Block Write */

#define INTMMC_DUMMY_BYTE   0xFF

//private function definition
void INTMMC_InitHw(); //init hardware


//init hardware
void INTMMC_InitHw()
{
    //init SPI pins and control pin
    //init spi
  GPIO_InitTypeDef  GPIO_InitStructure;
  SPI_InitTypeDef   SPI_InitStructure;

  //pin clock enable 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);

  /*!< SD_SPI Periph clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);

  /*!< Configure pins: SCK */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /*!< Configure SD_SPI pins: MOSI */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /*!< Configure SD_SPI pins: MISO */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  /*!< Configure SD_SPI_CS_PIN pin: SD Card CS pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /*!< SD_SPI Config */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//ok
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;//ok
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;//ok
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;//=0
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;//=0 debug : old 2edge
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft; //nss pin off
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;//2=12m@mode48
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;  //ok
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI2, &SPI_InitStructure);
  
  SPI_Cmd(SPI2, ENABLE); /*!< SD_SPI enable */
}

void INTMMC_Exit()
{
    //free SPI pins and control pin
    //...
      GPIO_InitTypeDef  GPIO_InitStructure;
  
  SPI_Cmd(SPI2, DISABLE); /*!< SD_SPI disable */
  SPI_I2S_DeInit(SPI2);   /*!< DeInitializes the SD_SPI */
  
  /*!< SD_SPI Periph clock disable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, DISABLE);
  
  /*!< Configure SD_SPI pins:*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

}


/**
  * @brief  Write a byte on the SD.
  * @param  Data: byte to send.
  * @retval None
  */
uint8_t INTMMC_SpiReadWriteByte(uint8_t Data)
{
  /*!< Wait until the transmit buffer is empty */
  while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)
  {
  }
  
  /*!< Send the byte */
  SPI_I2S_SendData(SPI2, Data);
  
  /*!< Wait to receive a byte*/
  while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)
  {
  }
  
  /*!< Return the byte read from the SPI bus */ 
  return SPI_I2S_ReceiveData(SPI2);
}

/**
  * @brief  Read a byte from the SD.
  * @param  None
  * @retval The received byte.
  */
//uint8_t INTMMC_ReadByte(void)
//{
//  uint8_t Data = 0;
//  
//  /*!< Wait until the transmit buffer is empty */
//  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)
//  {
//  }
//  /*!< Send the byte */
//  SPI_I2S_SendData(SPI2, INTMMC_DUMMY_BYTE);
//
//  /*!< Wait until a data is received */
//  while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)
//  {
//  }
//  /*!< Get the received data */
//  Data = SPI_I2S_ReceiveData(SPI2);
//
//  /*!< Return the shifted data */
//  return Data;
//}


///////////////////////////////////////////////////////////////////////////////////



/**
  * @brief  Initializes the SD/SD communication.
  * @param  None
  * @retval The SD Response: 
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_Init(void)
{
  uint32_t i = 0;

  /*!< Initialize SPI */
  INTMMC_InitHw(); 

  /*!< SD chip select high */
  INTMMC_CS_HIGH();

  //DBG_printfn("1", 1);   
  /*!< Send dummy byte 0xFF, 10 times with CS high */
  /*!< Rise CS and MOSI for 80 clocks cycles */
  for (i = 0; i < 80; i++)      //DEBUG: 80 bytes send for card initiation
  {
    /*!< Send dummy byte 0xFF */
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
  }
  
  //DBG_printfn("2", 1);
  /*------------Put SD in SPI mode--------------*/
  /*!< SD initialized and set to SPI mode properly */
   return (INTMMC_GoActive());
}

//soft reset card to idle mode 
INTMMC_Error INTMMC_GoIdle(void)
{
	/*!< SD chip select low */
	INTMMC_CS_LOW();
	/*!< Send CMD0 (SD_CMD_GO_IDLE_STATE) to put SD in SPI mode */
	INTMMC_SendCmd(INTMMC_CMD_GO_IDLE_STATE, 0, 0x95);

	/*!< Wait for In Idle State Response (R1 Format) equal to 0x01 */
	if (INTMMC_GetResponse(INTMMC_IN_IDLE_STATE))
	{
		/*!< No Idle State Response: return response failue */
		return INTMMC_RESPONSE_FAILURE;
	}
	INTMMC_CS_HIGH();
	return INTMMC_RESPONSE_NO_ERROR;
}

//activate card from idle mode
INTMMC_Error INTMMC_GoActive(void)
{
	//reset card if not been reset
	if(INTMMC_GoIdle() != INTMMC_RESPONSE_NO_ERROR) return INTMMC_RESPONSE_FAILURE;
	//initialize card
	do
	{
		/*!< SD chip select high */
		INTMMC_CS_HIGH();
		//Send Dummy byte 0xFF
		INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

		/*!< SD chip select low */
		INTMMC_CS_LOW();

		/*!< Send CMD1 (Activates the card process) until response equal to 0x0 */
		INTMMC_SendCmd(INTMMC_CMD_SEND_OP_COND, 0, 0xFF);
		/*!< Wait for no error Response (R1 Format) equal to 0x00 */
	}
	while (INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR));

	/*!< SD chip select high */
	INTMMC_CS_HIGH();

	/*!< Send dummy byte 0xFF */
	INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
	return INTMMC_RESPONSE_NO_ERROR;
}


/**
  * @brief  Returns information about specific card.
  * @param  cardinfo: pointer to a INTMMC_CardInfo structure that contains all SD 
  *         card information.
  * @retval The SD Response:
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_GetCardInfo(INTMMC_CardInfo *cardinfo)
{
  INTMMC_Error status = INTMMC_RESPONSE_FAILURE;

  status = INTMMC_GetCSDRegister(&(cardinfo->SD_csd));
  status = INTMMC_GetCIDRegister(&(cardinfo->SD_cid));
  cardinfo->CardCapacity = (cardinfo->SD_csd.DeviceSize + 1) ;
  cardinfo->CardCapacity *= (1 << (cardinfo->SD_csd.DeviceSizeMul + 2));
  cardinfo->CardBlockSize = 1 << (cardinfo->SD_csd.RdBlockLen);
  cardinfo->CardCapacity *= cardinfo->CardBlockSize;

  /*!< Returns the reponse */
  return status;
}

/**
  * @brief  Reads a block of data from the SD.
  * @param  pBuffer: pointer to the buffer that receives the data read from the 
  *                  SD.
  * @param  ReadAddr: SD's internal address to read from.
  * @retval The SD Response:
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_ReadBlock(uint8_t* pBuffer, uint32_t ReadAddr)
{
  uint32_t i = 0;
  INTMMC_Error rvalue = INTMMC_RESPONSE_FAILURE;

  /*!< SD chip select low */
  INTMMC_CS_LOW();
  
  /*!< Send CMD17 (SD_CMD_READ_SINGLE_BLOCK) to read one block */
  INTMMC_SendCmd(INTMMC_CMD_READ_SINGLE_BLOCK, ReadAddr, 0xFF);
  
  /*!< Check if the SD acknowledged the read block command: R1 response (0x00: no errors) */
  if (!INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR))
  {
    /*!< Now look for the data token to signify the start of the data */
    if (!INTMMC_GetResponse(INTMMC_START_DATA_SINGLE_BLOCK_READ))
    {
      /*!< Read the SD block data : read NumByteToRead data */
      for (i = 0; i < 512; i++)
      {
        /*!< Save the received data */
        *pBuffer = INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
       
        /*!< Point to the next location where the byte read will be saved */
        pBuffer++;
      }
      /*!< Get CRC bytes (not really needed by us, but required by SD) */
      INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
      INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
      /*!< Set response value to success */
      rvalue = INTMMC_RESPONSE_NO_ERROR;
    }
  }
  /*!< SD chip select high */
  INTMMC_CS_HIGH();
  
  /*!< Send dummy byte: 8 Clock pulses of delay */
  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
  
  /*!< Returns the reponse */
  return rvalue;
}


/**
  * @brief  Writes a block on the SD
  * @param  pBuffer: pointer to the buffer containing the data to be written on 
  *                  the SD.
  * @param  WriteAddr: address to write on.
  * @retval The SD Response: 
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_WriteBlock(uint8_t* pBuffer, uint32_t WriteAddr)
{
  uint32_t i = 0;
  INTMMC_Error rvalue = INTMMC_RESPONSE_FAILURE;

  /*!< SD chip select low */
  INTMMC_CS_LOW();

  /*!< Send CMD24 (INTMMC_CMD_WRITE_SINGLE_BLOCK) to write block */
  INTMMC_SendCmd(INTMMC_CMD_WRITE_SINGLE_BLOCK, WriteAddr, 0xFF);
  
  /*!< Check if the SD acknowledged the write block command: R1 response (0x00: no errors) */
  if (!INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR))
  {
    /*!< Send a dummy byte */
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

    /*!< Send the data token to signify the start of the data */
    INTMMC_SpiReadWriteByte(0xFE);

    /*!< Write the block data to SD : write count data by block */
    for (i = 0; i < 512; i++)
    {
      /*!< Send the pointed byte */
      INTMMC_SpiReadWriteByte(*pBuffer);
      /*!< Point to the next location where the byte read will be saved */
      pBuffer++;
    }
    /*!< Put CRC bytes (not really needed by us, but required by SD) */
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

    /*!< Read data response */
    if (INTMMC_GetDataResponse() == INTMMC_DATA_OK)
    {
      rvalue = INTMMC_RESPONSE_NO_ERROR;
    }
  }
  /*!< SD chip select high */
  INTMMC_CS_HIGH();
  /*!< Send dummy byte: 8 Clock pulses of delay */
  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

  /*!< Returns the reponse */
  return rvalue;
}

/**
  * @brief  Read the CSD card register.
  *         Reading the contents of the CSD register in SPI mode is a simple 
  *         read-block transaction.
  * @param  SD_csd: pointer on an SCD register structure
  * @retval The SD Response: 
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_GetCSDRegister(INTMMC_CSD* SD_csd)
{
  uint32_t i = 0;
  INTMMC_Error rvalue = INTMMC_RESPONSE_FAILURE;
  uint8_t CSD_Tab[16];

  /*!< SD chip select low */
  INTMMC_CS_LOW();
  /*!< Send CMD9 (CSD register) or CMD10(CSD register) */
  INTMMC_SendCmd(INTMMC_CMD_SEND_CSD, 0, 0xFF);
  /*!< Wait for response in the R1 format (0x00 is no errors) */
  if (!INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR))
  {
    if (!INTMMC_GetResponse(INTMMC_START_DATA_SINGLE_BLOCK_READ))
    {
      for (i = 0; i < 16; i++)
      {
        /*!< Store CSD register value on CSD_Tab */
        CSD_Tab[i] = INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
      }
    }
    /*!< Get CRC bytes (not really needed by us, but required by SD) */
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    /*!< Set response value to success */
    rvalue = INTMMC_RESPONSE_NO_ERROR;
  }
  /*!< SD chip select high */
  INTMMC_CS_HIGH();
  /*!< Send dummy byte: 8 Clock pulses of delay */
  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

  /*!< Byte 0 */
  SD_csd->CSDStruct = (CSD_Tab[0] & 0xC0) >> 6;
  SD_csd->SysSpecVersion = (CSD_Tab[0] & 0x3C) >> 2;
  SD_csd->Reserved1 = CSD_Tab[0] & 0x03;

  /*!< Byte 1 */
  SD_csd->TAAC = CSD_Tab[1];

  /*!< Byte 2 */
  SD_csd->NSAC = CSD_Tab[2];

  /*!< Byte 3 */
  SD_csd->MaxBusClkFrec = CSD_Tab[3];

  /*!< Byte 4 */
  SD_csd->CardComdClasses = CSD_Tab[4] << 4;

  /*!< Byte 5 */
  SD_csd->CardComdClasses |= (CSD_Tab[5] & 0xF0) >> 4;
  SD_csd->RdBlockLen = CSD_Tab[5] & 0x0F;

  /*!< Byte 6 */
  SD_csd->PartBlockRead = (CSD_Tab[6] & 0x80) >> 7;
  SD_csd->WrBlockMisalign = (CSD_Tab[6] & 0x40) >> 6;
  SD_csd->RdBlockMisalign = (CSD_Tab[6] & 0x20) >> 5;
  SD_csd->DSRImpl = (CSD_Tab[6] & 0x10) >> 4;
  SD_csd->Reserved2 = 0; /*!< Reserved */

  SD_csd->DeviceSize = (CSD_Tab[6] & 0x03) << 10;

  /*!< Byte 7 */
  SD_csd->DeviceSize |= (CSD_Tab[7]) << 2;

  /*!< Byte 8 */
  SD_csd->DeviceSize |= (CSD_Tab[8] & 0xC0) >> 6;

  SD_csd->MaxRdCurrentVDDMin = (CSD_Tab[8] & 0x38) >> 3;
  SD_csd->MaxRdCurrentVDDMax = (CSD_Tab[8] & 0x07);

  /*!< Byte 9 */
  SD_csd->MaxWrCurrentVDDMin = (CSD_Tab[9] & 0xE0) >> 5;
  SD_csd->MaxWrCurrentVDDMax = (CSD_Tab[9] & 0x1C) >> 2;
  SD_csd->DeviceSizeMul = (CSD_Tab[9] & 0x03) << 1;
  /*!< Byte 10 */
  SD_csd->DeviceSizeMul |= (CSD_Tab[10] & 0x80) >> 7;
    
  SD_csd->EraseGrSize = (CSD_Tab[10] & 0x40) >> 6;
  SD_csd->EraseGrMul = (CSD_Tab[10] & 0x3F) << 1;

  /*!< Byte 11 */
  SD_csd->EraseGrMul |= (CSD_Tab[11] & 0x80) >> 7;
  SD_csd->WrProtectGrSize = (CSD_Tab[11] & 0x7F);

  /*!< Byte 12 */
  SD_csd->WrProtectGrEnable = (CSD_Tab[12] & 0x80) >> 7;
  SD_csd->ManDeflECC = (CSD_Tab[12] & 0x60) >> 5;
  SD_csd->WrSpeedFact = (CSD_Tab[12] & 0x1C) >> 2;
  SD_csd->MaxWrBlockLen = (CSD_Tab[12] & 0x03) << 2;

  /*!< Byte 13 */
  SD_csd->MaxWrBlockLen |= (CSD_Tab[13] & 0xC0) >> 6;
  SD_csd->WriteBlockPaPartial = (CSD_Tab[13] & 0x20) >> 5;
  SD_csd->Reserved3 = 0;
  SD_csd->ContentProtectAppli = (CSD_Tab[13] & 0x01);

  /*!< Byte 14 */
  SD_csd->FileFormatGrouop = (CSD_Tab[14] & 0x80) >> 7;
  SD_csd->CopyFlag = (CSD_Tab[14] & 0x40) >> 6;
  SD_csd->PermWrProtect = (CSD_Tab[14] & 0x20) >> 5;
  SD_csd->TempWrProtect = (CSD_Tab[14] & 0x10) >> 4;
  SD_csd->FileFormat = (CSD_Tab[14] & 0x0C) >> 2;
  SD_csd->ECC = (CSD_Tab[14] & 0x03);

  /*!< Byte 15 */
  SD_csd->CSD_CRC = (CSD_Tab[15] & 0xFE) >> 1;
  SD_csd->Reserved4 = 1;

  /*!< Return the reponse */
  return rvalue;
}

/**
  * @brief  Read the CID card register.
  *         Reading the contents of the CID register in SPI mode is a simple 
  *         read-block transaction.
  * @param  SD_cid: pointer on an CID register structure
  * @retval The SD Response: 
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_GetCIDRegister(INTMMC_CID* SD_cid)
{
  uint32_t i = 0;
  INTMMC_Error rvalue = INTMMC_RESPONSE_FAILURE;
  uint8_t CID_Tab[16];
  
  /*!< SD chip select low */
  INTMMC_CS_LOW();
  
  /*!< Send CMD10 (CID register) */
  INTMMC_SendCmd(INTMMC_CMD_SEND_CID, 0, 0xFF);
  
  /*!< Wait for response in the R1 format (0x00 is no errors) */
  if (!INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR))
  {
    if (!INTMMC_GetResponse(INTMMC_START_DATA_SINGLE_BLOCK_READ))
    {
      /*!< Store CID register value on CID_Tab */
      for (i = 0; i < 16; i++)
      {
        CID_Tab[i] = INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
      }
    }
    /*!< Get CRC bytes (not really needed by us, but required by SD) */
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    /*!< Set response value to success */
    rvalue = INTMMC_RESPONSE_NO_ERROR;
  }
  /*!< SD chip select high */
  INTMMC_CS_HIGH();
  /*!< Send dummy byte: 8 Clock pulses of delay */
  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

  /*!< Byte 0 */
  SD_cid->ManufacturerID = CID_Tab[0];

  /*!< Byte 1 */
  SD_cid->OEM_AppliID = CID_Tab[1] << 8;

  /*!< Byte 2 */
  SD_cid->OEM_AppliID |= CID_Tab[2];

  /*!< Byte 3 */
  SD_cid->ProdName1 = CID_Tab[3] << 24;

  /*!< Byte 4 */
  SD_cid->ProdName1 |= CID_Tab[4] << 16;

  /*!< Byte 5 */
  SD_cid->ProdName1 |= CID_Tab[5] << 8;

  /*!< Byte 6 */
  SD_cid->ProdName1 |= CID_Tab[6];

  /*!< Byte 7 */
  SD_cid->ProdName2 = CID_Tab[7];

  /*!< Byte 8 */
  SD_cid->ProdRev = CID_Tab[8];

  /*!< Byte 9 */
  SD_cid->ProdSN = CID_Tab[9] << 24;

  /*!< Byte 10 */
  SD_cid->ProdSN |= CID_Tab[10] << 16;

  /*!< Byte 11 */
  SD_cid->ProdSN |= CID_Tab[11] << 8;

  /*!< Byte 12 */
  SD_cid->ProdSN |= CID_Tab[12];

  /*!< Byte 13 */
  SD_cid->Reserved1 |= (CID_Tab[13] & 0xF0) >> 4;
  SD_cid->ManufactDate = (CID_Tab[13] & 0x0F) << 8;

  /*!< Byte 14 */
  SD_cid->ManufactDate |= CID_Tab[14];

  /*!< Byte 15 */
  SD_cid->CID_CRC = (CID_Tab[15] & 0xFE) >> 1;
  SD_cid->Reserved2 = 1;

  /*!< Return the reponse */
  return rvalue;
}

/**
  * @brief  Send 5 bytes command to the SD card.
  * @param  Cmd: The user expected command to send to SD card.
  * @param  Arg: The command argument.
  * @param  Crc: The CRC.
  * @retval None
  */
void INTMMC_SendCmd(uint8_t Cmd, uint32_t Arg, uint8_t Crc)
{
  uint32_t i = 0x00;
  
  uint8_t Frame[6];
  
  Frame[0] = (Cmd | 0x40); /*!< Construct byte 1 */
  
  Frame[1] = (uint8_t)(Arg >> 24); /*!< Construct byte 2 */
  
  Frame[2] = (uint8_t)(Arg >> 16); /*!< Construct byte 3 */
  
  Frame[3] = (uint8_t)(Arg >> 8); /*!< Construct byte 4 */
  
  Frame[4] = (uint8_t)(Arg); /*!< Construct byte 5 */
  
  Frame[5] = (Crc); /*!< Construct CRC: byte 6 */
  
  for (i = 0; i < 6; i++)
  {
    INTMMC_SpiReadWriteByte(Frame[i]); /*!< Send the Cmd bytes */
  }
}

/**
  * @brief  Get SD card data response.
  * @param  None
  * @retval The SD status: Read data response xxx0<status>1
  *         - status 010: Data accecpted
  *         - status 101: Data rejected due to a crc error
  *         - status 110: Data rejected due to a Write error.
  *         - status 111: Data rejected due to other error.
  */
uint8_t INTMMC_GetDataResponse(void)
{
  uint32_t i = 0;
  uint8_t response, rvalue;

  while (i <= 64)
  {
    /*!< Read resonse */
    response = INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
    /*!< Mask unused bits */
    response &= 0x1F;
    switch (response)
    {
      case INTMMC_DATA_OK:
      {
        rvalue = INTMMC_DATA_OK;
        break;
      }
      case INTMMC_DATA_CRC_ERROR:
        return INTMMC_DATA_CRC_ERROR;
      case INTMMC_DATA_WRITE_ERROR:
        return INTMMC_DATA_WRITE_ERROR;
      default:
      {
        rvalue = INTMMC_DATA_OTHER_ERROR;
        break;
      }
    }
    /*!< Exit loop in case of data ok */
    if (rvalue == INTMMC_DATA_OK)
      break;
    /*!< Increment loop counter */
    i++;
  }

  /*!< Wait null data */
  while (INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE) == 0);

  /*!< Return response */
  return response;
}

/**
  * @brief  Returns the SD response.
  * @param  None
  * @retval The SD Response: 
  *         - SD_RESPONSE_FAILURE: Sequence failed
  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
  */
INTMMC_Error INTMMC_GetResponse(uint8_t Response)
{
  uint32_t Count = 0xFFFF; //debug: old=0xFFF

  /*!< Check if response is got or a timeout is happen */
  while ((INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE) != Response) && Count)
  {
    Count--;
  }
  if (Count == 0)
  {
    /*!< After time out */
    return INTMMC_RESPONSE_FAILURE;
  }
  else
  {
    /*!< Right response got */
    return INTMMC_RESPONSE_NO_ERROR;
  }
}

/**
  * @brief  Returns the SD status.
  * @param  None
  * @retval The SD status.
  */
uint16_t INTMMC_GetStatus(void)
{
  uint16_t Status = 0;

  /*!< SD chip select low */
  INTMMC_CS_LOW();

  /*!< Send CMD13 (SD_SEND_STATUS) to get SD status */
  INTMMC_SendCmd(INTMMC_CMD_SEND_STATUS, 0, 0xFF);

  Status = INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
  Status |= (uint16_t)(INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE) << 8);

  /*!< SD chip select high */
  INTMMC_CS_HIGH();

  /*!< Send dummy byte 0xFF */
  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);

  return Status;
}

///**
//  * @brief  Put SD in Idle state.
//  * @param  None
//  * @retval The SD Response: 
//  *         - SD_RESPONSE_FAILURE: Sequence failed
//  *         - SD_RESPONSE_NO_ERROR: Sequence succeed
//  */
//INTMMC_Error INTMMC_GoIdleState(void)
//{
//  /*!< SD chip select low */
//  INTMMC_CS_LOW();
//  /*!< Send CMD0 (SD_CMD_GO_IDLE_STATE) to put SD in SPI mode */
//  INTMMC_SendCmd(INTMMC_CMD_GO_IDLE_STATE, 0, 0x95);
//
//  /*!< Wait for In Idle State Response (R1 Format) equal to 0x01 */
//  if (INTMMC_GetResponse(INTMMC_IN_IDLE_STATE))
//  {
//    /*!< No Idle State Response: return response failue */
//   return INTMMC_RESPONSE_FAILURE;
//  }
//  /*----------Activates the card initialization process-----------*/
//  do
//  {
//    /*!< SD chip select high */
//    INTMMC_CS_HIGH();
//    //DBG_printfn("4", 1);
//    /*!< Send Dummy byte 0xFF */
//    INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
//    
//    /*!< SD chip select low */
//    INTMMC_CS_LOW();
//    
//    /*!< Send CMD1 (Activates the card process) until response equal to 0x0 */
//    INTMMC_SendCmd(INTMMC_CMD_SEND_OP_COND, 0, 0xFF);
//    /*!< Wait for no error Response (R1 Format) equal to 0x00 */
//  }
//  while (INTMMC_GetResponse(INTMMC_RESPONSE_NO_ERROR));
//  
//  /*!< SD chip select high */
//  INTMMC_CS_HIGH();
//  
//  /*!< Send dummy byte 0xFF */
//  INTMMC_SpiReadWriteByte(INTMMC_DUMMY_BYTE);
//  return INTMMC_RESPONSE_NO_ERROR;
//}

