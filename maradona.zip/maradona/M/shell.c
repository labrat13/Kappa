/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for SHELL subsystem of Maradona project
// Jan 4, 2013: initial
// Main application for system

***********************************************************/
#include "hub.h"
#include "window.h"
#include "draw_.h"
#include "GData.h"
#include "debugTerm.h"
#include "colors.h"
#include "strings_.h"


const u32 hInstance = 0;
void SHELL_onPaint(PWND pWnd);//paint shell window
void onNcPaint(PWND pWnd);//paint non-client shell window
u32 SHELL_wndProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval);//shell window handler
u32 SHELL_main(void); //shell main function
PWND SHELL_CreateLabel(u8* text, PWND pParent, u32 styles, u32 parX, u32 parY, u32 width, u32 height, u32 hInstance);
u32 SHELL_RegisterClasses(); //return 0 if any error, !0 if success
u32 SHELL_DefControlProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval);//process control messages by default
void SHELL_onControlNcPaint(PWND pWnd);//paint non-client area of control
void SHELL_onControlPaint(PWND pWnd); //paint client area of control
u32 SHELL_ControlWindowProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval); //window handler for control windows


//PRIVATE VARIABLES
PWND SHELL_pMainWnd;
HUB_MSG SHELL_Msg;

//FUNCTIONS



u32 SHELL_Init()
{
    HUB_EnableEventProcessing();
    return SHELL_main();
    
}

void SHELL_Exit()
{
    HUB_DisableEventProcessing();
    
}

//shell main function
u32 SHELL_main(void)
{
    GDATA_RECT rc;
    
    DRAW_GetDisplayRect(&rc);
    
    DBG_printfn((u8*)"U1", 2);
    //1 - register window class
	u32 classId = WND_RegisterClass(
		hInstance,	//app instance = 0
		SHELL_wndProc,	//wnd proc address
		0);			//class styles - no styles defined
	//register system window classes
	if(SHELL_RegisterClasses() == 0)
	{
		//system classes not initialized properly
	}
    DBG_printfn((u8*)"U2", 2);
	//2 - create window

	SHELL_pMainWnd = WND_CreateWindow(
		classId,	//class identifier
		0,	//window styles
		0,			//X
		0,			//Y
		rc.Width,		//Width of window =  display
		rc.Height,		//Height of window = display
		0,	//Parent wnd
		0,		//Menu of window ?
		hInstance); //app instance = 0
	if(SHELL_pMainWnd == 0) return 1;
	//create label
	PWND labWnd = SHELL_CreateLabel((u8*)"Label", SHELL_pMainWnd, WND_WS_BORDER | WND_WS_VISIBLE, 10, 10, 60, 20, hInstance);
	
	DBG_printfn((u8*)"U3", 2);
	//3 - init app resources
	

	//4 - show window
	WND_ShowWindow(SHELL_pMainWnd, 1); //set or clear window show state flag
	//set show flag for childs?
	DBG_printfn((u8*)"U4", 2);
    WND_UpdateWindow(SHELL_pMainWnd);//send PAINT and NCPAINT message directly to window procedure
	//send update message to all childs
    DBG_printfn((u8*)"U5", 2);
	//5 - message loop

	//while(1);
        
    while(HUB_GetMessage(&SHELL_Msg, 0, MSG_MIN, MSG_MAX))
	{
		DBG_printfn((u8*)"U9", 2);
        //add some msg translators here
		HUB_DispatchMessage(&SHELL_Msg);
	}
	
    DBG_printfn((u8*)"UE", 2);
	//release application resources here?
    return 0;
}

//paint shell window
void SHELL_onPaint(PWND pWnd)
{
	GDATA_RECT rc;
    DBG_printfn((u8*)"U6", 2);
    DRAW_GetDisplayRect(&rc);  //window client rectangle for drawing
	//TODO: add application drawing code here
	DRAW_FillRect(&rc, COLOR_Gray);
}

//paint non-client shell window
void onNcPaint(PWND pWnd)
{
	//GDATA_RECT rc;
	//WND_GetWindowRect(pWnd, &rc);  //window non-client area for drawing
	//TODO: add application drawing code here

}

//shell window handler
u32 SHELL_wndProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval)
{
	DBG_printfn((u8*)"U7", 2);
    DBG_printHex(msgCode);
    switch(msgCode)
	{
	case MSG_COMMAND: //menu processing
		break;
	case MSG_PAINT:
		SHELL_onPaint(pWnd); //����������
		break;
	case MSG_NCPAINT:
		onNcPaint(pWnd);
		break;
	case MSG_TOUCHSCREEN_BUTTON_1_UP: //
                DBG_printfn((u8*)"B1", 2);
		break;
	case MSG_TOUCHSCREEN_BUTTON_2_UP: //
                DBG_printfn((u8*)"B2", 2);
		break;
	case MSG_TOUCHSCREEN_BUTTON_3_UP: //
                DBG_printfn((u8*)"B3", 2);
		break;
	case MSG_TOUCHSCREEN_BUTTON_4_UP: //
                DBG_printfn((u8*)"B4", 2);
		break;
	case MSG_TOUCHSCREEN_BUTTON_5_UP: //
                DBG_printfn((u8*)"B5", 2);
		break;
	case MSG_TOUCHSCREEN_SCREEN_DOWN:
                DBG_printfn((u8*)"SD", 2);
    return WND_DefWindowProc(pWnd, msgCode, Xval, Yval);
		//��������� ��������� �������
		break;
	case MSG_TOUCHSCREEN_SCREEN_MOVE:
                DBG_printfn((u8*)"SM", 2);
    return WND_DefWindowProc(pWnd, msgCode, Xval, Yval);
		//��������� ��������� � ������������ �������
		break;
	case MSG_TOUCHSCREEN_SCREEN_UP:
		//��������� ��������� �������
        DBG_printfn((u8*)"SU", 2);
    return WND_DefWindowProc(pWnd, msgCode, Xval, Yval);
		break;
	case MSG_STILUS_DOWN:
		DBG_printfn((u8*)"S1", 2);
		break;
	case MSG_STILUS_MOVE:
		DBG_printfn((u8*)"S2", 2);
		break;
	case MSG_STILUS_UP:
		DBG_printfn((u8*)"S3", 2);
		HUB_PostMessage(pWnd, MSG_CLOSE, 0, 0);
		break;
	case MSG_LOSTFOCUS:
		break;
	case MSG_CLOSE:
		//prompt to confirm closing window
        DBG_printfn((u8*)"E1", 2);
        WND_DestroyWindow(pWnd);
		break;
	case MSG_NCDESTROY: //
		break;
	case MSG_DESTROY:
		//PostQuitMessage(0); //0=app result code
	    DBG_printfn((u8*)"E2", 2);	
        HUB_PostMessage(pWnd, MSG_QUIT, 0, 0);
		break;
	default:
		return WND_DefWindowProc(pWnd, msgCode, Xval, Yval);
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////
//          CONTROL WINDOW PROCEDURES
//
//
////////////////////////////////////////////////////////////////////


//window handler for control windows
u32 SHELL_ControlWindowProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval)
{
	//DBG_printfn((u8*)"c7", 2);
    //DBG_printHex(msgCode);
    switch(msgCode)
	{
	case MSG_COMMAND: //menu processing
		break;
	case MSG_PAINT:
		SHELL_onControlPaint(pWnd);
		break;
	case MSG_NCPAINT:
		SHELL_onControlNcPaint(pWnd);
		break;
	case MSG_STILUS_DOWN:
		//DBG_printfn((u8*)"S1", 2);
		break;
	case MSG_STILUS_MOVE:
		//DBG_printfn((u8*)"S2", 2);
		break;
	case MSG_STILUS_UP:
		//DBG_printfn((u8*)"S3", 2);
		break;
	case MSG_LOSTFOCUS:
		break;
	case MSG_NCDESTROY: 
		break;
	case MSG_DESTROY:
		break;
	default:
		return SHELL_DefControlProc(pWnd, msgCode, Xval, Yval);
        break;
	}
	return 0;
}

//paint client area of control
void SHELL_onControlPaint(PWND pWnd)
{
	GDATA_RECT rc;
	GDATA_RECT rcText;
	WND_GetClientRect(pWnd, &rc);
	DRAW_FillRect(&rc, COLOR_Gray);
	//draw text
	//simple
	u8* text = (u8*)(pWnd->Value);
	u32 len = STRINGS_strlen(text);
	GDATA_SIZE sz;
	DRAW_GetStringSize(text, len, &sz);
	rcText.Width = sz.Width;
	rcText.Height = sz.Height;
	GDATA_rectAlign(&rc, &rcText, GDATA_ALIGN_LEFT);
	rcText.X = rcText.X + 4;
	DRAW_String(text, len, rcText.X, rcText.Y, COLOR_Black, COLOR_Gray);
	return;
}

//paint non-client area of control
void SHELL_onControlNcPaint(PWND pWnd)
{
	//u16 clsId = pWnd->pClass->ClassId;
	//draw border if specified style set
	GDATA_RECT rc;
	WND_GetClientRect(pWnd, &rc);
	if(pWnd->WindowStyle & WND_WS_BORDER)
	{
		DRAW_drawBorderAround(rc.X, rc.Y, rc.Width, rc.Height, DRAW_BORDER_INACTIVE_POPPED);
	}
	return;
}

//process control messages by default
u32 SHELL_DefControlProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval)
{
	
	return 0;
}

//register system window classes
//return 0 if any error, !0 if success
u32 SHELL_RegisterClasses()
{
	u32 clsId;
	//register label class
	clsId = WND_RegisterClass(
		hInstance,					//app instance
		SHELL_ControlWindowProc,	//wnd proc address
		0);							//class styles
	if(clsId != WND_CLASS_LABEL) return 0; //class not match classID or is invalid
	//add more classes here
	return clsId;
}

PWND SHELL_CreateLabel(u8* text, PWND pParent, u32 styles, u32 parX, u32 parY, u32 width, u32 height, u32 hInst)
{
    PWND res;
	GDATA_RECT rc;
	WND_GetClientRect(pParent, &rc);
	res = WND_CreateWindow(WND_CLASS_LABEL, styles, rc.X + parX, rc.Y + parY, width, height, pParent, 0, hInst);
	if(res != 0) res->Value = (u32) text;
	return res;
}



























