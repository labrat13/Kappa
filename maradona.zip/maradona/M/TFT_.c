/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES

#include "TFT_.h"
#include "Font.h" //font table, remap table


#define TFTDATA (u16*) 0x62000000  //data address = 0x62000000
#define TFTCMD  (u16*) 0x60000000  //cmd address = 0x60000000

//some tft commands
#define TFT_NOP     0x00
#define TFT_CASET   0x2A
#define TFT_RASET   0x2B
#define TFT_RAMWR   0x2C
#define TFT_RAMRD   0x2E
#define TFT_COLMOD  0x3A
#define TFT_MADCTL  0x36

//color modes
#define TFT_COLORMODE_565	0x55
#define TFT_COLORMODE_666	0x66	

//PRIVATE DEFINITIONS
inline void TFT_writeCmd(u16 val);
inline void TFT_writeData(u16 val);
inline u16 TFT_readData();
inline void TFT_hardReset();//hard reset tft, need wait for 120 mS min after reset
//set new color mode for tft display
void TFT_SetColorMode(u8 mode);
u16 TFT_pixelRxBG(u16 rx, u16 bg); //helper for TFT_Read
u16 TFT_pixelGRxB(u16 gr, u16 xb); //helper for TFT_Read


//FUNCTIONS
void TFT_Init()
{
	TFT_FsmcInit();

	//this function have 250mS delay after display reset
	//we can use this time if need some work - if refactore code and split initialization in main.c 
	TFT_DisplayInit();
}

void TFT_Exit()
{
	//Off LCD power    
	//disable all pin's to inputFloating

}
//init FSMC hardware for display
void TFT_FsmcInit()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
	FSMC_NORSRAMTimingInitTypeDef  read;
	FSMC_NORSRAMTimingInitTypeDef  write;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOG | RCC_APB2Periph_GPIOE, ENABLE);
	/* Enable the FSMC Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);
	/*-- GPIO Configuration ------------------------------------------------------*/ 
	/* SRAM Data lines configuration */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8 | GPIO_Pin_9 |
		GPIO_Pin_10 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure); 

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
		GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	/* SRAM Address lines configuration */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	/* NOE and NWE configuration */  
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 |GPIO_Pin_5;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	/* NE configuration */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; 
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	//reset configuration setup here!!
	//PD3 as manual pushpull
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	// GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	//set level now
	GPIO_SetBits(GPIOD, GPIO_Pin_3); //resetLine = high

	/*-- FSMC Configuration ------------------------------------------------------*/
	read.FSMC_AddressSetupTime = 1;  //20ns
	read.FSMC_AddressHoldTime = 1;  //10ns
	read.FSMC_DataSetupTime = 25; //360ns
	read.FSMC_BusTurnAroundDuration = 0; 
	read.FSMC_CLKDivision = 0;       //
	read.FSMC_DataLatency = 0;       //
	read.FSMC_AccessMode = FSMC_AccessMode_A; //modeA

	write.FSMC_AddressSetupTime = 1;  //20ns
	write.FSMC_AddressHoldTime = 1;  //10ns
	write.FSMC_DataSetupTime = 2; //50ns
	write.FSMC_BusTurnAroundDuration = 0; 
	write.FSMC_CLKDivision = 0;       //
	write.FSMC_DataLatency = 0;       //
	write.FSMC_AccessMode = FSMC_AccessMode_A; //modeA  

	FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
	FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
	FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
	FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
	FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
	FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
	FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Enable; //
	FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &read;
	FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &write;

	FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); 

	/* Enable FSMC Bank1_SRAM Bank */
	FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE); 

}
//tft display initialization
void TFT_DisplayInit()
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;

	//reset
	TFT_hardReset();
	//delay 250 ms (120 min)
	TIME_delay_ms(250);
	//sleep out
	*cmdaddr = 0x11; //SLEEP OUT 
	TIME_delay_ms(250);
	//set up display
	*cmdaddr = (0xC0); //PWCTR1
	*dataddr = (0x00);
	*cmdaddr = (0xc1); //PWCTR2
	*dataddr = (0xD0);
	*dataddr = (0x01);

	//set power in normal full color mode
	*cmdaddr = (0xC2); //PWCTR3
	*dataddr = (0x01);    
	*dataddr = (0xD4);
	*dataddr = (0x85);
	*dataddr = (0x00);
	*dataddr = (0x00);
	//set power control Idle 8color mode 
	*cmdaddr = (0xC3);
	*dataddr = (0x01);
	*dataddr = (0x22);
	*dataddr = (0x00);
	*dataddr = (0x00);
	*dataddr = (0x01); 
	//no power control for Partial mode (PWCTR5 0xc4)! 
	//unknown commands
	*cmdaddr = (0xF4);
	*dataddr = (0xFF);
	*dataddr = (0x3F);

	*cmdaddr = (0xF5);
	*dataddr = (0x10);
	//VCOM multimode default, may skip
	*cmdaddr = (0xFB);
	*dataddr = (0x7F);
	//set VCOMH voltage for Normal and Idle mode   
	*cmdaddr = (0xC5);
	*dataddr = (0xB6);
	*dataddr = (0x1A);
	//set VCOMAC voltage in Normal and Idle mode   
	*cmdaddr = (0xC6);
	*dataddr = (0x28);
	*dataddr = (0x00);
	// Idle mode off, Inversion off, Normal mode On (may skip?)   
	*cmdaddr = (0x38);    //IDMOFF
	*cmdaddr = (0x13);    //NORON 
	*cmdaddr = (0x20);    //INVOFF

	//set frame rate for full-color normal mode
	*cmdaddr = (0xB1);    //FRMCTR1-FRAME RATE CONTROL for the Full color Normal Mode
	*dataddr = (0x3C);   	// 00110000 = 75Hz? ,typical 60Hz@0x3C; max 90Hz@0x28, see datasheet       
	*dataddr = (0x02);   	//  typical         
	*dataddr = (0x02);   	//  typical        

	//Disable external synchro
	*cmdaddr = (0xBC);    //VSYNCOUT external disable (?)

	//Set draw area as display full
	//*cmdaddr = (0x2A);    //  CASET
	//*dataddr = (0x00);   	//        
	//*dataddr = (0x00);   	//  0        
	//*dataddr = (0x00);   	//        
	//*dataddr = (0xEF);   	// 239         
	//*cmdaddr = (0x2B);    // RASET
	//*dataddr = (0x00);   	//        
	//*dataddr = (0x00);   	//  0        
	//*dataddr = (0x01);   	//        
	//*dataddr = (0x3F);   	// 319         

	//tearing effect, after reset = 0( may skipped)  
	*cmdaddr = (0x35);    //TEON, Mode 1
	*dataddr = (0x00);   	//default    
	//set pixel mode 565
	*cmdaddr = (0x3A);        //COLMOD
	*dataddr = (TFT_COLORMODE_565);       //RGB565 format

	//Set scan order
	TFT_SetScanOrder(TFT_Portrait); //0=vertical orientation
	//delay 100 ms ???
	TIME_delay_ms(100);
	//display on
	*cmdaddr = (0x29); //display_On
}


inline void TFT_writeCmd(u16 val)
{
	volatile u16* addr = TFTCMD;
	*addr = val;
}

inline void TFT_writeData(u16 val)
{
	volatile u16* addr = TFTDATA;
	*addr = val;
}

inline u16 TFT_readData()
{
	volatile u16* addr = TFTDATA;
	return *addr;
}

//set new color mode for tft
void TFT_SetColorMode(u8 mode)
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;
	*cmdaddr = TFT_COLMOD;
	*dataddr = mode; 
}

//hard reset tft, need wait for 120 mS min after reset
inline void TFT_hardReset()
{
	GPIO_ResetBits(GPIOD, GPIO_Pin_3);
	TIME_delay_ms(1);
	GPIO_SetBits(GPIOD, GPIO_Pin_3);
}




/////////////////////////////////////////////////////////////////////

//fill all screen with specified color
void  APIEXPORT TFT_FillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color)
{
	u32 j;

	//set drawing rectangle
	TFT_SetDrawRect2(x1, y1, width, height);
	//calc pixels count
	j = width * height;
	TFT_Fill(j, (u16)color);
}

//send pixels to display (when size is known)
void TFT_Fill(u32 count, u16 color)
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;
	u32 i;

	//send pixels to tft  - (may be to use DMA instead?)
	*cmdaddr = TFT_RAMWR;
	for(i = 0; i < count; i++)
		*dataddr = color;
	*cmdaddr = TFT_NOP; //NOP breaks writing
}

////Set rectangle for reading/writing
void TFT_SetDrawRect2(u16 x, u16 y, u16 w, u16 h)
{
	//vertical orient - X swap Y
    //horizontal orient - X not swap Y
	h = y + h - 1; //end point
	w = x + w - 1;
    
    volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;
    //here axis is inverted for Portrait orient
	*cmdaddr = TFT_CASET;    //  CASET
	*dataddr = x >> 8;   	//        
	*dataddr = x & 0xFF;   	//  0        
	*dataddr = w >> 8;   	//        
	*dataddr = w & 0xFF;   	// 239         
	*cmdaddr = TFT_RASET;    // RASET
	*dataddr = y >> 8;   	//        
	*dataddr = y & 0xFF;   	//  0        
	*dataddr = h >> 8;   	//        
	*dataddr = h & 0xFF;   	// 319 
	return;
}

//helper for TFT_Read
u16 TFT_pixelGRxB(u16 gr, u16 xb)
{
	//gr(15-0) = r5r4r3r2r1r0 0 0 g5g4g3g2g1g0 0 0 
	//xb(15-0) = b5b4b3b2b1b0 0 0 x x x x x x  0 0
	// -------------------------------------------
	//565(15-0)= r4r3r2r1r0g5g4g3 g2g1g0b4b3b2b1b0
	u8 g = (u8) (gr & 0xff);		 //g5g4g3g2g1g000
	u8 b = (u8) ((xb >> 10) & 0x1F); //000b4b3b2b1b0
	u16 res = ((gr >> 2) & 0xFF00);  //00r5r4r3r2r1r0 00000000
	res = (res | g) << 3;			 //r4r3r2r1r0g5g4g3g2g1g0 00000
	res = res | b;					//r4r3r2r1r0g5g4g3g2g1g0b4b3b2b1b0
	return res;
}
//helper for TFT_Read
u16 TFT_pixelRxBG(u16 rx, u16 bg)
{
	//rx = x x x x x x  0 0 r5r4r3r2r1r0 0 0
	//bg = g5g4g3g2g1g0 0 0 b5b4b3b2b1b0 0 0 
	//--------------------------------------
	//565(15-0)= r4r3r2r1r0g5g4g3 g2g1g0b4b3b2b1b0

	u8 b = (u8)((bg >> 2) & 0x1F);	//000b4b3b2b1b0
	u8 g = (u8)(bg >> 10);			//00g5g4g3g2g1g0
	u16 res = ((rx << 4) | (u16)g); //xx00rrrrrrgggggg
	res = (res << 5) | b;			//rrrrrggggggbbbbb
	return res;
}

//read data for already specified rect
//Data from tft comes in rgb666, need convert to rgb565!!!
void TFT_Read(u16* buf, u32 cnt) 
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;
	u16 t1, t2;

	//change colmod for 18bpp //colmod = 0x66;
	TFT_SetColorMode(TFT_COLORMODE_666);
	//send cmd for reading
	//TFT_writeCmd(TFT_RAMRD);
    *cmdaddr = TFT_RAMRD; //try optimize
	t1 = *dataddr; //one dummy read

	//read 1.5 word pixels
	while(cnt > 0)
	{
		//read first pixel
		t1 = *dataddr;
		t2 = *dataddr;
		//process and save pixel
		*buf = TFT_pixelGRxB(t1, t2);
		cnt--;
		buf++;
		if(cnt > 0)
		{
			t1 = *dataddr; //read second pixel
			cnt--;
			//process and save pixel
			*buf = TFT_pixelRxBG(t2, t1);
			buf++;
		}
	}
	//TFT_writeCmd(TFT_NOP);//break read
    *cmdaddr = TFT_NOP; //try optimize

	//restore old color mode
	TFT_SetColorMode(TFT_COLORMODE_565);
}

//write data for already specified rect
void TFT_Write(u16* buf, u32 cnt)
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;

	//send cmd for writing
	*cmdaddr = TFT_RAMWR;
	while(cnt)
	{
		*dataddr = *buf;   
		buf++;
		cnt--;
	}
	*cmdaddr = TFT_NOP;//break read
}

//function draw pixel with specified color
//must be fastest, if used
void  APIEXPORT TFT_SetPixel(u16 x, u16 y, u16 color)
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;

	TFT_SetDrawRect2(x, y, 1, 1);
	//send cmd for writing
	*cmdaddr = TFT_RAMWR;
	*dataddr = color;
	*cmdaddr = TFT_NOP;
}

//Read pixels from specified screen rectangle
void  APIEXPORT TFT_ReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf)
{
	TFT_SetDrawRect2(x, y, width, height);
	TFT_Read(buf, width * height);
}

//Write pixels to specified screen rectangle
void  APIEXPORT TFT_WriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf)
{
	TFT_SetDrawRect2(x, y, width, height);
	TFT_Write(buf, width * height);
}

//set display update order 
void TFT_SetScanOrder(TFT_DisplayOrder order)
{
	volatile u16* cmdaddr = TFTCMD;
	volatile u16* dataddr = TFTDATA;

	*cmdaddr = TFT_MADCTL;
	if(order == TFT_Portrait) //==0
	{
		*dataddr = (u16) 0; //MY=0;MX=0;MV=0; vertical 
	}
	else
	{
		*dataddr = (u16) 96; //MY=0;MX=1;MV=1; horizontal =01100000=
	}
}

//get address of u8*12 dotmap for ASCII char
u8*  APIEXPORT TFT_fontGetChar(u8 ch)
{
	u8* res;
	//char remapping
	if(ch < 32) ch = '?'; //control symbols
	ch = ch - 32;    
	if(ch > 95) ch = remapWin1251[ch - 96]; //for non-ascii symbols #128 - #255
	//get address
	res = fontTable;
	res = res + (ch * 12);
	return res;
}

//Write one char rect
void  APIEXPORT TFT_WriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor)
{
	u8* rows;
	u32 val;
	u32 i, j;
	volatile u16* dataddr = TFTDATA;

	//get char dotmap
	rows = TFT_fontGetChar(ch);
	//set rectangle for one char
    TFT_SetDrawRect2(X, Y, CHAR_W, CHAR_H);
    //open writing
    TFT_writeCmd(TFT_RAMWR);
	//draw 12 rows, MSB=firstpixel
	i = 12;
	while(i)
	{
		i--;
		val = (u32) *rows; rows++; //to next column
		j = 128;
		while(j)
		{
			//put pixel
			if((j & val) > 0) *dataddr = color;
			else *dataddr = bgcolor;
			j = j >> 1;
		}
	}
	//draw last 13 and 14 rows
	i = 16; //2 * 8
	while(i) { *dataddr = bgcolor; i--; };
    //break writing
    TFT_writeCmd(TFT_NOP);
}













