//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for INTMMC subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_INTMMC_H
#define  MY_INTMMC_H
#include "stm32f10x.h" //project data types

//DEFINES

typedef enum
{
/**
  * @brief  SD responses and error flags
  */
  INTMMC_RESPONSE_NO_ERROR      = (0x00),
  INTMMC_IN_IDLE_STATE          = (0x01),
  INTMMC_ERASE_RESET            = (0x02),
  INTMMC_ILLEGAL_COMMAND        = (0x04),
  INTMMC_COM_CRC_ERROR          = (0x08),
  INTMMC_ERASE_SEQUENCE_ERROR   = (0x10),
  INTMMC_ADDRESS_ERROR          = (0x20),
  INTMMC_PARAMETER_ERROR        = (0x40),
  INTMMC_RESPONSE_FAILURE       = (0xFF),

/**
  * @brief  Data response error
  */
  INTMMC_DATA_OK                = (0x05),
  INTMMC_DATA_CRC_ERROR         = (0x0B),
  INTMMC_DATA_WRITE_ERROR       = (0x0D),
  INTMMC_DATA_OTHER_ERROR       = (0xFF)
} INTMMC_Error;

/** 
  * @brief  Card Specific Data: CSD Register   41 bytes
  */ 
typedef struct
{
  __IO uint8_t  CSDStruct;            /*!< CSD structure */
  __IO uint8_t  SysSpecVersion;       /*!< System specification version */
  __IO uint8_t  Reserved1;            /*!< Reserved */
  __IO uint8_t  TAAC;                 /*!< Data read access-time 1 */
  __IO uint8_t  NSAC;                 /*!< Data read access-time 2 in CLK cycles */
  __IO uint8_t  MaxBusClkFrec;        /*!< Max. bus clock frequency */
  __IO uint16_t CardComdClasses;      /*!< Card command classes */
  __IO uint8_t  RdBlockLen;           /*!< Max. read data block length */
  __IO uint8_t  PartBlockRead;        /*!< Partial blocks for read allowed */
  __IO uint8_t  WrBlockMisalign;      /*!< Write block misalignment */
  __IO uint8_t  RdBlockMisalign;      /*!< Read block misalignment */
  __IO uint8_t  DSRImpl;              /*!< DSR implemented */
  __IO uint8_t  Reserved2;            /*!< Reserved */
  __IO uint32_t DeviceSize;           /*!< Device Size */
  __IO uint8_t  MaxRdCurrentVDDMin;   /*!< Max. read current @ VDD min */
  __IO uint8_t  MaxRdCurrentVDDMax;   /*!< Max. read current @ VDD max */
  __IO uint8_t  MaxWrCurrentVDDMin;   /*!< Max. write current @ VDD min */
  __IO uint8_t  MaxWrCurrentVDDMax;   /*!< Max. write current @ VDD max */
  __IO uint8_t  DeviceSizeMul;        /*!< Device size multiplier */
  __IO uint8_t  EraseGrSize;          /*!< Erase group size */
  __IO uint8_t  EraseGrMul;           /*!< Erase group size multiplier */
  __IO uint8_t  WrProtectGrSize;      /*!< Write protect group size */
  __IO uint8_t  WrProtectGrEnable;    /*!< Write protect group enable */
  __IO uint8_t  ManDeflECC;           /*!< Manufacturer default ECC */
  __IO uint8_t  WrSpeedFact;          /*!< Write speed factor */
  __IO uint8_t  MaxWrBlockLen;        /*!< Max. write data block length */
  __IO uint8_t  WriteBlockPaPartial;  /*!< Partial blocks for write allowed */
  __IO uint8_t  Reserved3;            /*!< Reserded */
  __IO uint8_t  ContentProtectAppli;  /*!< Content protection application */
  __IO uint8_t  FileFormatGrouop;     /*!< File format group */
  __IO uint8_t  CopyFlag;             /*!< Copy flag (OTP) */
  __IO uint8_t  PermWrProtect;        /*!< Permanent write protection */
  __IO uint8_t  TempWrProtect;        /*!< Temporary write protection */
  __IO uint8_t  FileFormat;           /*!< File Format */
  __IO uint8_t  ECC;                  /*!< ECC code */
  __IO uint8_t  CSD_CRC;              /*!< CSD CRC */
  __IO uint8_t  Reserved4;            /*!< always 1*/
} INTMMC_CSD;

/** 
  * @brief  Card Identification Data: CID Register   18 bytes
  */
typedef struct
{
  __IO uint8_t  ManufacturerID;       /*!< ManufacturerID */
  __IO uint16_t OEM_AppliID;          /*!< OEM/Application ID */
  __IO uint32_t ProdName1;            /*!< Product Name part1 */
  __IO uint8_t  ProdName2;            /*!< Product Name part2*/
  __IO uint8_t  ProdRev;              /*!< Product Revision */
  __IO uint32_t ProdSN;               /*!< Product Serial Number */
  __IO uint8_t  Reserved1;            /*!< Reserved1 */
  __IO uint16_t ManufactDate;         /*!< Manufacturing Date */
  __IO uint8_t  CID_CRC;              /*!< CID CRC */
  __IO uint8_t  Reserved2;            /*!< always 1 */
} INTMMC_CID;

/** 
  * @brief SD Card information 
  */
typedef struct
{
  INTMMC_CSD SD_csd;
  INTMMC_CID SD_cid;
  uint32_t CardCapacity;  /*!< Card Capacity */
  uint32_t CardBlockSize; /*!< Card Block Size */
} INTMMC_CardInfo;

/**
  * @brief  Block Size
  */
#define INTMMC_BLOCK_SIZE    0x200

/**
  * @brief  SD detection on its memory slot
  */
#define INTMMC_PRESENT        ((uint8_t)0x01)
#define INTMMC_NOT_PRESENT    ((uint8_t)0x00)


/**
  * @brief  Commands: CMDxx = CMD-number | 0x40
  */
#define INTMMC_CMD_GO_IDLE_STATE          0   /*!< CMD0 = 0x40 */
#define INTMMC_CMD_SEND_OP_COND           1   /*!< CMD1 = 0x41 */
#define INTMMC_CMD_SEND_CSD               9   /*!< CMD9 = 0x49 */
#define INTMMC_CMD_SEND_CID               10  /*!< CMD10 = 0x4A */
#define INTMMC_CMD_STOP_TRANSMISSION      12  /*!< CMD12 = 0x4C */
#define INTMMC_CMD_SEND_STATUS            13  /*!< CMD13 = 0x4D */
#define INTMMC_CMD_SET_BLOCKLEN           16  /*!< CMD16 = 0x50 */
#define INTMMC_CMD_READ_SINGLE_BLOCK      17  /*!< CMD17 = 0x51 */
#define INTMMC_CMD_READ_MULT_BLOCK        18  /*!< CMD18 = 0x52 */
#define INTMMC_CMD_SET_BLOCK_COUNT        23  /*!< CMD23 = 0x57 */
#define INTMMC_CMD_WRITE_SINGLE_BLOCK     24  /*!< CMD24 = 0x58 */
#define INTMMC_CMD_WRITE_MULT_BLOCK       25  /*!< CMD25 = 0x59 */
#define INTMMC_CMD_PROG_CSD               27  /*!< CMD27 = 0x5B */
#define INTMMC_CMD_SET_WRITE_PROT         28  /*!< CMD28 = 0x5C */
#define INTMMC_CMD_CLR_WRITE_PROT         29  /*!< CMD29 = 0x5D */
#define INTMMC_CMD_SEND_WRITE_PROT        30  /*!< CMD30 = 0x5E */
#define INTMMC_CMD_SD_ERASE_GRP_START     32  /*!< CMD32 = 0x60 */
#define INTMMC_CMD_SD_ERASE_GRP_END       33  /*!< CMD33 = 0x61 */
#define INTMMC_CMD_UNTAG_SECTOR           34  /*!< CMD34 = 0x62 */
#define INTMMC_CMD_ERASE_GRP_START        35  /*!< CMD35 = 0x63 */
#define INTMMC_CMD_ERASE_GRP_END          36  /*!< CMD36 = 0x64 */
#define INTMMC_CMD_UNTAG_ERASE_GROUP      37  /*!< CMD37 = 0x65 */
#define INTMMC_CMD_ERASE                  38  /*!< CMD38 = 0x66 */

//PROTOTYPES
//activate card from idle mode
INTMMC_Error INTMMC_GoActive(void);
//soft reset card to idle mode 
INTMMC_Error INTMMC_GoIdle(void); 
void INTMMC_Exit();
INTMMC_Error INTMMC_Init(void); //init hardware and card
INTMMC_Error INTMMC_GetCardInfo(INTMMC_CardInfo *cardinfo);
INTMMC_Error INTMMC_ReadBlock(uint8_t* pBuffer, uint32_t ReadAddr); //read up to 512 bytes from card 
INTMMC_Error INTMMC_WriteBlock(uint8_t* pBuffer, uint32_t WriteAddr); //write up to 512 bytes to card
INTMMC_Error INTMMC_GetCSDRegister(INTMMC_CSD* SD_csd);
INTMMC_Error INTMMC_GetCIDRegister(INTMMC_CID* SD_cid);


void INTMMC_SendCmd(uint8_t Cmd, uint32_t Arg, uint8_t Crc);
INTMMC_Error INTMMC_GetResponse(uint8_t Response);
uint8_t INTMMC_GetDataResponse(void);
uint16_t INTMMC_GetStatus(void);
uint8_t INTMMC_SpiReadWriteByte(uint8_t byte);



#endif // MY_INTMMC_H