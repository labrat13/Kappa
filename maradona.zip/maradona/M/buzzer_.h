//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for BUZZER subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_BUZZER_H
#define  MY_BUZZER_H

#include "stm32f10x.h"
//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//EXPORT VARIABLES

//PROTOTYPES

//NT-init buzzer resources
void BUZZER_Init();
//NT-deinit buzzer resources
void BUZZER_Exit();
//NT-routine for SYSTICK interrupt
void BUZZER_Routine();
//NT-Stop playing sound, buzzer off
void  APIEXPORT BUZZER_Break();
//NT-Play sound for Len millisecond, max 65 seconds
void  APIEXPORT BUZZER_Beep(u32 Len);

#endif // MY_BUZZER_H