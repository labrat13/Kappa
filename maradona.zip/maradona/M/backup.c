/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "backup.h"

#define BACKUP_KEY_VALUE 0x55AA

//FUNCTIONS

/*
backup registers and RTC use one domain and should be initialized in one place.
Here a only example for test without RTC.
*/

//init access to backup registers
void BACKUP_Init()
{
	/* Enable PWR and BKP clocks */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
	/* Allow access to BKP Domain */
	PWR_BackupAccessCmd(ENABLE);
    return;
}

//deinit backup subsystem, stop PWR and BKP clocks (RTC access breaks)
void BACKUP_Exit()
{
	/* Deny access to BKP Domain */
	PWR_BackupAccessCmd(DISABLE);
	/* Disable PWR and BKP clocks */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, DISABLE);
    return;
}
//read backup register
u32  APIEXPORT BACKUP_Read(u32 regNo)
{
	return (u32) BKP_ReadBackupRegister((u16)regNo);
}
//write backup register
void  APIEXPORT BACKUP_Write(u32 regNo, u32 val)
{
	BKP_WriteBackupRegister((u16)regNo, (u16)val);
	return;
}

//return 0 if key invalid, return 1 if key valid
u32  APIEXPORT BACKUP_isValid()
{
    if(BACKUP_Read(BACKUP_REG_KEY) == BACKUP_KEY_VALUE)
     return 1; else return 0;        
}

