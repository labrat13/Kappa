//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for DEBUGTERM subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_DEBUGTERM_H
#define  MY_DEBUGTERM_H

#include "stm32f10x.h" //project data types

//DEFINES
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif
//GLOBAL VARIABLES
u32 DBG_minStackPSPValue; //debug variable for list stack value. Remove this when unused.
u32 DBG_minStackMSPValue; //debug variable for list stack value. Remove this when unused.
//PROTOTYPES
void DBG_Init();
void DBG_Exit();

//put char via USART1 to debug terminal
void APIEXPORT DBG_putchar(u8 ch);

//send string to terminal
void APIEXPORT DBG_printf(u8* str);

//send string to terminal
void APIEXPORT DBG_printfn(u8* str, u32 len);

//send value to terminal
void APIEXPORT DBG_printval(u32 val);
//send hex value to terminal
void DBG_printHex(u32 val);

//print stack pointers
void DBG_printStackTop(u8* label);

//collect stack pointers values
void DBG_addStackInfo();
//print stack pointers values
void DBG_printStackMin();
//dump entire ram
void DBG_printMemory();
//Print debug flag value
void DBG_printFlag();
//set debug flag value
void DBG_setFlag(u32 val);

#endif // MY_DEBUGTERM_H