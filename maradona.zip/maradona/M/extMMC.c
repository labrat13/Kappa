/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "extMMC.h"
#include "Math_.h"
#include "ram_.h" //for memalloc

//NOTES
//4.3.14 Command Functional Difference in Card Capacity Types
// CCS in the response of ACMD41 determines card capacity types: CCS=0 is SDSC and CCS=1 is
// SDHC or SDXC.
//Memory access commands include block read commands (CMD17, CMD18), block write commands
// (CMD24, CMD25), and block erase commands (CMD32, CMD33).
//Following are the functional differences of memory access commands between SDSC and SDHC,SDXC:
//� Command Argument
// SDHC and SDXC use the 32-bit argument of memory access commands as block address
// format. Block length is fixed to 512 bytes regardless CMD16,
// SDSC uses the 32-bit argument of memory access commands as byte address format. Block
// length is determined by CMD16,
// i.e.:
// (a) Argument 0001h is byte address 0001h in the SDSC and 0001h block in SDHC and SDXC
// (b) Argument 0200h is byte address 0200h in the SDSC and 0200h block in SDHC and SDXC
//� Partial Access and Misalign Access
// SDHC and SDXC disable Partial access and Misalign access (crossing physical block
// boundary) as the block address is used. Access is only granted based on block addressing.
//� Set Block Length
// SDHC and SDXC use 512-byte fixed block length for memory access commands regardless of
// the block length set by CMD16. The setting of the block length does not affect the memory
// access commands. CMD42 is not classified as a memory access command. The data block
// size shall be specified by CMD16 and the block length can be set up to 512 bytes. Setting
// block length larger than 512 bytes sets the BLOCK_LEN_ERROR error bit regardless of the
// card capacity.
//� Write Protected Group
// SDHC and SDXC do not support write-protected groups. Issuing CMD28, CMD29 and CMD30
// generates the ILLEGAL_COMMAND error.

//DEFINES
#define NULL 0
#define SDIO_STATIC_FLAGS               ((uint32_t)0x000005FF)
#define SDIO_CMD0TIMEOUT                ((uint32_t)0x00002710)
#define SDIO_FIFO_Address               ((uint32_t)0x40018080)

/* Mask for errors Card Status R1 (OCR Register) */
#define EXTMMC_OCR_ADDR_OUT_OF_RANGE        ((uint32_t)0x80000000)
#define EXTMMC_OCR_ADDR_MISALIGNED          ((uint32_t)0x40000000)
#define EXTMMC_OCR_BLOCK_LEN_ERR            ((uint32_t)0x20000000)
#define EXTMMC_OCR_ERASE_SEQ_ERR            ((uint32_t)0x10000000)
#define EXTMMC_OCR_BAD_ERASE_PARAM          ((uint32_t)0x08000000)
#define EXTMMC_OCR_WRITE_PROT_VIOLATION     ((uint32_t)0x04000000)
#define EXTMMC_OCR_LOCK_UNLOCK_FAILED       ((uint32_t)0x01000000)
#define EXTMMC_OCR_COM_CRC_FAILED           ((uint32_t)0x00800000)
#define EXTMMC_OCR_ILLEGAL_CMD              ((uint32_t)0x00400000)
#define EXTMMC_OCR_CARD_ECC_FAILED          ((uint32_t)0x00200000)
#define EXTMMC_OCR_CC_ERROR                 ((uint32_t)0x00100000)
#define EXTMMC_OCR_GENERAL_UNKNOWN_ERROR    ((uint32_t)0x00080000)
#define EXTMMC_OCR_STREAM_READ_UNDERRUN     ((uint32_t)0x00040000)
#define EXTMMC_OCR_STREAM_WRITE_OVERRUN     ((uint32_t)0x00020000)
#define EXTMMC_OCR_CID_CSD_OVERWRIETE       ((uint32_t)0x00010000)
#define EXTMMC_OCR_WP_ERASE_SKIP            ((uint32_t)0x00008000)
#define EXTMMC_OCR_CARD_ECC_DISABLED        ((uint32_t)0x00004000)
#define EXTMMC_OCR_ERASE_RESET              ((uint32_t)0x00002000)
#define EXTMMC_OCR_AKE_SEQ_ERROR            ((uint32_t)0x00000008)
#define EXTMMC_OCR_ERRORBITS                ((uint32_t)0xFDFFE008)

/* Masks for R6 Response */
#define EXTMMC_R6_GENERAL_UNKNOWN_ERROR     ((uint32_t)0x00002000)
#define EXTMMC_R6_ILLEGAL_CMD               ((uint32_t)0x00004000)
#define EXTMMC_R6_COM_CRC_FAILED            ((uint32_t)0x00008000)

#define EXTMMC_VOLTAGE_WINDOW_SD            ((uint32_t)0x80100000)
#define EXTMMC_HIGH_CAPACITY                ((uint32_t)0x40000000)
#define EXTMMC_STD_CAPACITY                 ((uint32_t)0x00000000)
#define EXTMMC_CHECK_PATTERN                ((uint32_t)0x000001AA)

#define EXTMMC_MAX_VOLT_TRIAL               ((uint32_t)0x0000FFFF)
#define EXTMMC_ALLZERO                      ((uint32_t)0x00000000)

#define EXTMMC_WIDE_BUS_SUPPORT             ((uint32_t)0x00040000)
#define EXTMMC_SINGLE_BUS_SUPPORT           ((uint32_t)0x00010000)
#define EXTMMC_CARD_LOCKED                  ((uint32_t)0x02000000)
#define EXTMMC_CARD_PROGRAMMING             ((uint32_t)0x00000007)
#define EXTMMC_CARD_RECEIVING               ((uint32_t)0x00000006)
#define EXTMMC_DATATIMEOUT                  ((uint32_t)0x000FFFFF)
#define EXTMMC_0TO7BITS                     ((uint32_t)0x000000FF)
#define EXTMMC_8TO15BITS                    ((uint32_t)0x0000FF00)
#define EXTMMC_16TO23BITS                   ((uint32_t)0x00FF0000)
#define EXTMMC_24TO31BITS                   ((uint32_t)0xFF000000)
#define EXTMMC_MAX_DATA_LENGTH              ((uint32_t)0x01FFFFFF)

#define EXTMMC_HALFFIFO                     ((uint32_t)0x00000008)
#define EXTMMC_HALFFIFOBYTES                ((uint32_t)0x00000020)

/* Command Class Supported */
#define EXTMMC_CCCC_LOCK_UNLOCK             ((uint32_t)0x00000080)
#define EXTMMC_CCCC_WRITE_PROT              ((uint32_t)0x00000040)
#define EXTMMC_CCCC_ERASE                   ((uint32_t)0x00000020)

/* Following commands are SD Card Specific commands.
SDIO_APP_CMD should be sent before sending these commands. */
#define SDIO_SEND_IF_COND               ((uint32_t)0x00000008)

#define SDIO_INIT_CLK_DIV                  ((uint8_t)0xB2)
#define SDIO_TRANSFER_CLK_DIV              ((uint8_t)0x1) 

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//static u8 CardType =  SDIO_STD_CAPACITY_SD_CARD_V1_1;
//static uint32_t CSD_Tab[4], CID_Tab[4], RCA = 0;
//static u8 DeviceMode = EXTMMC_POLLING_MODE;
//static uint32_t TotalNumberOfBytes = 0, StopCondition = 0;
//uint32_t *SrcBuffer, *DestBuffer;
//volatile EXTMMC_Error TransferError = EXTMMC_OK;
//__IO uint32_t TransferEnd = 0;
//__IO uint32_t NumberOfBytes = 0;
//SDIO_InitTypeDef SDIO_InitStructure; move to local function data
//SDIO_CmdInitTypeDef SDIO_CmdInitStructure;  //20 bytes size
//SDIO_DataInitTypeDef SDIO_DataInitStructure; //24bytes size

//put global variables to single structure
typedef struct _EXTMMC_GlobalData
{
	u32 CSD_Tab[4]; //16 bytes
	u32 CID_Tab[4];	//16 bytes
	u32 NumberOfBytes;
	u32 TotalNumberOfBytes;
	u32* SrcBuffer;
	u32* DestBuffer;
	u16 RCA;
	u8 CardType;
	u8 TransferEnd; //flag from irq transfer end
	u8 DeviceMode;
	u8 StopCondition; //flag for irq bytes transfer break
	EXTMMC_Error TransferError; 
}EXTMMC_GlobalData, *PEXTMMC_GlobalData;

//pointer to global data strct
PEXTMMC_GlobalData EXTMMC_Gdata;

/* Private function prototypes -----------------------------------------------*/
static EXTMMC_Error CmdError(void);
static EXTMMC_Error CmdResp1Error(uint8_t cmd);
static EXTMMC_Error CmdResp7Error(void);
static EXTMMC_Error CmdResp3Error(void);
static EXTMMC_Error CmdResp2Error(void);
static EXTMMC_Error CmdResp6Error(uint8_t cmd, uint16_t *prca);
static EXTMMC_Error SDEnWideBus(FunctionalState NewState);
static EXTMMC_Error IsCardProgramming(uint8_t *pstatus);
static EXTMMC_Error FindSCR(uint16_t rca, uint32_t *pscr);
//static uint8_t convert_from_bytes_to_power_of_two(uint16_t NumberOfBytes);
static void GPIO_Configuration(void);
static void DMA_TxConfiguration(uint32_t *BufferSRC, uint32_t BufferSize);
static void DMA_RxConfiguration(uint32_t *BufferDST, uint32_t BufferSize);

/* Private functions ---------------------------------------------------------*/

/**
* @brief  Initializes the SD Card and put it into StandBy State (Ready 
*   for data transfer).
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
//EXTMMC_Error EXTMMC_Init(void)
//{
//	EXTMMC_Error errorstatus = EXTMMC_OK;
//
//	/* Configure SDIO interface GPIO */
//	GPIO_Configuration();
//
//	/* Enable the SDIO AHB Clock */
//	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SDIO, ENABLE);
//
//	/* Enable the DMA2 Clock */
//	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
//
//	SDIO_DeInit();
//
//	errorstatus = EXTMMC_PowerON();
//
//	if (errorstatus != EXTMMC_OK)
//	{
//		/* CMD Response TimeOut (wait for CMDSENT flag) */
//		return(errorstatus);
//	}
//
//	errorstatus = EXTMMC_InitializeCards();
//
//	if (errorstatus != EXTMMC_OK)
//	{
//		/* CMD Response TimeOut (wait for CMDSENT flag) */
//		return(errorstatus);
//	}
//
//	//TODO: setup clock with current clockmode
//	/* Configure the SDIO peripheral */
//	/* HCLK = 72 MHz, SDIOCLK = 72 MHz, SDIO_CK = HCLK/(2 + 1) = 24 MHz */  
//	SDIO_InitStructure.SDIO_ClockDiv = SDIO_TRANSFER_CLK_DIV; 
//	SDIO_InitStructure.SDIO_ClockEdge = SDIO_ClockEdge_Rising;
//	SDIO_InitStructure.SDIO_ClockBypass = SDIO_ClockBypass_Disable;
//	SDIO_InitStructure.SDIO_ClockPowerSave = SDIO_ClockPowerSave_Disable;
//	SDIO_InitStructure.SDIO_BusWide = SDIO_BusWide_1b;
//	SDIO_InitStructure.SDIO_HardwareFlowControl = SDIO_HardwareFlowControl_Disable;
//	SDIO_Init(&SDIO_InitStructure);
//
//	return(errorstatus);
//}

EXTMMC_Error EXTMMC_Init(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	//SDIO_InitTypeDef SDIO_InitStructure;
	//create global data and fill with zero
	EXTMMC_Gdata = (PEXTMMC_GlobalData) RAM_memAllocFill(sizeof(EXTMMC_GlobalData), RAM_TAG_EXTMMC, 0); //
	if(EXTMMC_Gdata == 0) return EXTMMC_ERROR; //ERROR: memory alloc error
	//fill default data
	//EXTMMC_Gdata->CardType = SDIO_STD_CAPACITY_SD_CARD_V1_1; == 0
	EXTMMC_Gdata->DeviceMode = EXTMMC_POLLING_MODE;
	EXTMMC_Gdata->TransferError = EXTMMC_OK;

	/* Configure SDIO interface GPIO */
	GPIO_Configuration();

	/* Enable the SDIO AHB Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SDIO, ENABLE);

	/* Enable the DMA2 Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);

	SDIO_DeInit();

	errorstatus = EXTMMC_PowerON();

	if (errorstatus == EXTMMC_OK)
	{
		/* CMD Response TimeOut (wait for CMDSENT flag) */
		//return(errorstatus);
	
		errorstatus = EXTMMC_InitializeCards();
	}

	if (errorstatus == EXTMMC_OK)
	{
		/* CMD Response TimeOut (wait for CMDSENT flag) */
		//return(errorstatus);

		//TODO: setup clock with current clockmode
		/* Configure the SDIO peripheral */
		/* HCLK = 72 MHz, SDIOCLK = 72 MHz, SDIO_CK = HCLK/(2 + 1) = 24 MHz */  
		//SDIO_InitStructure.SDIO_ClockDiv = SDIO_TRANSFER_CLK_DIV; 
		//SDIO_InitStructure.SDIO_ClockEdge = SDIO_ClockEdge_Rising;
		//SDIO_InitStructure.SDIO_ClockBypass = SDIO_ClockBypass_Disable;
		//SDIO_InitStructure.SDIO_ClockPowerSave = SDIO_ClockPowerSave_Disable;
		//SDIO_InitStructure.SDIO_BusWide = SDIO_BusWide_1b;
		//SDIO_InitStructure.SDIO_HardwareFlowControl = SDIO_HardwareFlowControl_Disable;
		//SDIO_Init(&SDIO_InitStructure);
		SDIO_Init2((u32)( SDIO_TRANSFER_CLK_DIV | SDIO_ClockEdge_Rising | SDIO_ClockBypass_Disable | SDIO_ClockPowerSave_Disable | SDIO_BusWide_1b | SDIO_HardwareFlowControl_Disable ));

		/*----------------- Select Card --------------------------------*/
		errorstatus = EXTMMC_SelectDeselect((uint32_t) (EXTMMC_Gdata->RCA << 16));
	}

	if (errorstatus == EXTMMC_OK)
	{
		errorstatus = EXTMMC_EnableWideBusOperation(SDIO_BusWide_4b);
	} 

	/* Set Device Transfer Mode to DMA */
	if (errorstatus == EXTMMC_OK)
	{  
		errorstatus = EXTMMC_SetDeviceMode(EXTMMC_DMA_MODE);
	} 

	/* Set Device Transfer Mode to DMA */
	if (errorstatus == EXTMMC_OK)
	{  
				//enable IRQ
		NVIC_InitTypeDef NVIC_InitStructure;

		NVIC_InitStructure.NVIC_IRQChannel = SDIO_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);
	} 
//if not success, free memory for global data
	if (errorstatus != EXTMMC_OK)
	{
		RAM_memFree((u8*)EXTMMC_Gdata);
		EXTMMC_Gdata = 0;
	}

	return(errorstatus);
}
void  EXTMMC_Exit()
{
	//disable pin's, disable SDIO module and clocks
	//...dma, interrupt, ...
	GPIO_InitTypeDef  GPIO_InitStructure;
	//disable IRQ
	NVIC_DisableIRQ(SDIO_IRQn);

	/*!< Disable SDIO Clock */
	SDIO_ClockCmd(DISABLE);

	/*!< Set Power State to OFF */
	SDIO_SetPowerState(SDIO_PowerState_OFF);

	/*!< DeInitializes the SDIO peripheral */
	SDIO_DeInit();
	//free global data struct memory
	RAM_memFree((u8*)EXTMMC_Gdata);
	EXTMMC_Gdata = 0;

	/*!< Disable the SDIO AHB Clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SDIO, DISABLE);

	/*!< Configure PC.08, PC.09, PC.10, PC.11, PC.12 pin: D0, D1, D2, D3, CLK pin */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/*!< Configure PD.02 CMD line */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}

/**
* @brief  Enquires cards about their operating voltage and configures 
*   clock controls.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_PowerON(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t response = 0, count = 0;
	bool validvoltage = FALSE;
	uint32_t SDType = EXTMMC_STD_CAPACITY;

	/* Power ON Sequence -------------------------------------------------------*/
	//SDIO_InitTypeDef SDIO_InitStructure;
	///* Configure the SDIO peripheral */
	//SDIO_InitStructure.SDIO_ClockDiv = SDIO_INIT_CLK_DIV; /* HCLK = 72MHz, SDIOCLK = 72MHz, SDIO_CK = HCLK/(178 + 2) = 400 KHz */
	//SDIO_InitStructure.SDIO_ClockEdge = SDIO_ClockEdge_Rising;
	//SDIO_InitStructure.SDIO_ClockBypass = SDIO_ClockBypass_Disable;
	//SDIO_InitStructure.SDIO_ClockPowerSave = SDIO_ClockPowerSave_Disable;
	//SDIO_InitStructure.SDIO_BusWide = SDIO_BusWide_1b;
	//SDIO_InitStructure.SDIO_HardwareFlowControl = SDIO_HardwareFlowControl_Disable;
	//SDIO_Init(&SDIO_InitStructure);
	SDIO_Init2((u32)( SDIO_INIT_CLK_DIV| SDIO_ClockEdge_Rising | SDIO_ClockBypass_Disable | SDIO_ClockPowerSave_Disable | SDIO_BusWide_1b | SDIO_HardwareFlowControl_Disable ));
	
	/* Set Power State to ON */
	SDIO_SetPowerState(SDIO_PowerState_ON);

	/* Enable SDIO Clock */
	SDIO_ClockCmd(ENABLE);

	/* CMD0: GO_IDLE_STATE -------------------------------------------------------*/
	/* No CMD response required */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x0;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_GO_IDLE_STATE;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(0, (u32)(SDIO_GO_IDLE_STATE | SDIO_Response_No | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdError();

	if (errorstatus != EXTMMC_OK)
	{
		/* CMD Response TimeOut (wait for CMDSENT flag) */
		return(errorstatus);
	}

	/* CMD8: SEND_IF_COND --------------------------------------------------------*/
	/* Send CMD8 to verify SD card interface operating condition */
	/* Argument: - [31:12]: Reserved (shall be set to '0')
	- [11:8]: Supply Voltage (VHS) 0x1 (Range: 2.7-3.6 V)
	- [7:0]: Check Pattern (recommended 0xAA) */
	/* CMD Response: R7 */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = EXTMMC_CHECK_PATTERN;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_IF_COND;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(EXTMMC_CHECK_PATTERN, (u32)(SDIO_SEND_IF_COND | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp7Error();

	if (errorstatus == EXTMMC_OK)
	{
		EXTMMC_Gdata->CardType = SDIO_STD_CAPACITY_SD_CARD_V2_0; /* SD Card 2.0 */
		SDType = EXTMMC_HIGH_CAPACITY;
	}
	else
	{
		/* CMD55 */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x00;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2(0, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_APP_CMD);
	}
	/* CMD55 */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x00;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(0, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_APP_CMD);

	/* If errorstatus is Command TimeOut, it is a MMC card */
	/* If errorstatus is EXTMMC_OK it is a SD card: SD card 2.0 (voltage range mismatch)
	or SD card 1.x */
	if (errorstatus == EXTMMC_OK)
	{
		/* SD CARD */
		/* Send ACMD41 EXTMMC_APP_OP_COND with Argument 0x80100000 */
		while ((!validvoltage) && (count < EXTMMC_MAX_VOLT_TRIAL))
		{

			/* SEND CMD55 APP_CMD with RCA as 0 */
			//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x00;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2(0, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
			errorstatus = CmdResp1Error(SDIO_APP_CMD);

			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}
			//Gdata->SDIO_CmdInitStructure.SDIO_Argument = EXTMMC_VOLTAGE_WINDOW_SD | SDType;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SD_APP_OP_COND;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2(EXTMMC_VOLTAGE_WINDOW_SD | SDType, (u32) (SDIO_SD_APP_OP_COND | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
			errorstatus = CmdResp3Error();
			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}

			response = SDIO_GetResponse(SDIO_RESP1);
			validvoltage = (bool) (((response >> 31) == 1) ? 1 : 0);
			count++;
		}
		if (count >= EXTMMC_MAX_VOLT_TRIAL)
		{
			errorstatus = EXTMMC_INVALID_VOLTRANGE;
			return(errorstatus);
		}

		if (response &= EXTMMC_HIGH_CAPACITY)
		{
			EXTMMC_Gdata->CardType = SDIO_HIGH_CAPACITY_SD_CARD;
		}

	}/* else MMC Card */

	return(errorstatus);
}

/**
* @brief  Turns the SDIO output signals off.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_PowerOFF(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	/* Set Power State to OFF */
	SDIO_SetPowerState(SDIO_PowerState_OFF);

	return(errorstatus);
}

/**
* @brief  Intialises all cards or single card as the case may be. 
*   Card(s) come into standby state.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_InitializeCards(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint16_t rca = 0x01;

	if (SDIO_GetPowerState() == SDIO_PowerState_OFF)
	{
		errorstatus = EXTMMC_REQUEST_NOT_APPLICABLE;
		return(errorstatus);
	}

	if (SDIO_SECURE_DIGITAL_IO_CARD != EXTMMC_Gdata->CardType)
	{
		/* Send CMD2 ALL_SEND_CID */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x0;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_ALL_SEND_CID;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Long;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2(0, (u32) (SDIO_ALL_SEND_CID | SDIO_Response_Long | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp2Error();

		if (EXTMMC_OK != errorstatus)
		{
			return(errorstatus);
		}

		EXTMMC_Gdata->CID_Tab[0] = SDIO_GetResponse(SDIO_RESP1);
		EXTMMC_Gdata->CID_Tab[1] = SDIO_GetResponse(SDIO_RESP2);
		EXTMMC_Gdata->CID_Tab[2] = SDIO_GetResponse(SDIO_RESP3);
		EXTMMC_Gdata->CID_Tab[3] = SDIO_GetResponse(SDIO_RESP4);
	}
	if ((SDIO_STD_CAPACITY_SD_CARD_V1_1 == EXTMMC_Gdata->CardType) ||  (SDIO_STD_CAPACITY_SD_CARD_V2_0 == EXTMMC_Gdata->CardType) ||  (SDIO_SECURE_DIGITAL_IO_COMBO_CARD == EXTMMC_Gdata->CardType)
		||  (SDIO_HIGH_CAPACITY_SD_CARD == EXTMMC_Gdata->CardType))
	{
		/* Send CMD3 SET_REL_ADDR with argument 0 */
		/* SD Card publishes its RCA. */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x00;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SET_REL_ADDR;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2(0, (u32) (SDIO_SET_REL_ADDR | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp6Error(SDIO_SET_REL_ADDR, &rca);

		if (EXTMMC_OK != errorstatus)
		{
			return(errorstatus);
		}
	}

	if (SDIO_SECURE_DIGITAL_IO_CARD != EXTMMC_Gdata->CardType)
	{
		EXTMMC_Gdata->RCA = rca;

		/* Send CMD9 SEND_CSD with argument as card's RCA */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t)(rca << 16);
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_CSD;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Long;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32)(rca << 16), (u32) (SDIO_SEND_CSD | SDIO_Response_Long | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp2Error();

		if (EXTMMC_OK != errorstatus)
		{
			return(errorstatus);
		}

		EXTMMC_Gdata->CSD_Tab[0] = SDIO_GetResponse(SDIO_RESP1);
		EXTMMC_Gdata->CSD_Tab[1] = SDIO_GetResponse(SDIO_RESP2);
		EXTMMC_Gdata->CSD_Tab[2] = SDIO_GetResponse(SDIO_RESP3);
		EXTMMC_Gdata->CSD_Tab[3] = SDIO_GetResponse(SDIO_RESP4);
	}

	errorstatus = EXTMMC_OK; /* All cards get intialized */

	return(errorstatus);
}

/**
* @brief  Returns information about specific card.
* @param  cardinfo : pointer to a EXTMMC_CardInfo structure 
*   that contains all SD card information.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_GetCardInfo(EXTMMC_CardInfo *cardinfo)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint8_t tmp = 0;

	cardinfo->CardType = (uint8_t)EXTMMC_Gdata->CardType;
	cardinfo->RCA = (uint16_t)EXTMMC_Gdata->RCA;

	/* Byte 0 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[0] & 0xFF000000) >> 24);
	cardinfo->SD_csd.CSDStruct = (tmp & 0xC0) >> 6;
	cardinfo->SD_csd.SysSpecVersion = (tmp & 0x3C) >> 2;
	cardinfo->SD_csd.Reserved1 = tmp & 0x03;

	/* Byte 1 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[0] & 0x00FF0000) >> 16);
	cardinfo->SD_csd.TAAC = tmp;

	/* Byte 2 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[0] & 0x0000FF00) >> 8);
	cardinfo->SD_csd.NSAC = tmp;

	/* Byte 3 */
	tmp = (uint8_t)(EXTMMC_Gdata->CSD_Tab[0] & 0x000000FF);
	cardinfo->SD_csd.MaxBusClkFrec = tmp;

	/* Byte 4 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[1] & 0xFF000000) >> 24);
	cardinfo->SD_csd.CardComdClasses = tmp << 4;

	/* Byte 5 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[1] & 0x00FF0000) >> 16);
	cardinfo->SD_csd.CardComdClasses |= (tmp & 0xF0) >> 4;
	cardinfo->SD_csd.RdBlockLen = tmp & 0x0F;

	/* Byte 6 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[1] & 0x0000FF00) >> 8);
	cardinfo->SD_csd.PartBlockRead = (tmp & 0x80) >> 7;
	cardinfo->SD_csd.WrBlockMisalign = (tmp & 0x40) >> 6;
	cardinfo->SD_csd.RdBlockMisalign = (tmp & 0x20) >> 5;
	cardinfo->SD_csd.DSRImpl = (tmp & 0x10) >> 4;
	cardinfo->SD_csd.Reserved2 = 0; /* Reserved */

	if ((EXTMMC_Gdata->CardType == SDIO_STD_CAPACITY_SD_CARD_V1_1) || (EXTMMC_Gdata->CardType == SDIO_STD_CAPACITY_SD_CARD_V2_0))
	{
		cardinfo->SD_csd.DeviceSize = (tmp & 0x03) << 10;

		/* Byte 7 */
		tmp = (uint8_t)(EXTMMC_Gdata->CSD_Tab[1] & 0x000000FF);
		cardinfo->SD_csd.DeviceSize |= (tmp) << 2;

		/* Byte 8 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0xFF000000) >> 24);
		cardinfo->SD_csd.DeviceSize |= (tmp & 0xC0) >> 6;

		cardinfo->SD_csd.MaxRdCurrentVDDMin = (tmp & 0x38) >> 3;
		cardinfo->SD_csd.MaxRdCurrentVDDMax = (tmp & 0x07);

		/* Byte 9 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0x00FF0000) >> 16);
		cardinfo->SD_csd.MaxWrCurrentVDDMin = (tmp & 0xE0) >> 5;
		cardinfo->SD_csd.MaxWrCurrentVDDMax = (tmp & 0x1C) >> 2;
		cardinfo->SD_csd.DeviceSizeMul = (tmp & 0x03) << 1;
		/* Byte 10 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0x0000FF00) >> 8);
		cardinfo->SD_csd.DeviceSizeMul |= (tmp & 0x80) >> 7;

		cardinfo->CardCapacity = (cardinfo->SD_csd.DeviceSize + 1) ;
		cardinfo->CardCapacity *= (1 << (cardinfo->SD_csd.DeviceSizeMul + 2));
		cardinfo->CardBlockSize = 1 << (cardinfo->SD_csd.RdBlockLen);
		cardinfo->CardCapacity *= cardinfo->CardBlockSize;
	}
	else if (EXTMMC_Gdata->CardType == SDIO_HIGH_CAPACITY_SD_CARD)
	{
		/* Byte 7 */
		tmp = (uint8_t)(EXTMMC_Gdata->CSD_Tab[1] & 0x000000FF);
		cardinfo->SD_csd.DeviceSize = (tmp & 0x3F) << 16;

		/* Byte 8 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0xFF000000) >> 24);

		cardinfo->SD_csd.DeviceSize |= (tmp << 8);

		/* Byte 9 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0x00FF0000) >> 16);

		cardinfo->SD_csd.DeviceSize |= (tmp);

		/* Byte 10 */
		tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[2] & 0x0000FF00) >> 8);

		cardinfo->CardCapacity = (cardinfo->SD_csd.DeviceSize + 1) * 512 * 1024;
		cardinfo->CardBlockSize = 512;    
	}


	cardinfo->SD_csd.EraseGrSize = (tmp & 0x40) >> 6;
	cardinfo->SD_csd.EraseGrMul = (tmp & 0x3F) << 1;

	/* Byte 11 */
	tmp = (uint8_t)(EXTMMC_Gdata->CSD_Tab[2] & 0x000000FF);
	cardinfo->SD_csd.EraseGrMul |= (tmp & 0x80) >> 7;
	cardinfo->SD_csd.WrProtectGrSize = (tmp & 0x7F);

	/* Byte 12 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[3] & 0xFF000000) >> 24);
	cardinfo->SD_csd.WrProtectGrEnable = (tmp & 0x80) >> 7;
	cardinfo->SD_csd.ManDeflECC = (tmp & 0x60) >> 5;
	cardinfo->SD_csd.WrSpeedFact = (tmp & 0x1C) >> 2;
	cardinfo->SD_csd.MaxWrBlockLen = (tmp & 0x03) << 2;

	/* Byte 13 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[3] & 0x00FF0000) >> 16);
	cardinfo->SD_csd.MaxWrBlockLen |= (tmp & 0xC0) >> 6;
	cardinfo->SD_csd.WriteBlockPaPartial = (tmp & 0x20) >> 5;
	cardinfo->SD_csd.Reserved3 = 0;
	cardinfo->SD_csd.ContentProtectAppli = (tmp & 0x01);

	/* Byte 14 */
	tmp = (uint8_t)((EXTMMC_Gdata->CSD_Tab[3] & 0x0000FF00) >> 8);
	cardinfo->SD_csd.FileFormatGrouop = (tmp & 0x80) >> 7;
	cardinfo->SD_csd.CopyFlag = (tmp & 0x40) >> 6;
	cardinfo->SD_csd.PermWrProtect = (tmp & 0x20) >> 5;
	cardinfo->SD_csd.TempWrProtect = (tmp & 0x10) >> 4;
	cardinfo->SD_csd.FileFormat = (tmp & 0x0C) >> 2;
	cardinfo->SD_csd.ECC = (tmp & 0x03);

	/* Byte 15 */
	tmp = (uint8_t)(EXTMMC_Gdata->CSD_Tab[3] & 0x000000FF);
	cardinfo->SD_csd.CSD_CRC = (tmp & 0xFE) >> 1;
	cardinfo->SD_csd.Reserved4 = 1;


	/* Byte 0 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[0] & 0xFF000000) >> 24);
	cardinfo->SD_cid.ManufacturerID = tmp;

	/* Byte 1 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[0] & 0x00FF0000) >> 16);
	cardinfo->SD_cid.OEM_AppliID = tmp << 8;

	/* Byte 2 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[0] & 0x000000FF00) >> 8);
	cardinfo->SD_cid.OEM_AppliID |= tmp;

	/* Byte 3 */
	tmp = (uint8_t)(EXTMMC_Gdata->CID_Tab[0] & 0x000000FF);
	cardinfo->SD_cid.ProdName1 = tmp << 24;

	/* Byte 4 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[1] & 0xFF000000) >> 24);
	cardinfo->SD_cid.ProdName1 |= tmp << 16;

	/* Byte 5 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[1] & 0x00FF0000) >> 16);
	cardinfo->SD_cid.ProdName1 |= tmp << 8;

	/* Byte 6 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[1] & 0x0000FF00) >> 8);
	cardinfo->SD_cid.ProdName1 |= tmp;

	/* Byte 7 */
	tmp = (uint8_t)(EXTMMC_Gdata->CID_Tab[1] & 0x000000FF);
	cardinfo->SD_cid.ProdName2 = tmp;

	/* Byte 8 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[2] & 0xFF000000) >> 24);
	cardinfo->SD_cid.ProdRev = tmp;

	/* Byte 9 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[2] & 0x00FF0000) >> 16);
	cardinfo->SD_cid.ProdSN = tmp << 24;

	/* Byte 10 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[2] & 0x0000FF00) >> 8);
	cardinfo->SD_cid.ProdSN |= tmp << 16;

	/* Byte 11 */
	tmp = (uint8_t)(EXTMMC_Gdata->CID_Tab[2] & 0x000000FF);
	cardinfo->SD_cid.ProdSN |= tmp << 8;

	/* Byte 12 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[3] & 0xFF000000) >> 24);
	cardinfo->SD_cid.ProdSN |= tmp;

	/* Byte 13 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[3] & 0x00FF0000) >> 16);
	cardinfo->SD_cid.Reserved1 |= (tmp & 0xF0) >> 4;
	cardinfo->SD_cid.ManufactDate = (tmp & 0x0F) << 8;

	/* Byte 14 */
	tmp = (uint8_t)((EXTMMC_Gdata->CID_Tab[3] & 0x0000FF00) >> 8);
	cardinfo->SD_cid.ManufactDate |= tmp;

	/* Byte 15 */
	tmp = (uint8_t)(EXTMMC_Gdata->CID_Tab[3] & 0x000000FF);
	cardinfo->SD_cid.CID_CRC = (tmp & 0xFE) >> 1;
	cardinfo->SD_cid.Reserved2 = 1;

	return(errorstatus);
}

/**
* @brief  Enables wide bus opeartion for the requeseted card if 
*   supported by card.
* @param  WideMode: Specifies the SD card wide bus mode. 
*   This parameter can be one of the following values:
*     @arg SDIO_BusWide_8b: 8-bit data transfer (Only for MMC)
*     @arg SDIO_BusWide_4b: 4-bit data transfer
*     @arg SDIO_BusWide_1b: 1-bit data transfer
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_EnableWideBusOperation(uint32_t WideMode)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	//SDIO_InitTypeDef SDIO_InitStructure;

	/* MMC Card doesn't support this feature */
	if (SDIO_MULTIMEDIA_CARD == EXTMMC_Gdata->CardType)
	{
		errorstatus = EXTMMC_UNSUPPORTED_FEATURE;
		return(errorstatus);
	}
	else if ((SDIO_STD_CAPACITY_SD_CARD_V1_1 == EXTMMC_Gdata->CardType) || (SDIO_STD_CAPACITY_SD_CARD_V2_0 == EXTMMC_Gdata->CardType) || (SDIO_HIGH_CAPACITY_SD_CARD == EXTMMC_Gdata->CardType))
	{
		if (SDIO_BusWide_8b == WideMode)
		{
			errorstatus = EXTMMC_UNSUPPORTED_FEATURE;
			return(errorstatus);
		}
		else if (SDIO_BusWide_4b == WideMode)
		{
			errorstatus = SDEnWideBus(ENABLE);

			if (EXTMMC_OK == errorstatus)
			{
				/* Configure the SDIO peripheral */
				//SDIO_InitStructure.SDIO_ClockDiv = SDIO_TRANSFER_CLK_DIV; 
				//SDIO_InitStructure.SDIO_ClockEdge = SDIO_ClockEdge_Rising;
				//SDIO_InitStructure.SDIO_ClockBypass = SDIO_ClockBypass_Disable;
				//SDIO_InitStructure.SDIO_ClockPowerSave = SDIO_ClockPowerSave_Disable;
				//SDIO_InitStructure.SDIO_BusWide = SDIO_BusWide_4b;
				//SDIO_InitStructure.SDIO_HardwareFlowControl = SDIO_HardwareFlowControl_Disable;
				//SDIO_Init(&SDIO_InitStructure);
				SDIO_Init2((u32)( SDIO_TRANSFER_CLK_DIV | SDIO_ClockEdge_Rising | SDIO_ClockBypass_Disable | SDIO_ClockPowerSave_Disable | SDIO_BusWide_4b | SDIO_HardwareFlowControl_Disable ));
			}
		}
		else
		{
			errorstatus = SDEnWideBus(DISABLE);

			if (EXTMMC_OK == errorstatus)
			{
				/* Configure the SDIO peripheral */
				//SDIO_InitStructure.SDIO_ClockDiv = SDIO_TRANSFER_CLK_DIV; 
				//SDIO_InitStructure.SDIO_ClockEdge = SDIO_ClockEdge_Rising;
				//SDIO_InitStructure.SDIO_ClockBypass = SDIO_ClockBypass_Disable;
				//SDIO_InitStructure.SDIO_ClockPowerSave = SDIO_ClockPowerSave_Disable;
				//SDIO_InitStructure.SDIO_BusWide = SDIO_BusWide_1b;
				//SDIO_InitStructure.SDIO_HardwareFlowControl = SDIO_HardwareFlowControl_Disable;
				//SDIO_Init(&SDIO_InitStructure);
				SDIO_Init2((u32)( SDIO_TRANSFER_CLK_DIV | SDIO_ClockEdge_Rising | SDIO_ClockBypass_Disable | SDIO_ClockPowerSave_Disable | SDIO_BusWide_1b | SDIO_HardwareFlowControl_Disable ));
			}
		}
	}

	return(errorstatus);
}

/**
* @brief  Sets device mode whether to operate in Polling, Interrupt or
*   DMA mode.
* @param  Mode: Specifies the Data Transfer mode.
*   This parameter can be one of the following values:
*     @arg EXTMMC_DMA_MODE: Data transfer using DMA.
*     @arg EXTMMC_INTERRUPT_MODE: Data transfer using interrupts.
*     @arg EXTMMC_POLLING_MODE: Data transfer using flags.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_SetDeviceMode(uint32_t Mode)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	if ((Mode == EXTMMC_DMA_MODE) || (Mode == EXTMMC_INTERRUPT_MODE) || (Mode == EXTMMC_POLLING_MODE))
	{
		EXTMMC_Gdata->DeviceMode = Mode;
	}
	else
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
	}
	return(errorstatus);

}

/**
* @brief  Selects od Deselects the corresponding card.
* @param  addr: Address of the Card to be selected.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_SelectDeselect(uint32_t addr)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	/* Send CMD7 SDIO_SEL_DESEL_CARD */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument =  addr;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEL_DESEL_CARD;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(addr, (u32) (SDIO_SEL_DESEL_CARD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SEL_DESEL_CARD);

	return(errorstatus);
}

/**
* @brief  Allows to read one block from a specified address in a card.
* @param  addr: Address from where data are to be read.
* @param  readbuff: pointer to the buffer that will contain the 
*   received data
* @param  BlockSize: the SD card Data block size.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_ReadBlock(uint32_t *readbuff, uint32_t addr, uint16_t BlockSize)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t count = 0, *tempbuff = readbuff;
	uint8_t power = 0;

	if (NULL == readbuff)
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
		return(errorstatus);
	}

	EXTMMC_Gdata->TransferError = EXTMMC_OK;
	EXTMMC_Gdata->TransferEnd = 0;
	EXTMMC_Gdata->TotalNumberOfBytes = 0;

	/* Clear all DPSM configuration */
	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = 0;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = SDIO_DataBlockSize_1b;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToCard;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Disable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, 0, (u32)(SDIO_DataBlockSize_1b | SDIO_TransferDir_ToCard | SDIO_TransferMode_Block | SDIO_DPSM_Disable));
	
	SDIO_DMACmd(DISABLE);

	if (SDIO_GetResponse(SDIO_RESP1) & EXTMMC_CARD_LOCKED)
	{
		errorstatus = EXTMMC_LOCK_UNLOCK_FAILED;
		return(errorstatus);
	}

	if (EXTMMC_Gdata->CardType == SDIO_HIGH_CAPACITY_SD_CARD)
	{
		BlockSize = 512;
		addr /= 512;
	}
	if ((BlockSize > 0) && (BlockSize <= 2048) && ((BlockSize & (BlockSize - 1)) == 0))
	{
		power = MATH_power2(BlockSize);

		/* Set Block Size for Card */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) BlockSize;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SET_BLOCKLEN;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32) BlockSize, (u32) (SDIO_SET_BLOCKLEN | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_SET_BLOCKLEN);

		if (EXTMMC_OK != errorstatus)
		{
			return(errorstatus);
		}
	}
	else
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
		return(errorstatus);
	}

	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = BlockSize;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = (uint32_t) power << 4;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToSDIO;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Enable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, BlockSize, (u32)((u32)(power << 4) | SDIO_TransferDir_ToSDIO | SDIO_TransferMode_Block | SDIO_DPSM_Enable));
	
	EXTMMC_Gdata->TotalNumberOfBytes = BlockSize;
	EXTMMC_Gdata->StopCondition = 0;
	EXTMMC_Gdata->DestBuffer = readbuff;

	/* Send CMD17 READ_SINGLE_BLOCK */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t)addr;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_READ_SINGLE_BLOCK;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) addr, (u32) (SDIO_READ_SINGLE_BLOCK | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_READ_SINGLE_BLOCK);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}
	/* In case of single block transfer, no need of stop transfer at all.*/
	if (EXTMMC_Gdata->DeviceMode == EXTMMC_POLLING_MODE)
	{
		/* Polling mode */
		while (!(SDIO->STA &(SDIO_FLAG_RXOVERR | SDIO_FLAG_DCRCFAIL | SDIO_FLAG_DTIMEOUT | SDIO_FLAG_DBCKEND | SDIO_FLAG_STBITERR)))
		{
			if (SDIO_GetFlagStatus(SDIO_FLAG_RXFIFOHF) != RESET)
			{
				for (count = 0; count < 8; count++)
				{
					*(tempbuff + count) = SDIO_ReadData();
				}
				tempbuff += 8;
			}
		}

		if (SDIO_GetFlagStatus(SDIO_FLAG_DTIMEOUT) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_DTIMEOUT);
			errorstatus = EXTMMC_DATA_TIMEOUT;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_DCRCFAIL) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_DCRCFAIL);
			errorstatus = EXTMMC_DATA_CRC_FAIL;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_RXOVERR) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_RXOVERR);
			errorstatus = EXTMMC_RX_OVERRUN;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_STBITERR) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_STBITERR);
			errorstatus = EXTMMC_START_BIT_ERR;
			return(errorstatus);
		}
		while (SDIO_GetFlagStatus(SDIO_FLAG_RXDAVL) != RESET)
		{
			*tempbuff = SDIO_ReadData();
			tempbuff++;
		}

		/* Clear all the static flags */
		SDIO_ClearFlag(SDIO_STATIC_FLAGS);
	}
	else if (EXTMMC_Gdata->DeviceMode == EXTMMC_INTERRUPT_MODE)
	{
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND | SDIO_IT_RXOVERR | SDIO_IT_RXFIFOHF | SDIO_IT_STBITERR, ENABLE);
		while ((EXTMMC_Gdata->TransferEnd == 0) && (EXTMMC_Gdata->TransferError == EXTMMC_OK))
		{}
		if (EXTMMC_Gdata->TransferError != EXTMMC_OK)
		{
			return(EXTMMC_Gdata->TransferError);
		}
	}
	else if (EXTMMC_Gdata->DeviceMode == EXTMMC_DMA_MODE)
	{
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND | SDIO_IT_RXOVERR | SDIO_IT_STBITERR, ENABLE);
		SDIO_DMACmd(ENABLE);
		DMA_RxConfiguration(readbuff, BlockSize);
		while (DMA_GetFlagStatus(DMA2_FLAG_TC4) == RESET)
		{}
	}
	return(errorstatus);
}


/**
* @brief  Allows to write one block starting from a specified address 
*   in a card.
* @param  addr: Address from where data are to be read.
* @param  writebuff: pointer to the buffer that contain the data to be
*   transferred.
* @param  BlockSize: the SD card Data block size.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_WriteBlock(uint32_t *writebuff, uint32_t addr,  uint16_t BlockSize)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint8_t  power = 0, cardstate = 0;
	uint32_t timeout = 0, bytestransferred = 0;
	uint32_t cardstatus = 0, count = 0, restwords = 0;
	uint32_t *tempbuff = writebuff;

	if (writebuff == NULL)
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
		return(errorstatus);
	}

	EXTMMC_Gdata->TransferError = EXTMMC_OK;
	EXTMMC_Gdata->TransferEnd = 0;
	EXTMMC_Gdata->TotalNumberOfBytes = 0;

	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = 0;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = SDIO_DataBlockSize_1b;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToCard;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Disable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, 0, (u32)(SDIO_DataBlockSize_1b | SDIO_TransferDir_ToCard | SDIO_TransferMode_Block | SDIO_DPSM_Disable));
	SDIO_DMACmd(DISABLE);

	if (SDIO_GetResponse(SDIO_RESP1) & EXTMMC_CARD_LOCKED)
	{
		errorstatus = EXTMMC_LOCK_UNLOCK_FAILED;
		return(errorstatus);
	}

	if (EXTMMC_Gdata->CardType == SDIO_HIGH_CAPACITY_SD_CARD)
	{
		BlockSize = 512; //SDHC have fixed lenght of sector
		addr /= 512; //???
	}

	/* Set the block size, both on controller and card */
	if ((BlockSize > 0) && (BlockSize <= 2048) && ((BlockSize & (BlockSize - 1)) == 0))
	{
		power = MATH_power2(BlockSize);

		//EXTMMC_Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) BlockSize;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SET_BLOCKLEN;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32) BlockSize, (u32) (SDIO_SET_BLOCKLEN | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_SET_BLOCKLEN);

		if (errorstatus != EXTMMC_OK)
		{
			return(errorstatus);
		}
	}
	else
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
		return(errorstatus);
	}

	/* Wait till card is ready for data Added */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) (Gdata->RCA << 16);
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_STATUS;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) (EXTMMC_Gdata->RCA << 16), (u32) (SDIO_SEND_STATUS | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SEND_STATUS);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	cardstatus = SDIO_GetResponse(SDIO_RESP1);

	timeout = EXTMMC_DATATIMEOUT;

	while (((cardstatus & 0x00000100) == 0) && (timeout > 0))
	{
		timeout--;
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) (Gdata->RCA << 16);
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_STATUS;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32) (EXTMMC_Gdata->RCA << 16), (u32) (SDIO_SEND_STATUS | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_SEND_STATUS);

		if (errorstatus != EXTMMC_OK)
		{
			return(errorstatus);
		}
		cardstatus = SDIO_GetResponse(SDIO_RESP1);
	}

	if (timeout == 0)
	{
		return(EXTMMC_ERROR);
	}

	/* Send CMD24 WRITE_SINGLE_BLOCK */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = addr;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_WRITE_SINGLE_BLOCK;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) addr, (u32) (SDIO_WRITE_SINGLE_BLOCK | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_WRITE_SINGLE_BLOCK);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	EXTMMC_Gdata->TotalNumberOfBytes = BlockSize;
	EXTMMC_Gdata->StopCondition = 0;
	EXTMMC_Gdata->SrcBuffer = writebuff;

	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = BlockSize;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = (uint32_t) power << 4;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToCard;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Enable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, BlockSize, (u32)((u32)(power << 4) | SDIO_TransferDir_ToCard | SDIO_TransferMode_Block | SDIO_DPSM_Enable));

/* In case of single data block transfer no need of stop command at all */
	if (EXTMMC_Gdata->DeviceMode == EXTMMC_POLLING_MODE)
	{
		while (!(SDIO->STA & (SDIO_FLAG_DBCKEND | SDIO_FLAG_TXUNDERR | SDIO_FLAG_DCRCFAIL | SDIO_FLAG_DTIMEOUT | SDIO_FLAG_STBITERR)))
		{
			if (SDIO_GetFlagStatus(SDIO_FLAG_TXFIFOHE) != RESET)
			{
				if ((EXTMMC_Gdata->TotalNumberOfBytes - bytestransferred) < 32)
				{
					restwords = ((EXTMMC_Gdata->TotalNumberOfBytes - bytestransferred) % 4 == 0) ? ((EXTMMC_Gdata->TotalNumberOfBytes - bytestransferred) / 4) : (( EXTMMC_Gdata->TotalNumberOfBytes -  bytestransferred) / 4 + 1);

					for (count = 0; count < restwords; count++, tempbuff++, bytestransferred += 4)
					{
						SDIO_WriteData(*tempbuff);
					}
				}
				else
				{
					for (count = 0; count < 8; count++)
					{
						SDIO_WriteData(*(tempbuff + count));
					}
					tempbuff += 8;
					bytestransferred += 32;
				}
			}
		}
		if (SDIO_GetFlagStatus(SDIO_FLAG_DTIMEOUT) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_DTIMEOUT);
			errorstatus = EXTMMC_DATA_TIMEOUT;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_DCRCFAIL) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_DCRCFAIL);
			errorstatus = EXTMMC_DATA_CRC_FAIL;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_TXUNDERR) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_TXUNDERR);
			errorstatus = EXTMMC_TX_UNDERRUN;
			return(errorstatus);
		}
		else if (SDIO_GetFlagStatus(SDIO_FLAG_STBITERR) != RESET)
		{
			SDIO_ClearFlag(SDIO_FLAG_STBITERR);
			errorstatus = EXTMMC_START_BIT_ERR;
			return(errorstatus);
		}
	}
	else if (EXTMMC_Gdata->DeviceMode == EXTMMC_INTERRUPT_MODE)
	{
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND | SDIO_FLAG_TXFIFOHE | SDIO_IT_TXUNDERR | SDIO_IT_STBITERR, ENABLE);
		while ((EXTMMC_Gdata->TransferEnd == 0) && (EXTMMC_Gdata->TransferError == EXTMMC_OK))
		{}
		if (EXTMMC_Gdata->TransferError != EXTMMC_OK)
		{
			return(EXTMMC_Gdata->TransferError);
		}
	}
	else if (EXTMMC_Gdata->DeviceMode == EXTMMC_DMA_MODE)
	{
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND | SDIO_IT_TXUNDERR | SDIO_IT_STBITERR, ENABLE);
		DMA_TxConfiguration(writebuff, BlockSize);
		SDIO_DMACmd(ENABLE);
		while (DMA_GetFlagStatus(DMA2_FLAG_TC4) == RESET)
		{}
		while ((EXTMMC_Gdata->TransferEnd == 0) && (EXTMMC_Gdata->TransferError == EXTMMC_OK))
		{}
		if (EXTMMC_Gdata->TransferError != EXTMMC_OK)
		{
			return(EXTMMC_Gdata->TransferError);
		}
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	/* Wait till the card is in programming state */
	errorstatus = IsCardProgramming(&cardstate);

	while ((errorstatus == EXTMMC_OK) && ((cardstate == EXTMMC_CARD_PROGRAMMING) || (cardstate == EXTMMC_CARD_RECEIVING)))
	{
		errorstatus = IsCardProgramming(&cardstate);
	}

	return(errorstatus);
}

/**
* @brief  Gets the cuurent data transfer state.
* @param  None
* @retval SDTransferState: Data Transfer state.
*   This value can be: 
*             - EXTMMC_NO_TRANSFER: No data transfer is acting
*             - EXTMMC_TRANSFER_IN_PROGRESS: Data transfer is acting
*/
SDTransferState EXTMMC_GetTransferState(void)
{
	if (SDIO->STA & (SDIO_FLAG_TXACT | SDIO_FLAG_RXACT))
	{
		return(SD_TRANSFER_IN_PROGRESS);
	}
	else
	{
		return(SD_NO_TRANSFER);
	}
}

/**
* @brief  Aborts an ongoing data transfer.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_StopTransfer(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	/* Send CMD12 STOP_TRANSMISSION  */
	// Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x0;
	// Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_STOP_TRANSMISSION;
	// Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	// Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	// Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	// SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
    SDIO_SendCommand2(0, (u32) (SDIO_STOP_TRANSMISSION | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_STOP_TRANSMISSION);

	return(errorstatus);
}

/**
* @brief  Allows to erase memory area specified for the given card.
* @param  startaddr: the start address.
* @param  endaddr: the end address.
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_Erase(uint32_t startaddr, uint32_t endaddr)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t delay = 0;
	__IO uint32_t maxdelay = 0;
	uint8_t cardstate = 0;

	/* Check if the card coomnd class supports erase command */
	if (((EXTMMC_Gdata->CSD_Tab[1] >> 20) & EXTMMC_CCCC_ERASE) == 0)
	{
		errorstatus = EXTMMC_REQUEST_NOT_APPLICABLE;
		return(errorstatus);
	}

	maxdelay = 72000 / ((SDIO->CLKCR & 0xFF) + 2);

	if (SDIO_GetResponse(SDIO_RESP1) & EXTMMC_CARD_LOCKED)
	{
		errorstatus = EXTMMC_LOCK_UNLOCK_FAILED;
		return(errorstatus);
	}

	if (EXTMMC_Gdata->CardType == SDIO_HIGH_CAPACITY_SD_CARD)
	{
		startaddr /= 512;
		endaddr /= 512;
	}

	/* According to sd-card spec 1.0 ERASE_GROUP_START (CMD32) and erase_group_end(CMD33) */
	if ((SDIO_STD_CAPACITY_SD_CARD_V1_1 == EXTMMC_Gdata->CardType) || (SDIO_STD_CAPACITY_SD_CARD_V2_0 == EXTMMC_Gdata->CardType) || (SDIO_HIGH_CAPACITY_SD_CARD == EXTMMC_Gdata->CardType))
	{
		/* Send CMD32 SD_ERASE_GRP_START with argument as addr  */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = startaddr;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SD_ERASE_GRP_START;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32) startaddr, (u32) (SDIO_SD_ERASE_GRP_START | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_SD_ERASE_GRP_START);
		if (errorstatus != EXTMMC_OK)
		{
			return(errorstatus);
		}

		/* Send CMD33 EXTMMC_ERASE_GRP_END with argument as addr  */
		//Gdata->SDIO_CmdInitStructure.SDIO_Argument = endaddr;
		//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SD_ERASE_GRP_END;
		//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
		//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
		//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
		//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
		SDIO_SendCommand2((u32) endaddr, (u32) (SDIO_SD_ERASE_GRP_END | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
		errorstatus = CmdResp1Error(SDIO_SD_ERASE_GRP_END);
		if (errorstatus != EXTMMC_OK)
		{
			return(errorstatus);
		}
	}

	/* Send CMD38 ERASE */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_ERASE;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(0, (u32) (SDIO_ERASE | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_ERASE);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	for (delay = 0; delay < maxdelay; delay++)
	{}

	/* Wait till the card is in programming state */
	errorstatus = IsCardProgramming(&cardstate);

	while ((errorstatus == EXTMMC_OK) && ((EXTMMC_CARD_PROGRAMMING == cardstate) || (EXTMMC_CARD_RECEIVING == cardstate)))
	{
		errorstatus = IsCardProgramming(&cardstate);
	}

	return(errorstatus);
}

/**
* @brief  Returns the current card's status.
* @param  pcardstatus: pointer to the buffer that will contain the SD 
*   card status (Card Status register).
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_SendStatus(uint32_t *pcardstatus)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	if (pcardstatus == NULL)
	{
		errorstatus = EXTMMC_INVALID_PARAMETER;
		return(errorstatus);
	}

	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_STATUS;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) EXTMMC_Gdata->RCA << 16, (u32) (SDIO_SEND_STATUS | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));

	errorstatus = CmdResp1Error(SDIO_SEND_STATUS);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	*pcardstatus = SDIO_GetResponse(SDIO_RESP1);

	return(errorstatus);
}

/**
* @brief  Returns the current SD card's status.
* @param  psdstatus: pointer to the buffer that will contain the SD 
*   card status (SD Status register).
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_SendSDStatus(uint32_t *psdstatus)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t count = 0;

	if (SDIO_GetResponse(SDIO_RESP1) & EXTMMC_CARD_LOCKED)
	{
		errorstatus = EXTMMC_LOCK_UNLOCK_FAILED;
		return(errorstatus);
	}

	/* Set block size for card if it is not equal to current block size for card. */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 64;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SET_BLOCKLEN;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(64, (u32) (SDIO_SET_BLOCKLEN | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SET_BLOCKLEN);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	/* CMD55 */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) EXTMMC_Gdata->RCA << 16, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_APP_CMD);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = 64;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = SDIO_DataBlockSize_64b;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToSDIO;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Enable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, 64, (u32)(SDIO_DataBlockSize_64b | SDIO_TransferDir_ToSDIO | SDIO_TransferMode_Block | SDIO_DPSM_Enable));

	/* Send ACMD13 SD_APP_STAUS  with argument as card's RCA.*/
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SD_APP_STAUS;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(0, (u32) (SDIO_SD_APP_STAUS | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SD_APP_STAUS);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	while (!(SDIO->STA &(SDIO_FLAG_RXOVERR | SDIO_FLAG_DCRCFAIL | SDIO_FLAG_DTIMEOUT | SDIO_FLAG_DBCKEND | SDIO_FLAG_STBITERR)))
	{
		if (SDIO_GetFlagStatus(SDIO_FLAG_RXFIFOHF) != RESET)
		{
			for (count = 0; count < 8; count++)
			{
				*(psdstatus + count) = SDIO_ReadData();
			}
			psdstatus += 8;
		}
	}

	if (SDIO_GetFlagStatus(SDIO_FLAG_DTIMEOUT) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_DTIMEOUT);
		errorstatus = EXTMMC_DATA_TIMEOUT;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_DCRCFAIL) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_DCRCFAIL);
		errorstatus = EXTMMC_DATA_CRC_FAIL;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_RXOVERR) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_RXOVERR);
		errorstatus = EXTMMC_RX_OVERRUN;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_STBITERR) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_STBITERR);
		errorstatus = EXTMMC_START_BIT_ERR;
		return(errorstatus);
	}

	while (SDIO_GetFlagStatus(SDIO_FLAG_RXDAVL) != RESET)
	{
		*psdstatus = SDIO_ReadData();
		psdstatus++;
	}

	/* Clear all the static status flags*/
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);
	psdstatus -= 16;
	for (count = 0; count < 16; count++)
	{
		psdstatus[count] = ((psdstatus[count] & EXTMMC_0TO7BITS) << 24) |((psdstatus[count] & EXTMMC_8TO15BITS) << 8) |
			((psdstatus[count] & EXTMMC_16TO23BITS) >> 8) |((psdstatus[count] & EXTMMC_24TO31BITS) >> 24);
	}
	return(errorstatus);
}

/**
* @brief  Allows to process all the interrupts that are high.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
EXTMMC_Error EXTMMC_ProcessIRQSrc(void)
{
	uint32_t count = 0, restwords = 0;

	if (EXTMMC_Gdata->DeviceMode == EXTMMC_INTERRUPT_MODE)
	{
		if (SDIO_GetITStatus(SDIO_IT_RXFIFOHF) != RESET)
		{
			for (count = 0; count < EXTMMC_HALFFIFO; count++)
			{
				*(EXTMMC_Gdata->DestBuffer + count) = SDIO_ReadData();
			}
			EXTMMC_Gdata->DestBuffer += EXTMMC_HALFFIFO;
			EXTMMC_Gdata->NumberOfBytes += EXTMMC_HALFFIFOBYTES;
		}
		else if (SDIO_GetITStatus(SDIO_IT_TXFIFOHE) != RESET)
		{
			if ((EXTMMC_Gdata->TotalNumberOfBytes - EXTMMC_Gdata->NumberOfBytes) < EXTMMC_HALFFIFOBYTES)
			{
				restwords = ((EXTMMC_Gdata->TotalNumberOfBytes - EXTMMC_Gdata->NumberOfBytes) %  4 == 0) ?
					((EXTMMC_Gdata->TotalNumberOfBytes - EXTMMC_Gdata->NumberOfBytes) / 4) :
				((EXTMMC_Gdata->TotalNumberOfBytes - EXTMMC_Gdata->NumberOfBytes) / 4 + 1);

				for (count = 0; count < restwords;  count++, EXTMMC_Gdata->SrcBuffer++, EXTMMC_Gdata->NumberOfBytes += 4)
				{
					SDIO_WriteData(*(EXTMMC_Gdata->SrcBuffer));
				}
			}
			else
			{
				for (count = 0; count < EXTMMC_HALFFIFO; count++)
				{
					SDIO_WriteData(*(EXTMMC_Gdata->SrcBuffer + count));
				}

				EXTMMC_Gdata->SrcBuffer += EXTMMC_HALFFIFO;
				EXTMMC_Gdata->NumberOfBytes += EXTMMC_HALFFIFOBYTES;
			}
		}
	}

	if (SDIO_GetITStatus(SDIO_IT_DATAEND) != RESET)
	{
		if (EXTMMC_Gdata->DeviceMode != EXTMMC_DMA_MODE)
		{
			while ((SDIO_GetFlagStatus(SDIO_FLAG_RXDAVL) != RESET)  &&  (EXTMMC_Gdata->NumberOfBytes < EXTMMC_Gdata->TotalNumberOfBytes))
			{
				*(EXTMMC_Gdata->DestBuffer) = SDIO_ReadData();
				EXTMMC_Gdata->DestBuffer++;
				EXTMMC_Gdata->NumberOfBytes += 4;
			}
		}

		if (EXTMMC_Gdata->StopCondition == 1)
		{
			EXTMMC_Gdata->TransferError = EXTMMC_StopTransfer();
		}
		else
		{
			EXTMMC_Gdata->TransferError = EXTMMC_OK;
		}
		SDIO_ClearITPendingBit(SDIO_IT_DATAEND);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->TransferEnd = 1;
		EXTMMC_Gdata->NumberOfBytes = 0;
		return(EXTMMC_Gdata->TransferError);
	}

	if (SDIO_GetITStatus(SDIO_IT_DCRCFAIL) != RESET)
	{
		SDIO_ClearITPendingBit(SDIO_IT_DCRCFAIL);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->NumberOfBytes = 0;
		EXTMMC_Gdata->TransferError = EXTMMC_DATA_CRC_FAIL;
		return(EXTMMC_DATA_CRC_FAIL);
	}

	if (SDIO_GetITStatus(SDIO_IT_DTIMEOUT) != RESET)
	{
		SDIO_ClearITPendingBit(SDIO_IT_DTIMEOUT);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->NumberOfBytes = 0;
		EXTMMC_Gdata->TransferError = EXTMMC_DATA_TIMEOUT;
		return(EXTMMC_DATA_TIMEOUT);
	}

	if (SDIO_GetITStatus(SDIO_IT_RXOVERR) != RESET)
	{
		SDIO_ClearITPendingBit(SDIO_IT_RXOVERR);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->NumberOfBytes = 0;
		EXTMMC_Gdata->TransferError = EXTMMC_RX_OVERRUN;
		return(EXTMMC_RX_OVERRUN);
	}

	if (SDIO_GetITStatus(SDIO_IT_TXUNDERR) != RESET)
	{
		SDIO_ClearITPendingBit(SDIO_IT_TXUNDERR);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->NumberOfBytes = 0;
		EXTMMC_Gdata->TransferError = EXTMMC_TX_UNDERRUN;
		return(EXTMMC_TX_UNDERRUN);
	}

	if (SDIO_GetITStatus(SDIO_IT_STBITERR) != RESET)
	{
		SDIO_ClearITPendingBit(SDIO_IT_STBITERR);
		SDIO_ITConfig(SDIO_IT_DCRCFAIL | SDIO_IT_DTIMEOUT | SDIO_IT_DATAEND |
			SDIO_IT_TXFIFOHE | SDIO_IT_RXFIFOHF | SDIO_IT_TXUNDERR |
			SDIO_IT_RXOVERR | SDIO_IT_STBITERR, DISABLE);
		EXTMMC_Gdata->NumberOfBytes = 0;
		EXTMMC_Gdata->TransferError = EXTMMC_START_BIT_ERR;
		return(EXTMMC_START_BIT_ERR);
	}

	return(EXTMMC_OK);
}

/**
* @brief  Checks for error conditions for CMD0.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdError(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t timeout;

	timeout = SDIO_CMD0TIMEOUT; /* 10000 */

	while ((timeout > 0) && (SDIO_GetFlagStatus(SDIO_FLAG_CMDSENT) == RESET))
	{
		timeout--;
	}

	if (timeout == 0)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	return(errorstatus);
}

/**
* @brief  Checks for error conditions for R7.
*   response.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdResp7Error(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t status;
	uint32_t timeout = SDIO_CMD0TIMEOUT;

	status = SDIO->STA;

	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CMDREND | SDIO_FLAG_CTIMEOUT)) && (timeout > 0))
	{
		timeout--;
		status = SDIO->STA;
	}

	if ((timeout == 0) || (status & SDIO_FLAG_CTIMEOUT))
	{
		/* Card is not V2.0 complient or card does not support the set voltage range */
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}

	if (status & SDIO_FLAG_CMDREND)
	{
		/* Card is SD V2.0 compliant */
		errorstatus = EXTMMC_OK;
		SDIO_ClearFlag(SDIO_FLAG_CMDREND);
		return(errorstatus);
	}
	return(errorstatus);
}

/**
* @brief  Checks for error conditions for R1.
*   response
* @param  cmd: The sent command index.
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdResp1Error(uint8_t cmd)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t status;
	uint32_t response_r1;

	status = SDIO->STA;

	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CMDREND | SDIO_FLAG_CTIMEOUT)))
	{
		status = SDIO->STA;
	}

	if (status & SDIO_FLAG_CTIMEOUT)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}
	else if (status & SDIO_FLAG_CCRCFAIL)
	{
		errorstatus = EXTMMC_CMD_CRC_FAIL;
		SDIO_ClearFlag(SDIO_FLAG_CCRCFAIL);
		return(errorstatus);
	}

	/* Check response received is of desired command */
	if (SDIO_GetCommandResponse() != cmd)
	{
		errorstatus = EXTMMC_ILLEGAL_CMD;
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	/* We have received response, retrieve it for analysis  */
	response_r1 = SDIO_GetResponse(SDIO_RESP1);

	if ((response_r1 & EXTMMC_OCR_ERRORBITS) == EXTMMC_ALLZERO)
	{
		return(errorstatus);
	}

	if (response_r1 & EXTMMC_OCR_ADDR_OUT_OF_RANGE)
	{
		return(EXTMMC_ADDR_OUT_OF_RANGE);
	}

	if (response_r1 & EXTMMC_OCR_ADDR_MISALIGNED)
	{
		return(EXTMMC_ADDR_MISALIGNED);
	}

	if (response_r1 & EXTMMC_OCR_BLOCK_LEN_ERR)
	{
		return(EXTMMC_BLOCK_LEN_ERR);
	}

	if (response_r1 & EXTMMC_OCR_ERASE_SEQ_ERR)
	{
		return(EXTMMC_ERASE_SEQ_ERR);
	}

	if (response_r1 & EXTMMC_OCR_BAD_ERASE_PARAM)
	{
		return(EXTMMC_BAD_ERASE_PARAM);
	}

	if (response_r1 & EXTMMC_OCR_WRITE_PROT_VIOLATION)
	{
		return(EXTMMC_WRITE_PROT_VIOLATION);
	}

	if (response_r1 & EXTMMC_OCR_LOCK_UNLOCK_FAILED)
	{
		return(EXTMMC_LOCK_UNLOCK_FAILED);
	}

	if (response_r1 & EXTMMC_OCR_COM_CRC_FAILED)
	{
		return(EXTMMC_COM_CRC_FAILED);
	}

	if (response_r1 & EXTMMC_OCR_ILLEGAL_CMD)
	{
		return(EXTMMC_ILLEGAL_CMD);
	}

	if (response_r1 & EXTMMC_OCR_CARD_ECC_FAILED)
	{
		return(EXTMMC_CARD_ECC_FAILED);
	}

	if (response_r1 & EXTMMC_OCR_CC_ERROR)
	{
		return(EXTMMC_CC_ERROR);
	}

	if (response_r1 & EXTMMC_OCR_GENERAL_UNKNOWN_ERROR)
	{
		return(EXTMMC_GENERAL_UNKNOWN_ERROR);
	}

	if (response_r1 & EXTMMC_OCR_STREAM_READ_UNDERRUN)
	{
		return(EXTMMC_STREAM_READ_UNDERRUN);
	}

	if (response_r1 & EXTMMC_OCR_STREAM_WRITE_OVERRUN)
	{
		return(EXTMMC_STREAM_WRITE_OVERRUN);
	}

	if (response_r1 & EXTMMC_OCR_CID_CSD_OVERWRIETE)
	{
		return(EXTMMC_CID_CSD_OVERWRITE);
	}

	if (response_r1 & EXTMMC_OCR_WP_ERASE_SKIP)
	{
		return(EXTMMC_WP_ERASE_SKIP);
	}

	if (response_r1 & EXTMMC_OCR_CARD_ECC_DISABLED)
	{
		return(EXTMMC_CARD_ECC_DISABLED);
	}

	if (response_r1 & EXTMMC_OCR_ERASE_RESET)
	{
		return(EXTMMC_ERASE_RESET);
	}

	if (response_r1 & EXTMMC_OCR_AKE_SEQ_ERROR)
	{
		return(EXTMMC_AKE_SEQ_ERROR);
	}
	return(errorstatus);
}

/**
* @brief  Checks for error conditions for R3 (OCR).
*   response.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdResp3Error(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t status;

	status = SDIO->STA;

	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CMDREND | SDIO_FLAG_CTIMEOUT)))
	{
		status = SDIO->STA;
	}

	if (status & SDIO_FLAG_CTIMEOUT)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}
	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);
	return(errorstatus);
}

/**
* @brief  Checks for error conditions for R2 (CID or CSD).
*   response.
* @param  None
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdResp2Error(void)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t status;

	status = SDIO->STA;

	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CTIMEOUT | SDIO_FLAG_CMDREND)))
	{
		status = SDIO->STA;
	}

	if (status & SDIO_FLAG_CTIMEOUT)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}
	else if (status & SDIO_FLAG_CCRCFAIL)
	{
		errorstatus = EXTMMC_CMD_CRC_FAIL;
		SDIO_ClearFlag(SDIO_FLAG_CCRCFAIL);
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	return(errorstatus);
}

/**
* @brief  Checks for error conditions for R6 (RCA).
*   response.
* @param  cmd: The sent command index.
* @param  prca: pointer to the variable that will contain the SD
*   card relative address RCA. 
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error CmdResp6Error(uint8_t cmd, uint16_t *prca)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t status;
	uint32_t response_r1;

	status = SDIO->STA;

	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CTIMEOUT | SDIO_FLAG_CMDREND)))
	{
		status = SDIO->STA;
	}

	if (status & SDIO_FLAG_CTIMEOUT)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}
	else if (status & SDIO_FLAG_CCRCFAIL)
	{
		errorstatus = EXTMMC_CMD_CRC_FAIL;
		SDIO_ClearFlag(SDIO_FLAG_CCRCFAIL);
		return(errorstatus);
	}

	/* Check response received is of desired command */
	if (SDIO_GetCommandResponse() != cmd)
	{
		errorstatus = EXTMMC_ILLEGAL_CMD;
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	/* We have received response, retrieve it.  */
	response_r1 = SDIO_GetResponse(SDIO_RESP1);

	if (EXTMMC_ALLZERO == (response_r1 & (EXTMMC_R6_GENERAL_UNKNOWN_ERROR | EXTMMC_R6_ILLEGAL_CMD | EXTMMC_R6_COM_CRC_FAILED)))
	{
		*prca = (uint16_t) (response_r1 >> 16);
		return(errorstatus);
	}

	if (response_r1 & EXTMMC_R6_GENERAL_UNKNOWN_ERROR)
	{
		return(EXTMMC_GENERAL_UNKNOWN_ERROR);
	}

	if (response_r1 & EXTMMC_R6_ILLEGAL_CMD)
	{
		return(EXTMMC_ILLEGAL_CMD);
	}

	if (response_r1 & EXTMMC_R6_COM_CRC_FAILED)
	{
		return(EXTMMC_COM_CRC_FAILED);
	}

	return(errorstatus);
}

/**
* @brief  Enables or disables the SDIO wide bus mode.
* @param  NewState: new state of the SDIO wide bus mode.
*   This parameter can be: ENABLE or DISABLE.
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error SDEnWideBus(FunctionalState NewState)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;

	uint32_t scr[2] = {0, 0};

	if (SDIO_GetResponse(SDIO_RESP1) & EXTMMC_CARD_LOCKED)
	{
		errorstatus = EXTMMC_LOCK_UNLOCK_FAILED;
		return(errorstatus);
	}

	/* Get SCR Register */
	errorstatus = FindSCR(EXTMMC_Gdata->RCA, scr);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	/* If wide bus operation to be enabled */
	if (NewState == ENABLE)
	{
		/* If requested card supports wide bus operation */
		if ((scr[1] & EXTMMC_WIDE_BUS_SUPPORT) != EXTMMC_ALLZERO)
		{
			/* Send CMD55 APP_CMD with argument as card's RCA.*/
			//EXTMMC_Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2((u32) EXTMMC_Gdata->RCA << 16, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
			errorstatus = CmdResp1Error(SDIO_APP_CMD);

			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}

			/* Send ACMD6 APP_CMD with argument as 2 for wide bus mode */
			//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x2;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_SD_SET_BUSWIDTH;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2((u32) 0x2, (u32) (SDIO_APP_SD_SET_BUSWIDTH | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
			errorstatus = CmdResp1Error(SDIO_APP_SD_SET_BUSWIDTH);

			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}
			return(errorstatus);
		}
		else
		{
			errorstatus = EXTMMC_REQUEST_NOT_APPLICABLE;
			return(errorstatus);
		}
	}   /* If wide bus operation to be disabled */
	else
	{
		/* If requested card supports 1 bit mode operation */
		if ((scr[1] & EXTMMC_SINGLE_BUS_SUPPORT) != EXTMMC_ALLZERO)
		{
			/* Send CMD55 APP_CMD with argument as card's RCA.*/
			//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2((u32) EXTMMC_Gdata->RCA << 16, (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));

			errorstatus = CmdResp1Error(SDIO_APP_CMD);

			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}

			/* Send ACMD6 APP_CMD with argument as 2 for wide bus mode */
			//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x00;
			//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_SD_SET_BUSWIDTH;
			//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
			//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
			//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
			//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
			SDIO_SendCommand2(0, (u32) (SDIO_APP_SD_SET_BUSWIDTH | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
			errorstatus = CmdResp1Error(SDIO_APP_SD_SET_BUSWIDTH);

			if (errorstatus != EXTMMC_OK)
			{
				return(errorstatus);
			}

			return(errorstatus);
		}
		else
		{
			errorstatus = EXTMMC_REQUEST_NOT_APPLICABLE;
			return(errorstatus);
		}
	}
}

/**
* @brief  Checks if the SD card is in programming state.
* @param  pstatus: pointer to the variable that will contain the SD
*   card state.
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error IsCardProgramming(uint8_t *pstatus)
{
	EXTMMC_Error errorstatus = EXTMMC_OK;
	__IO uint32_t respR1 = 0, status = 0;

	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SEND_STATUS;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) (EXTMMC_Gdata->RCA << 16), (u32) (SDIO_SEND_STATUS | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	status = SDIO->STA;
	while (!(status & (SDIO_FLAG_CCRCFAIL | SDIO_FLAG_CMDREND | SDIO_FLAG_CTIMEOUT)))
	{
		status = SDIO->STA;
	}

	if (status & SDIO_FLAG_CTIMEOUT)
	{
		errorstatus = EXTMMC_CMD_RSP_TIMEOUT;
		SDIO_ClearFlag(SDIO_FLAG_CTIMEOUT);
		return(errorstatus);
	}
	else if (status & SDIO_FLAG_CCRCFAIL)
	{
		errorstatus = EXTMMC_CMD_CRC_FAIL;
		SDIO_ClearFlag(SDIO_FLAG_CCRCFAIL);
		return(errorstatus);
	}

	status = (uint32_t)SDIO_GetCommandResponse();

	/* Check response received is of desired command */
	if (status != SDIO_SEND_STATUS)
	{
		errorstatus = EXTMMC_ILLEGAL_CMD;
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);


	/* We have received response, retrieve it for analysis  */
	respR1 = SDIO_GetResponse(SDIO_RESP1);

	/* Find out card status */
	*pstatus = (uint8_t) ((respR1 >> 9) & 0x0000000F);

	if ((respR1 & EXTMMC_OCR_ERRORBITS) == EXTMMC_ALLZERO)
	{
		return(errorstatus);
	}

	if (respR1 & EXTMMC_OCR_ADDR_OUT_OF_RANGE)
	{
		return(EXTMMC_ADDR_OUT_OF_RANGE);
	}

	if (respR1 & EXTMMC_OCR_ADDR_MISALIGNED)
	{
		return(EXTMMC_ADDR_MISALIGNED);
	}

	if (respR1 & EXTMMC_OCR_BLOCK_LEN_ERR)
	{
		return(EXTMMC_BLOCK_LEN_ERR);
	}

	if (respR1 & EXTMMC_OCR_ERASE_SEQ_ERR)
	{
		return(EXTMMC_ERASE_SEQ_ERR);
	}

	if (respR1 & EXTMMC_OCR_BAD_ERASE_PARAM)
	{
		return(EXTMMC_BAD_ERASE_PARAM);
	}

	if (respR1 & EXTMMC_OCR_WRITE_PROT_VIOLATION)
	{
		return(EXTMMC_WRITE_PROT_VIOLATION);
	}

	if (respR1 & EXTMMC_OCR_LOCK_UNLOCK_FAILED)
	{
		return(EXTMMC_LOCK_UNLOCK_FAILED);
	}

	if (respR1 & EXTMMC_OCR_COM_CRC_FAILED)
	{
		return(EXTMMC_COM_CRC_FAILED);
	}

	if (respR1 & EXTMMC_OCR_ILLEGAL_CMD)
	{
		return(EXTMMC_ILLEGAL_CMD);
	}

	if (respR1 & EXTMMC_OCR_CARD_ECC_FAILED)
	{
		return(EXTMMC_CARD_ECC_FAILED);
	}

	if (respR1 & EXTMMC_OCR_CC_ERROR)
	{
		return(EXTMMC_CC_ERROR);
	}

	if (respR1 & EXTMMC_OCR_GENERAL_UNKNOWN_ERROR)
	{
		return(EXTMMC_GENERAL_UNKNOWN_ERROR);
	}

	if (respR1 & EXTMMC_OCR_STREAM_READ_UNDERRUN)
	{
		return(EXTMMC_STREAM_READ_UNDERRUN);
	}

	if (respR1 & EXTMMC_OCR_STREAM_WRITE_OVERRUN)
	{
		return(EXTMMC_STREAM_WRITE_OVERRUN);
	}

	if (respR1 & EXTMMC_OCR_CID_CSD_OVERWRIETE)
	{
		return(EXTMMC_CID_CSD_OVERWRITE);
	}

	if (respR1 & EXTMMC_OCR_WP_ERASE_SKIP)
	{
		return(EXTMMC_WP_ERASE_SKIP);
	}

	if (respR1 & EXTMMC_OCR_CARD_ECC_DISABLED)
	{
		return(EXTMMC_CARD_ECC_DISABLED);
	}

	if (respR1 & EXTMMC_OCR_ERASE_RESET)
	{
		return(EXTMMC_ERASE_RESET);
	}

	if (respR1 & EXTMMC_OCR_AKE_SEQ_ERROR)
	{
		return(EXTMMC_AKE_SEQ_ERROR);
	}

	return(errorstatus);
}

/**
* @brief  Find the SD card SCR register value.
* @param  rca: selected card address.
* @param  pscr: pointer to the buffer that will contain the SCR value.
* @retval EXTMMC_Error: SD Card Error code.
*/
static EXTMMC_Error FindSCR(uint16_t rca, uint32_t *pscr)
{
	uint32_t index = 0;
	EXTMMC_Error errorstatus = EXTMMC_OK;
	uint32_t tempscr[2] = {0, 0};

	/* Set Block Size To 8 Bytes */
	/* Send CMD55 APP_CMD with argument as card's RCA */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t)8;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SET_BLOCKLEN;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) 8, (u32) (SDIO_SET_BLOCKLEN | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SET_BLOCKLEN);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	/* Send CMD55 APP_CMD with argument as card's RCA */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = (uint32_t) Gdata->RCA << 16;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_APP_CMD;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2((u32) (EXTMMC_Gdata->RCA << 16), (u32) (SDIO_APP_CMD | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_APP_CMD);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}
	//Gdata->SDIO_DataInitStructure.SDIO_DataTimeOut = EXTMMC_DATATIMEOUT;
	//Gdata->SDIO_DataInitStructure.SDIO_DataLength = 8;
	//Gdata->SDIO_DataInitStructure.SDIO_DataBlockSize = SDIO_DataBlockSize_8b;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferDir = SDIO_TransferDir_ToSDIO;
	//Gdata->SDIO_DataInitStructure.SDIO_TransferMode = SDIO_TransferMode_Block;
	//Gdata->SDIO_DataInitStructure.SDIO_DPSM = SDIO_DPSM_Enable;
	//SDIO_DataConfig(&(Gdata->SDIO_DataInitStructure));
	SDIO_DataConfig2(EXTMMC_DATATIMEOUT, 8, (u32)(SDIO_DataBlockSize_8b | SDIO_TransferDir_ToSDIO | SDIO_TransferMode_Block | SDIO_DPSM_Enable));

	/* Send ACMD51 EXTMMC_APP_SEND_SCR with argument as 0 */
	//Gdata->SDIO_CmdInitStructure.SDIO_Argument = 0x0;
	//Gdata->SDIO_CmdInitStructure.SDIO_CmdIndex = SDIO_SD_APP_SEND_SCR;
	//Gdata->SDIO_CmdInitStructure.SDIO_Response = SDIO_Response_Short;
	//Gdata->SDIO_CmdInitStructure.SDIO_Wait = SDIO_Wait_No;
	//Gdata->SDIO_CmdInitStructure.SDIO_CPSM = SDIO_CPSM_Enable;
	//SDIO_SendCommand(&(Gdata->SDIO_CmdInitStructure));
	SDIO_SendCommand2(0, (u32) (SDIO_SD_APP_SEND_SCR | SDIO_Response_Short | SDIO_Wait_No | SDIO_CPSM_Enable));
	errorstatus = CmdResp1Error(SDIO_SD_APP_SEND_SCR);

	if (errorstatus != EXTMMC_OK)
	{
		return(errorstatus);
	}

	while (!(SDIO->STA & (SDIO_FLAG_RXOVERR | SDIO_FLAG_DCRCFAIL | SDIO_FLAG_DTIMEOUT | SDIO_FLAG_DBCKEND | SDIO_FLAG_STBITERR)))
	{
		if (SDIO_GetFlagStatus(SDIO_FLAG_RXDAVL) != RESET)
		{
			*(tempscr + index) = SDIO_ReadData();
			index++;
		}
	}

	if (SDIO_GetFlagStatus(SDIO_FLAG_DTIMEOUT) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_DTIMEOUT);
		errorstatus = EXTMMC_DATA_TIMEOUT;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_DCRCFAIL) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_DCRCFAIL);
		errorstatus = EXTMMC_DATA_CRC_FAIL;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_RXOVERR) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_RXOVERR);
		errorstatus = EXTMMC_RX_OVERRUN;
		return(errorstatus);
	}
	else if (SDIO_GetFlagStatus(SDIO_FLAG_STBITERR) != RESET)
	{
		SDIO_ClearFlag(SDIO_FLAG_STBITERR);
		errorstatus = EXTMMC_START_BIT_ERR;
		return(errorstatus);
	}

	/* Clear all the static flags */
	SDIO_ClearFlag(SDIO_STATIC_FLAGS);

	*(pscr + 1) = ((tempscr[0] & EXTMMC_0TO7BITS) << 24) | ((tempscr[0] & EXTMMC_8TO15BITS) << 8) | ((tempscr[0] & EXTMMC_16TO23BITS) >> 8) | ((tempscr[0] & EXTMMC_24TO31BITS) >> 24);

	*(pscr) = ((tempscr[1] & EXTMMC_0TO7BITS) << 24) | ((tempscr[1] & EXTMMC_8TO15BITS) << 8) | ((tempscr[1] & EXTMMC_16TO23BITS) >> 8) | ((tempscr[1] & EXTMMC_24TO31BITS) >> 24);

	return(errorstatus);
}

/**
* @brief  Converts the number of bytes in power of two and returns the
*   power.
* @param  NumberOfBytes: number of bytes.
* @retval None
*/
//static uint8_t convert_from_bytes_to_power_of_two(uint16_t NumberOfBytes)
//{
//  uint8_t count = 0;

//  while (NumberOfBytes != 1)
//  {
//    NumberOfBytes >>= 1;
//    count++;
//  }
//  return(count);
//}

/**
* @brief  Configures the SDIO Corresponding GPIO Ports
* @param  None
* @retval None
*/
static void GPIO_Configuration(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	//D0  pin98 PC8 SDIO_D7
	//D1  pin99 PC9 SDIO_D1
	//D2  pin111 PC10 SDIO_D2
	//D3  pin112 PC11 SDIO_D3
	//CK  pin113 PC12 SDIO_CK
	//CMD pin116 PD2 SDIO_CMD
	/* GPIOC and GPIOD Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);

	/* Configure PC.08, PC.09, PC.10, PC.11, PC.12 pin: D0, D1, D2, D3, CLK pin */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* Configure PD.02 CMD line */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}

/**
* @brief  Configures the DMA2 Channel4 for SDIO Tx request.
* @param  BufferSRC: pointer to the source buffer
* @param  BufferSize: buffer size
* @retval None
*/
static void DMA_TxConfiguration(uint32_t *BufferSRC, uint32_t BufferSize)
{
	DMA_InitTypeDef DMA_InitStructure;

	DMA_ClearFlag(DMA2_FLAG_TC4 | DMA2_FLAG_TE4 | DMA2_FLAG_HT4 | DMA2_FLAG_GL4);

	/* DMA2 Channel4 disable */
	DMA_Cmd(DMA2_Channel4, DISABLE);

	/* DMA2 Channel4 Config */
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SDIO_FIFO_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)BufferSRC;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = BufferSize / 4;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel4, &DMA_InitStructure);

	/* DMA2 Channel4 enable */
	DMA_Cmd(DMA2_Channel4, ENABLE);
}

/**
* @brief  Configures the DMA2 Channel4 for SDIO Rx request.
* @param  BufferDST: pointer to the destination buffer
* @param  BufferSize: buffer size
* @retval None
*/
static void DMA_RxConfiguration(uint32_t *BufferDST, uint32_t BufferSize)
{
	DMA_InitTypeDef DMA_InitStructure;

	DMA_ClearFlag(DMA2_FLAG_TC4 | DMA2_FLAG_TE4 | DMA2_FLAG_HT4 | DMA2_FLAG_GL4);

	/* DMA2 Channel4 disable */
	DMA_Cmd(DMA2_Channel4, DISABLE);

	/* DMA2 Channel4 Config */
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SDIO_FIFO_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)BufferDST;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = BufferSize / 4;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel4, &DMA_InitStructure);

	/* DMA2 Channel4 enable */
	DMA_Cmd(DMA2_Channel4, ENABLE);
}

