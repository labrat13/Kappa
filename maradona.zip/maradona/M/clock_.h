//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for CLOCK subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_CLOCK_H
#define  MY_CLOCK_H

#include "stm32f10x.h" //project data types

//DEFINES

// CLOCK MODES
//CLKMODE_12: hclk=12; pclk1=12; pclk2=12; adcclk=pclk2/2=6m; flatency=0;
//CLKMODE_24: hclk=24; pclk1=24; pclk2=24; adcclk=pclk2/4=6m; flatency=0;
//CLKMODE_48: hclk=48; pclk1=24; pclk2=24; adcclk=pclk2/4=6m; flatency=1;
//CLKMODE_72: hclk=72; pclk1=36; pclk2=36; adcclk=pclk2/6=6m; flatency=2;
#define CLKMODE_12  0 //12MHZ
#define CLKMODE_24  1 //24MHZ
#define CLKMODE_48  2 //48MHZ
#define CLKMODE_72  3 //72MHZ

//PROTOTYPES
void CLOCK_Init(u16 clkMode); //init clock by mode number
void CLOCK_Exit(); //exit clock




#endif // MY_CLOCK_H