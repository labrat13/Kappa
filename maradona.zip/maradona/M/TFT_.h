//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for TFT subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_TFT_H
#define  MY_TFT_H

#include "stm32f10x.h"
#include "ram_.h"
#include "time_.h"
#include "colors.h"

//DEFINES
//define char size 
#define CHAR_W			8	// char width
#define CHAR_H			14	// logical char height, include row interval
#define CHAR_W_ACTUAL	8	// char width
#define CHAR_H_ACTUAL	12	// real char height

//tft size  vertical (default after reset)
#define TFT_SIZE_X 240
#define TFT_SIZE_Y 320

//display orientation modes
typedef enum
{
    TFT_Portrait  = 0,
    TFT_Landscape = 1,    
} TFT_DisplayOrder;

//COLORS - replaced to COLOR_ defines in colors.h
// #define tftBLACK	0x0000
// #define tftWHITE	0xffff
// #define tftRED		63488	//�������
// #define tftGREEN	2016	//�������
// #define tftBLUE		31		//�����
// #define tftYELLOW	65504	//������
// #define tftSKY		2047	//�������
// #define tftMAGENTA	63519   //����������
// #define tftGRAY		33808   //�����
// #define tftDGRAY	16904	//�����-�����
// #define tftLGRAY	50712	//������-�����

//GLOBAL VARIABLES

//PROTOTYPES
//init FSMC hardware for display
void TFT_FsmcInit();
//tft display initialization
void TFT_DisplayInit();
void TFT_Exit();
void TFT_Init();

//fill rectangle with specified color
void  APIEXPORT TFT_FillRect(u16 x1, u16 y1, u16 width, u16 height, u16 color);

//draw single pixel with specified color
void  APIEXPORT TFT_SetPixel(u16 x, u16 y, u16 color);

//read pixels from specified screen rectangle
void  APIEXPORT TFT_ReadRect(u16 x, u16 y, u16 width, u16 height, u16* buf);

//write pixels to specified screen rectangle
void  APIEXPORT TFT_WriteRect(u16 x, u16 y, u16 width, u16 height, u16* buf); 

//set display update order 
void  TFT_SetScanOrder(TFT_DisplayOrder order);

//Write one char rect
void  APIEXPORT TFT_WriteChar(u8 ch, u16 X, u16 Y, u16 color, u16 bgcolor);

//get address of u8*12 dotmap for char
u8*  APIEXPORT TFT_fontGetChar(u8 ch);

//*********** LOW LEVEL COMMON FUNCTIONS ************
//Set rectangle for reading/writing operations
void tftSetDrawRect(
 u16 x1, //start column
 u16 y1, //start row
 u16 x2, //end column
 u16 y2); //end row

//Set rectangle for reading/writing operations
void TFT_SetDrawRect2(u16 x, u16 y, u16 w, u16 h);

//send pixels to display (when size is known)
void TFT_Fill(u32 count, u16 color);

//read data from display in already specified rect
void TFT_Read(u16* buf, u32 cnt); 

//write data for already specified rect
void TFT_Write(u16* buf, u32 cnt); 






#endif // MY_TFT_H