/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/


//INCLUDES

#include "GData.h"

//PRIVATE DEFINES
#define GDATA_ALIGN_INT_VERTICAL_MASK		3
#define GDATA_ALIGN_INT_HORIZONTAL_MASK	12
//PRIVATE VARIABLES

//PUBLIC VARIABLES

//PRIVATE FUNCTION DECLARATION

//FUNCTION BODY

//RECT FUNCTIONS

u32  APIEXPORT GDATA_rectGetEndX(LPGDATA_RECT rc)
{
    return (u32)rc->X + rc->Width - 1;
}

u32  APIEXPORT GDATA_rectGetEndY(LPGDATA_RECT rc)
{
    return (u32)rc->Y + rc->Height - 1;
}

void  APIEXPORT GDATA_rectSetRect(LPGDATA_RECT rc, u32 x, u32 y, u32 width, u32 height)
{
    rc->X = (u16)x;
    rc->Y = (u16)y;
    rc->Width = (u16)width;
    rc->Height = (u16)height;
}

void  APIEXPORT GDATA_rectSetPoint(LPGDATA_RECT rc, LPGDATA_POINT pt)
{
    rc->X = pt->X;
    rc->Y = pt->Y;
}

void  APIEXPORT GDATA_rectSetSize(LPGDATA_RECT rc, LPGDATA_SIZE sz)
{
    rc->Width = sz->Width;
    rc->Height = sz->Height;
}

u32 APIEXPORT  GDATA_rectPtInRect2(LPGDATA_RECT rc, LPGDATA_POINT pt)
{
    u16 x = pt->X;
    u16 y = pt->Y;
    if((x >= rc->X) && (x <= (rc->X + rc->Width - 1)) && (y >= rc->Y) && (y <= (rc->Y + rc->Height - 1)))
		return 1; else return 0;
}

u32  APIEXPORT GDATA_rectPtInRect(LPGDATA_RECT rc, u32 x, u32 y)
{
    if((x >= rc->X) && (x <= (rc->X + rc->Width - 1)) && (y >= rc->Y) && (y <= (rc->Y + rc->Height - 1)))
		return 1; else return 0;
}

//Check that inner rect in outer rect fully 
u32  APIEXPORT GDATA_rectRectInRect(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner)
{
	if (GDATA_rectPtInRect(rcOuter, rcInner->X, rcInner->Y) && GDATA_rectPtInRect(rcOuter, GDATA_rectGetEndX(rcInner), GDATA_rectGetEndY(rcInner)))
		return 1; else return 0;
}

//���������� ����������� ������������� ������ ������ ������� ��������������
//�������� ��������� ����� ����������� ��������������
void  APIEXPORT GDATA_rectAlign(LPGDATA_RECT rcOuter, LPGDATA_RECT rcInner, u32 alignMode)
{
	//vertical align
	if ((alignMode & GDATA_ALIGN_INT_VERTICAL_MASK) == GDATA_ALIGN_ONLY_TOP)	//top
	{
		rcInner->Y = rcOuter->Y; //align top
	}
	else if ((alignMode & GDATA_ALIGN_INT_VERTICAL_MASK) == GDATA_ALIGN_ONLY_MIDDLE)//middle
	{
		rcInner->Y += ((s32)(rcOuter->Y + rcOuter->Height / 2)- (s32)(rcInner->Y + rcInner->Height / 2));
	}
	else if ((alignMode & GDATA_ALIGN_INT_VERTICAL_MASK) == GDATA_ALIGN_ONLY_BOTTOM)//bottom
	{
		rcInner->Y = (rcOuter->Y + rcOuter->Height - 1) - rcInner->Height;
	}
	//horizontal align
	if ((alignMode & GDATA_ALIGN_INT_HORIZONTAL_MASK) == GDATA_ALIGN_ONLY_LEFT)//left
	{
		rcInner->X = rcOuter->X;
	}
	else if ((alignMode & GDATA_ALIGN_INT_HORIZONTAL_MASK) == GDATA_ALIGN_ONLY_CENTER)//center
	{
		rcInner->X += ((s32)(rcOuter->X + rcOuter->Width / 2) - (s32)(rcInner->X + rcInner->Width / 2));
	}
	else if ((alignMode & GDATA_ALIGN_INT_HORIZONTAL_MASK) == GDATA_ALIGN_ONLY_RIGHT)//right
	{
		rcInner->X = (rcOuter->X + rcOuter->Width - 1) - rcInner->Width;
	}
	return;
}