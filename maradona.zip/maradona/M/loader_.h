//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for LOADER subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_LOADER_H
#define  MY_LOADER_H

#include "stm32f10x.h" //project data types
//DEFINES
//error codes of Load functions
#define LOADER_SUCCESS		0	//file load success
#define LOADER_ALLOC_FAIL   1	//memory allocation fail
#define LOADER_FORMAT_FAIL   2	//invalid elf format or structure
#define LOADER_FILE_FAIL   3    //file access failed


//PROTOTYPES
//init module
void LOADER_Init();
//exit module
void LOADER_Exit();


//Load program file. Return error code
//Caller must use defined entrypoint for execute file
//this function consume stack, thus not execute entrypoint directly
//szPath = elf file short pathname like  /dir/file.elf 
//readBuf = buffer 64 bytes for reading file
//return = error code
u32 LOADER_Load(u8* szPath, u8* readBuf);
//Load elf program file. Return error code
//Caller must use defined entrypoint for execute file
//this function consume stack, thus not execute entrypoint directly
//szPath = elf file pathname
//return = error code
u32 LOADER_Load2(u8* szPath);
//Execute loaded application and return result
//Arg0 = buffer or string
//Arg1 = number
//return = application result
inline u32 LOADER_Execute(u8* Arg0, u32 Arg1);
#endif // MY_LOADER_H