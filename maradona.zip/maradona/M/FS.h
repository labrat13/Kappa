//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for FS subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_FS_H
#define  MY_FS_H

#include "stm32f10x.h"
//define label that this function exported in M_API
#ifndef APIEXPORT
#define APIEXPORT
#endif


// Devices to be mounted
typedef enum _FS_Card_device
{
	unkCARD = 0,  //unknown card
	intCARD,
	extCARD,
}FS_CardDevice;


//===================================================================
// Configurable items
#define FS_MAX_PATH		64		// Maximum path length (increasing this will
								// GREATLY increase stack requirements!)
#define FS_DIR_SEPARATOR	'/'		// character separating directory components

// End of configurable items
//===================================================================
// 32-bit error codes
#define FS_OK			0			// no error
#define FS_EOF			1			// end of file (not an error)
#define FS_WRITEPROT	2			// volume is write protected
#define FS_NOTFOUND	    3			// path or file not found
#define FS_PATHLEN		4			// path too long
#define FS_ALLOCNEW	    5			// must allocate new directory cluster
#define FSS_INVALIDPATH		10		//INVALID PATH FORMAT
#define FSS_MOUNTFAIL		11		//DRIVE MOUNT FAIL
#define FS_ERRMISC		0xffffffff	// generic error

//===================================================================
// File access modes
#define FS_READ			1			// read-only
#define FS_WRITE		2			// write-only

//===================================================================
// Miscellaneous constants
#define FS_SECTOR_SIZE		512		    // sector size in bytes

//===================================================================
// DOS attribute bits
#define FS_ATTR_READ_ONLY	    0x01
#define FS_ATTR_HIDDEN			0x02
#define FS_ATTR_SYSTEM			0x04
#define FS_ATTR_VOLUME_ID	    0x08
#define FS_ATTR_DIRECTORY	    0x10
#define FS_ATTR_ARCHIVE	        0x20
#define FS_ATTR_LONG_NAME	(FS_ATTR_READ_ONLY | FS_ATTR_HIDDEN | FS_ATTR_SYSTEM | FS_ATTR_VOLUME_ID)


/*
	Directory entry structure
	note: if name[0] == 0xe5, this is a free dir entry
	      if name[0] == 0x00, this is a free entry and all subsequent entries are free
		  if name[0] == 0x05, the first character of the name is 0xe5 [a kanji nicety]

	Date format: bit 0-4  = day of month (1-31)
	             bit 5-8  = month, 1=Jan..12=Dec
				 bit 9-15 =	count of years since 1980 (0-127)
	Time format: bit 0-4  = 2-second count, (0-29)
	             bit 5-10 = minutes (0-59)
				 bit 11-15= hours (0-23)
*/
typedef struct _tagDIRENT {
	u8 name[11];			// filename
	u8 attr;				// attributes (see FS_ATTR_* constant definitions)
	u8 reserved;			// reserved, must be 0
	u8 crttimetenth;		// create time, 10ths of a second (0-199 are valid)
	u8 crttime_l;			// creation time low byte
	u8 crttime_h;			// creation time high byte
	u8 crtdate_l;			// creation date low byte
	u8 crtdate_h;			// creation date high byte
	u8 lstaccdate_l;		// last access date low byte
	u8 lstaccdate_h;		// last access date high byte
	u8 startclus_h_l;		// high word of first cluster, low byte (FAT32)
	u8 startclus_h_h;		// high word of first cluster, high byte (FAT32)
	u8 wrttime_l;			// last write time low byte
	u8 wrttime_h;			// last write time high byte
	u8 wrtdate_l;			// last write date low byte
	u8 wrtdate_h;			// last write date high byte
	u8 startclus_l_l;		// low word of first cluster, low byte
	u8 startclus_l_h;		// low word of first cluster, high byte
	u8 filesize_0;			// file size, low byte
	u8 filesize_1;			//
	u8 filesize_2;			//
	u8 filesize_3;			// file size, high byte
} FS_DIRENT, *PFS_DIRENT;

/*
	Volume information structure (Internal to DOSFS)
*/
typedef struct _tagVOLINFO {
	u8 unit;				// unit on which this volume resides
	u8 filesystem;			// formatted filesystem
// These two fields aren't very useful, so support for them has been commented out to
// save memory. (Note that the "system" tag is not actually used by DOS to determine
// filesystem type - that decision is made entirely on the basis of how many clusters
// the drive contains. DOSFS works the same way).
// See tag: OEMID in dosfs.c
//	u8 oemid[9];			// OEM ID ASCIIZ
//	u8 system[9];			// system ID ASCIIZ
	u8 label[12];			// volume label ASCIIZ
	u32 startsector;		// starting sector of filesystem
	u8 secperclus;			// sectors per cluster
	u16 reservedsecs;		// reserved sectors
	u32 numsecs;			// number of sectors in volume
	u32 secperfat;			// sectors per FAT
	u16 rootentries;		// number of root dir entries
	u32 numclusters;		// number of clusters on drive
	// The fields below are PHYSICAL SECTOR NUMBERS.
	u32 fat1;				// starting sector# of FAT copy 1
	u32 rootdir;			// starting sector# of root directory (FAT12/FAT16) or cluster (FAT32)
	u32 dataarea;			// starting sector# of data area (cluster #2)
} FS_VOLINFO, *PFS_VOLINFO;

/*
	Flags in DIRINFO.flags
*/
#define FS_DI_BLANKENT		0x01	// Searching for blank entry

/*
	Directory search structure (Internal to DOSFS)
*/
typedef struct _tagDIRINFO {
	u32 currentcluster;	// current cluster in dir
	u8 currentsector;		// current sector in cluster
	u8 currententry;		// current dir entry in sector
	u8* scratch;			// ptr to user-supplied scratch buffer (one sector)
	PFS_VOLINFO volinfo;	// VOLINFO used to open this directory
    u8 flags;				// internal DOSFS flags
} FS_DIRINFO, *PFS_DIRINFO;

/*
	File handle structure (Internal to DOSFS)
*/
typedef struct _tagFILEINFO {
	PFS_VOLINFO volinfo;			// VOLINFO used to open this file
	u32 dirsector;			// physical sector containing dir entry of this file
	u8 diroffset;			// # of this entry within the dir sector
	u8 mode;				// mode in which this file was opened
	u32 firstcluster;		// first cluster of file
	u32 filelen;			// byte length of file
	u32 cluster;			// current cluster
	u32 pointer;			// current (BYTE) pointer
} FS_FILEINFO, *PFS_FILEINFO;

//===================================================================
// User-supplied functions
u32  APIEXPORT FS_ReadSector(u32 unit, u8 *buffer, u32 sector);
u32  APIEXPORT FS_WriteSector(u32 unit, u8 *buffer, u32 sector);
u32  APIEXPORT FS_Mount(FS_CardDevice device, u8* scratchbuffer);
u32  APIEXPORT FS_Unmount(FS_CardDevice device);
u32 FS_Init();
void FS_Exit(); 
//===================================================================

/*
	Get starting sector# of specified partition on drive #unit
	NOTE: This code ASSUMES an MBR on the disk.
	scratchsector should point to a SECTOR_SIZE scratch area
	Returns 0xffffffff for any error.
	If pactive is non-NULL, this function also returns the partition active flag.
	If pptype is non-NULL, this function also returns the partition type.
	If psize is non-NULL, this function also returns the partition size.
*/
u32  APIEXPORT FS_GetPtnStart(u32 unit, u8 *scratchsector, u32 pnum, u8 *pactive, u8 *pptype, u32 *psize);

/*
	Retrieve volume info from BPB and store it in a VOLINFO structure
	You must provide the unit and starting sector of the filesystem, and
	a pointer to a sector buffer for scratch
	Attempts to read BPB and glean information about the FS from that.
	Returns 0 OK, nonzero for any error.
*/
u32  APIEXPORT FS_GetVolInfo(u32 unit, u8 *scratchsector, u32 startsector, PFS_VOLINFO volinfo);

/*
	Open a directory for enumeration by FS_GetNextDirEnt
	You must supply a populated VOLINFO (see FS_GetVolInfo)
	The empty string or a string containing only the directory separator are
	considered to be the root directory.
	Returns 0 OK, nonzero for any error.
*/
u32  APIEXPORT FS_OpenDir(PFS_VOLINFO volinfo, u8 * dirname, PFS_DIRINFO dirinfo);

/*
	Get next entry in opened directory structure. Copies fields into the dirent
	structure, updates dirinfo. Note that it is the _caller's_ responsibility to
	handle the '.' and '..' entries.
	A deleted file will be returned as a NULL entry (first char of filename=0)
	by this code. Filenames beginning with 0x05 will be translated to 0xE5
	automatically. Long file name entries will be returned as NULL.
	returns FS_EOF if there are no more entries, FS_OK if this entry is valid,
	or FS_ERRMISC for a media error
*/
u32  APIEXPORT FS_GetNext(PFS_VOLINFO volinfo, PFS_DIRINFO dirinfo, PFS_DIRENT dirent);

/*
	Open a file for reading or writing. You supply populated VOLINFO, a path to the file,
	mode (FS_READ or FS_WRITE) and an empty fileinfo structure. You also need to
	provide a pointer to a sector-sized scratch buffer.
	Returns various FS_* error states. If the result is FS_OK, fileinfo can be used
	to access the file from this point on.
*/
u32  APIEXPORT FS_OpenFile(PFS_VOLINFO volinfo, u8 *path, u32 mode, u8 *scratch, PFS_FILEINFO fileinfo);

/*
	Read an open file
	You must supply a prepopulated FILEINFO as provided by FS_OpenFile, and a
	pointer to a SECTOR_SIZE scratch buffer.
	Note that returning FS_EOF is not an error condition. This function updates the
	successcount field with the number of bytes actually read.
*/
u32  APIEXPORT FS_ReadFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);

/*
	Write an open file
	You must supply a prepopulated FILEINFO as provided by FS_OpenFile, and a
	pointer to a SECTOR_SIZE scratch buffer.
	This function updates the successcount field with the number of bytes actually written.
*/
u32  APIEXPORT FS_WriteFile(PFS_FILEINFO fileinfo, u8 *scratch, u8 *buffer, u32 *successcount, u32 len);

/*
	Seek file pointer to a given position
	This function does not return status - refer to the fileinfo->pointer value
	to see where the pointer wound up.
	Requires a SECTOR_SIZE scratch buffer
*/
void  APIEXPORT FS_Seek(PFS_FILEINFO fileinfo, u32 offset, u8 *scratch);

/*
	Delete a file
	scratch must point to a sector-sized buffer
*/
u32  APIEXPORT FS_UnlinkFile(PFS_VOLINFO volinfo, u8 *path, u8 *scratch);

/////////////////////////////////////////////////////////////////////////////////////
//    FSS subsystem layer 
//    Automatic management for cards and buffers
/////////////////////////////////////////////////////////////////////////////////////

//Split path to device code and path
//path = complex path like I:/file.ext
//pCard = pointer to FS_CardDevice variable
//return = part of path, without I: sentence 
u8* FS_splitPathCard(u8* path, FS_CardDevice* pCard);


//This function call by system on init process
u32 FSS_Init();
//This function call by system on exit process
void FSS_Exit();


//NT-prevent all volume unmount
//val=0 allow unmounting volumes when unused
//val=1 prevent unmount unused volumes
void FSS_PreventUnmounting(u32 val);

//NT-Close dirs after FSS_OpenDir()
void FSS_CloseDir(PFS_DIRINFO dirinfo);

//NT-Close files after FSS_OpenFile()
void FSS_CloseFile(PFS_FILEINFO fileinfo);

//NT- delete file
//path=file or folder path like E:/folder/file.ext\0
u32 FSS_UnlinkFile(u8* path);

//NT-return current file position
u32 FSS_getFilePosition(PFS_FILEINFO fileinfo);

//NT-set file position
void FSS_SetFilePosition(PFS_FILEINFO fileinfo, u32 offset);

//NT-Write file
//fileinfo=pointer to fileinfo structure from OpenFile()
//buffer=read buffer
//len=num of bytes to write
//successcount=number of bytes successfully written
u32 FSS_WriteFile(PFS_FILEINFO fileinfo, u8* buffer, u32 len, u32* successcount);

//NT-Read file
//fileinfo=pointer to fileinfo structure from OpenFile()
//buffer=read buffer
//len=num of bytes to read
//successcount=number of bytes successfully readed
u32 FSS_ReadFile(PFS_FILEINFO fileinfo, u8* buffer, u32 len, u32* successcount);

//NT-Open file
//path=file path like E:/folder/file.ext\0
//mode=opening mode
//fileinfo=pointer to structure for next using
u32 FSS_OpenFile(u8* path, u8 mode, PFS_FILEINFO fileinfo);

//NT-Get next directory item
u32 FSS_GetNext(PFS_DIRINFO dirinfo, PFS_DIRENT dirent);

//NT-Open directory for enumeration items
//path=directory path like E:/folder/file.ext\0
//dirinfo=pointer to directory info struct for next using
u32 FSS_OpenDir(u8* path, PFS_DIRINFO dirinfo);


#endif // MY_FS_H