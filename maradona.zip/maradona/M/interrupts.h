//************************************************************
// Copyright (C) 2012-2013 Pavel Selyakov
// Header for INTERRUPTS subsystem of Maradona project
// Nov 22, 2012: refactoring

//************************************************************

#ifndef MY_INTERRUPTS_H
#define  MY_INTERRUPTS_H

#include "stm32f10x.h" //project data types

//DEFINES

//GLOBAL VARIABLES

//PROTOTYPES
//initialize interrupts accord to current clockmode
void INTERRUPTS_Init(u16 clkMode);
//deinitialize interrupts
void INTERRUPTS_Exit();
//disable irq channel - replace by NVIC_DisableIRQ(IRQn_Type irq);




#endif // MY_INTERRUPTS_H