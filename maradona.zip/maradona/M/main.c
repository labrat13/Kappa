//************************************************************
// Copyright (C) 2011 Pavel Selyakov
// Main file for project
// Nov 22, 2012: initial

//************************************************************

//defines for my device
//#define STM32F10X_HD //for stm32f103zet6, define in project settings
#define HSE_VALUE    ((uint32_t) 12000000) //crystal used 12 MHz 
#define HSE_Value    ((uint32_t) 12000000) //crystal used 12 MHz 
//#define USE_STDPERIPH_DRIVER //stm32f10x.h for use ST peripherial libraries

//defined in project settings accord build confs
//#define SIMULATOR  //for RCC and some other when simulator debug fail
#ifdef SIMULATOR
#define USE_FULL_ASSERT  //for params checking in simulation only
#endif

//INCLUDES replaced from Maradona.h
#include "stm32f10x.h"
#include "types.h" //macro and types

#include "debugTerm.h" //debug functions

#include "clock_.h" //clock functions
#include "interrupts.h" //interrupts

#include "time_.h" //delay and time functions
#include "ram_.h" // sysflags, memcopy, memalloc functions
#include "strings_.h" //string functions

#include "BLight.h" //backlight functions

#include "draw_.h"    //drawing functions
#include "TFT_.h" //tft functions
#include "touch_.h" //touchscreen
#include "backup.h" //backup registers
#include "ram_.h" //memory functions
#include "buzzer_.h"//buzzer functions
#include "gps_.h" //gps functions
#include "intMMC.h" //int card functions
#include "extMMC.h" //ext card functions
#include "FS.h"     //filesystem functions
#include "hub.h"  //event consuming
#include "loader_.h" //user program loader
#include "window.h" //window functions
#include "shell.h" //shell app functions
#include "Math_.h" //math module functions
//***************** Global variables ****************************


//**************** Private function prototypes ******************


int main(void)
{
	//USART1, portA and some other already configured in my bootloader
	//here it's skipped
	//1) configure clocks for access to backup registers
	//2) read clockmode from backup registers
	//3) set up clockmode
	//4) ...
	RAM_Init(); //init memAlloc functions

	//try to config...
	/*
	��������:
	1)������ ����- ������������� ���������� �� 8 ��� 12 ���, ����� �������� ������ � �����-���������
	���� HSEfail, ���������� ���� � sysFlags, ����� ����� ��� �� �������� ��� ���������.
	2)�������� ������ � �����-��������� � ������ ������ clockmode
	3)�������������� clockmode ���������� ������� ��� � ����� ����������.
	-��� ���������������� ������� ����� ������?
	-HSE OFF;HSI ON;PLL=OFF;SYSCLK=HSI;AHB=/1;APB1=/1;APB2=/1;
	=> SYSCLK=HSI=HCLK=PCLK1=PCLK2; ADCCLK=PCLK2/2;
	-�������� �� �����-�������� ����� ������ ��� ��������� ������?
	-may be... try!
	4)...

	*/
	//TODO: ���������� ��� ��� � ���������� RAM_ ������ � ������� � ����������� �������� ����� ������.
	//TODO: move all GPIO pin's to ANALOG_INPUT state before all initialization
	BACKUP_Init();
	extern u16 RAM_sysSave1; //external variable used here


	//check backup data integrity
	if(BACKUP_isValid() == 0)
	{
		//backup data unavailable, create new backup data here...
		//CAN REPLACE BY PREDEFINED VALUES IMMEDIATELY ON RAM_ VARIABLES
		RAM_storeSysClockMode(CLKMODE_48); //create sysflag complete values here
		RAM_storeSysBackLight(BACKLIGHT_LEVEL_4); //default backlight level 
		RAM_sysSetFlag(SYSFLAG_TOUCHCAL); //need calibration procedure
		//TODO: Add here...
	}
	else
	{
		//get clockmode and other backup'ed values
		//TODO: Add here...
		RAM_sysSave1 = BACKUP_Read(BACKUP_REG_1); //test 

	}
	u16 clkMode = RAM_getSysClockMode();
	//��� ����� ������� ��� clockmode �������� � ��������, ������� ����� ������.

	/* System Clocks Configuration */
	//simulator not work with clock verifying flags, thus we should use HSI internal clock for simulation
	CLOCK_Init(clkMode); //
    HUB_Init(); //init event processing and queue before any interrupt enable
    
	DBG_Init();//enabled dbg interrupt

	//DBG_printfn("CLK=", 4);
	//DBG_printval(clkMode);//0000000002 0050351747 0002630666
	//DBG_printval(RCC->CR); //0050351747 HSI ON; HSI RDY; PLL ON; PLL RDY;
	//DBG_printval(RCC->CFGR); //0000009226  PLL USEDASSYSCLK; HCLK=PLLCLK; PCLK1=HCLK/2; PCLK2=HCLK/2; ADCCLK=PCLK2/2; PLLSRC=HSI/2; PLLMUL=x2;

	BUZZER_Init(); 
    
    
	INTERRUPTS_Init(clkMode);//This function enable SysTick interrupts

	BUZZER_Beep(1000); //simple test of buzzer

	//backlight configuration, default level = 50%
	BACKLIGHT_Init(clkMode);

	TOUCH_Init(clkMode);

	//tft init fsmc
	//TFT_FsmcInit();
	//init display 
	//TFT_DisplayInit();
	TFT_Init();
    //window system init
    WND_Init();

	//MATH_Init();
	//DRAW_Init();
	//FS_Init();

	//init intMMC and put to idle mode
	INTMMC_Init();
	INTMMC_GoIdle();

	//USB_Init();
	//LOADER_Init();
	//END OF INIT, GO TESTS

	//fill screen with white color 
	GDATA_RECT scr;
	DRAW_GetDisplayRect(&scr);
	DRAW_FillRect(&scr, COLOR_White);
    
 //test shell app
	u32 res = SHELL_Init(); //init and go shell app loop
	DBG_printfn((u8*) "Shell:", 6);
	DBG_printval(res);
	
	
	
	
	
	
	//set horizontal orient for tests
    //DRAW_SetDisplayOrient(TFT_Landscape);
	//u16* testbuf;

	//TFT_SetScanOrder(1);//horizontal
	//testbuf = (u16*)memAlloc(50*50*2);
	/* Insert delay */
	//TFT_FillRect(100, 100, 50, 50, tftBLUE);
	//TFT_FillRect(150, 150, 50, 50, tftRED);
	//read bitmap from screen and write ot other place
	//TFT_ReadRect(125, 125, 50, 50, testbuf);
	//TFT_WriteRect(30, 30, 50, 50, testbuf);
	//set some pixels
	//TFT_SetPixel(10, 10, tftRED);
	//TFT_SetPixel(10, 15, tftGREEN);
	//TFT_SetPixel(10, 20, tftBLUE);
	//memFree((u8*)testbuf);
	//draw chars
	// DRAW_String("1234567890!@#$%^&*()_-+={}", 26, 5, 5, tftBLACK, tftSKY);
	




	//draw points for stilus
	// DRAW_drawLine(10, 10, 230, 10, COLOR_Red);
	// DRAW_drawLine(10, 110, 230, 110, COLOR_Red);
	// DRAW_drawLine(10, 210, 230, 210, COLOR_Red);
	// DRAW_drawLine(10, 310, 230, 310, COLOR_Red);

	// DRAW_drawLine(10, 10, 10, 310, tftBLUE);
	// DRAW_drawLine(65, 10, 65, 310, tftBLUE);
	// DRAW_drawLine(120, 10, 120, 310, tftBLUE);
	// DRAW_drawLine(175, 10, 175, 310, tftBLUE);
	// DRAW_drawLine(230, 10, 230, 310, tftBLUE);

	// extern s16          TOUCH_Temperature;         //current temperature
	// extern u16          TOUCH_VrefMv;              //Vref millivolts
	// extern u16          TOUCH_VbatMv;              //Vbat millivolts
	//for test only
	// extern s16 TOUCH_TestX;
	// extern s16 TOUCH_TestY;
	// extern TOUCH_EventType TOUCH_TestMode;

	//gps test
	//GPS_Init();
	//DBG_printfn("G0", 2);
	//GPS_Enable(ENABLE);
	//DBG_printfn("G1", 2);
	//TIME_delay_ms(6000); //gps must send msgs
	//DBG_printfn("G2", 2);
	//GPS_Enable(DISABLE);
	//BG_printfn("G3", 2);
	//GPS_Exit();
	//DBG_printfn("G4", 2);
	////another powerup
	//TIME_delay_ms(6000);    
	//GPS_Init();
	//DBG_printfn("G5", 2);
	//GPS_Enable(ENABLE);
	//DBG_printfn("G6", 2);
	//TIME_delay_ms(6000); //gps must send msgs
	//DBG_printfn("G7", 2);
	//GPS_Enable(DISABLE);
	//DBG_printfn("G8", 2);
	//GPS_Exit();
	//DBG_printfn("G9", 2);

	//u16 color, xx, yy;
	//ADC using
	//DBG_printfn("ADC\r\n", 5);
	//ADC_TRESULTS ar;

	//FS_Init(); //init filesystem - this dummy function
	//int card test
	//clear buffer
	//RAM_memFill(TestCardBuf, 0, 512);    

	//u32 res = 0;
	//FS_VOLINFO volume; //volume info struct
	//FS_DIRINFO dir;   //directory info struct
	//FS_DIRENT dentry; //entry info struct
	//FS_FILEINFO fi;  //open file info
	//
	//DRAW_BmpHeader bmph; //bitmap header
	//u8* workBuf = RAM_memAlloc(512, 0x33);
 //   u8* TestCardBuf = RAM_memAlloc(512, 0x33);
	//u32 tmp = 0;
	//u32 cccnt = 0;
 //   
 //   //print stack pointer
 //   DBG_printStackTop((u8*)"main1");
 //   
	//if(!workBuf)
	//{
	//	DBG_printfn((u8*)"Wbuff FAIL\r\n", 12);
	//}
	//else
	//{
	//	//MOUNT device and get partition start sector
	//	res = FS_Mount(extCARD, TestCardBuf);
	//	if(res == 0xFFFFFFFF)
	//	{
	//		DBG_printfn((u8*)"MOUNT FAIL\r\n", 12);
	//	}
	//	else  //TestCardBuf
	//	{
	//		//open first partition
	//		res = FS_GetVolInfo(extCARD, TestCardBuf, res, &volume);
	//		if(res != FS_OK)
	//		{
	//			DBG_printval(res);
	//			DBG_printfn((u8*)"Volum FAIL\r\n", 12);
	//		}
	//		else
	//		{
	//			//open root dir
	//			dir.scratch = TestCardBuf;
	//			res = FS_OpenDir(&volume, (u8*) "/", &dir); //"" or "/" for disk root, "/folder" for root\folder\ //
	//			if(res != FS_OK)
	//			{
	//				DBG_printval(res);
	//				DBG_printfn((u8*)"OpDir FAIL\r\n", 12);
	//			}
	//			else
	//			{
	//				DBG_printfn((u8*)"Enumerate:\r\n", 12);
	//				//enumerate items in root dir
	//				while(FS_GetNext(&volume, &dir, &dentry) != FS_EOF)
	//				{
	//					if(dentry.name[0] != 0)
	//					{
	//						DBG_printfn((u8*)dentry.name, 11);
	//						if(dentry.attr & FS_ATTR_DIRECTORY) 
	//							DBG_printfn((u8*)" D", 2);
	//						DBG_printfn((u8*)"\r\n", 2);
	//					}
	//				}

	//				//open file for reading picture
	//				res = FS_OpenFile(&volume, (u8*)"/SYS/MAPS/nomap.mbp", FS_READ, TestCardBuf, &fi);
	//				if(res != FS_OK)
	//				{
	//					DBG_printval(res);
	//					DBG_printfn((u8*)"OpenFile FAIL\r\n", 14);
	//				}
	//				else
	//				{
	//					res = FS_ReadFile(&fi, TestCardBuf, (u8*) &bmph, &tmp, sizeof(DRAW_BmpHeader)); 
	//					if(res != FS_OK)
	//					{
	//						DBG_printval(res);
	//						DBG_printfn((u8*)"ReadFile FAIL\r\n", 15);
	//					}
	//					else
	//					{
	//						//print bmp header of loaded file
	//						DBG_printfn((u8*)"BmpHead \r\n", 10);
	//						DBG_printval(bmph.FileType); DBG_printfn((u8*)"\r\n", 2);
	//						DBG_printval(bmph.PixelFormat); DBG_printfn((u8*)"\r\n", 2);
	//						DBG_printval(bmph.Width); DBG_printfn((u8*)"\r\n", 2);
	//						DBG_printval(bmph.Height); DBG_printfn((u8*)"\r\n", 2);
	//						DBG_printval(bmph.AlphaColor); DBG_printfn((u8*)"\r\n", 2);
	//						//read 240 rows for landscape orient
	//						for(cccnt = 0; cccnt < 240; cccnt++)
	//						{
	//							//read one workBuf 512 of file - it must be 1 full row of pixels
 //                               res = FS_ReadFile(&fi, TestCardBuf, workBuf, &tmp, 512); 
	//							if(res != FS_OK)
	//							{
	//								DBG_printval(res);
	//								DBG_printfn((u8*)"ReadFil2 FAIL\r\n", 15);
	//							}
	//							else
	//							{
	//								//workBuf contains 1 row of pixels
	//								//draw to display - draw one row - x=0,y=cnt,w=Widht,h=1
	//								TFT_WriteRect(0, cccnt, 256, 1, (u16*)workBuf);
	//							}
	//						}
	//						



	//					}
	//				}
	//			}

	//		}
	//	}


	//	//unmount card
	//	FS_Unmount(extCARD);
	//	DBG_printfn((u8*)"Unmounted:\r\n", 12);
	//	RAM_memFree(workBuf);
 //       RAM_memFree(TestCardBuf);
 //       
 //       //test execute program
	//	tmp = LOADER_Load2(extCARD, (u8*) "/UserApp.elf");
	//	if(tmp == LOADER_SUCCESS)
	//	{
	//		//enable hardware events
 //           HUB_EnableEventProcessing();
 //           //tmp = LOADER_Execute((u8*)"Host", 4);
	//		TIME_delay_ms(60000);
 //           HUB_DisableEventProcessing();
 //           HUB_DebugOutQueue();
 //           DBG_printfn((u8*)"Executed: \r\n", 12);
	//	}
	//	else
	//	{
	//		DBG_printfn((u8*)"LoadError: \r\n", 13);
	//	}
 //       DBG_printval(tmp);
		

		//DRAW_String((u8*)"1234567890!@#$%^&*()_-+={}:;<=>?@ABCDEFG", 40, 0, 0, tftBLACK, tftSKY);
		//DRAW_String((u8*)"HIJKLMNOPQRSTUUVWXYZ[\\]^_ abcdefghijklm", 40, 0, 20, tftRED, tftLGRAY);
		//DRAW_String((u8*)"nopqrstuvwxyz{|}~�����������������������", 40, 0, 40, tftRED, tftLGRAY);
		//DRAW_String((u8*)"����������������������������������������", 40, 0, 60, tftRED, tftLGRAY);
		//DRAW_String((u8*)"�", 1, 0, 80, tftRED, tftLGRAY);
	//}
	//new filesystem layer test
	FSS_Init();	
    DRAW_BmpHeader bmph; //bitmap header
	FS_DIRINFO dir;   //directory info struct
	FS_DIRENT dentry; //entry info struct
	FS_FILEINFO fi;  //open file info
	u8* workBuf = RAM_memAlloc(512, RAM_TAG_TEST);
	u32 tmp, t1;
	u32 cccnt;
	if(!workBuf)
	{
		DBG_printfn((u8*)"Wbuff FAIL\r\n", 12);
	}
	else
	{
		tmp = FSS_OpenDir((u8*)"E:/", &dir);
		if(tmp != FS_OK)
		{
			DBG_printval(tmp);
			DBG_printfn((u8*)"OpDir FAIL\r\n", 12);
		}
		else
		{
			DBG_printfn((u8*)"Enumerate:\r\n", 12);
			//enumerate items in root dir
			while(FSS_GetNext(&dir, &dentry) != FS_EOF)
			{
				if(dentry.name[0] != 0)
				{
					DBG_printfn((u8*)dentry.name, 11);
					if(dentry.attr & FS_ATTR_DIRECTORY) 
						DBG_printfn((u8*)" D", 2);
					DBG_printfn((u8*)"\r\n", 2);
				}
			}
			//close session
			FSS_CloseDir(&dir);
		}
		//open file and read picture
		tmp = FSS_OpenFile((u8*)"E:/SYS/MAPS/nomap.mbp", FS_READ, &fi);
		if(tmp != FS_OK)
		{
			DBG_printval(tmp);
			DBG_printfn((u8*)"OpenFile FAIL\r\n", 14);			
		}
		else
		{
			tmp = FSS_ReadFile(&fi, (u8*) &bmph, sizeof(DRAW_BmpHeader), &t1);
			if(tmp != FS_OK)
			{
				DBG_printval(res);
				DBG_printfn((u8*)"ReadFile FAIL\r\n", 15);
			}
			else
			{	
				//print bmp header of loaded file
				DBG_printfn((u8*)"BmpHead \r\n", 10);
				DBG_printHex(bmph.FileType); DBG_printfn((u8*)"\r\n", 2);
				DBG_printHex(bmph.PixelFormat); DBG_printfn((u8*)"\r\n", 2);
				DBG_printHex(bmph.Width); DBG_printfn((u8*)"\r\n", 2);
				DBG_printHex(bmph.Height); DBG_printfn((u8*)"\r\n", 2);
				DBG_printHex(bmph.AlphaColor); DBG_printfn((u8*)"\r\n", 2);

				//read 240 rows for landscape orient
				for(cccnt = 0; cccnt < 240; cccnt++)
				{
					//read one workBuf 512 of file - it must be 1 full row of pixels
                    tmp = FSS_ReadFile(&fi, workBuf, 512, &t1); 
					if(tmp != FS_OK)
					{
						DBG_printval(tmp);
						DBG_printfn((u8*)"ReadFil2 FAIL\r\n", 15);
					}
					else
					{
						//workBuf contains 1 row of pixels
						//draw to display - draw one row - x=0,y=cnt,w=Widht,h=1
						TFT_WriteRect(0, cccnt, 256, 1, (u16*)workBuf);
					}
				}
			}	
			//close file session
			FSS_CloseFile(&fi);
		}
	}
    
    //test partial drawing
    GDATA_RECT rc;
    GDATA_rectSetRect(&rc, 100, 100, 32, 32);
    DRAW_PictureFile((u8*)"E:/SYS/MAPS/nomap.mbp", (u16*)workBuf, &rc, 10, 260); 
    //free buffer
    RAM_memFree(workBuf);

	//print stack pointer
	DBG_printStackTop((u8*)"main2");
	DBG_printStackMin();
    
    //test doubles - delayed to final because of big code size
    //TestMathCoord();
    
    //in final firmware this loop replaced by shell application message loop
    while(1)
	{
		//touch painting test
		//if(TOUCH_TestMode == TouchEvent_Down) color = tftRED;
		//else if(TOUCH_TestMode == TouchEvent_Move) color = tftGREEN;
		//else if(TOUCH_TestMode == TouchEvent_Up) color = tftBLUE;
		//xx = TOUCH_TestX - 2; yy = TOUCH_TestY - 2;
		//DRAW_drawRect(xx, yy, 4, 4, color);        

		//TIME_delay_ms(10);
		//TOUCH_calcPoint3(&ar, &tpt);
		//TOUCH_TouchClear(&ar);   
		//TOUCH_oneConversion(&ar);
		//DBG_printfn("M=", 2);
		//DBG_printval(TOUCH_TestMode);
		//DBG_printfn(";X=", 3);
		//DBG_printval(TOUCH_TestX);
		//DBG_printfn(";Y=", 3);
		//DBG_printval(TOUCH_TestY);
		//}
		//DBG_printfn(";t=", 3);
		//DBG_printval(TOUCH_Temperature);
		//DBG_printfn(";R=", 3);
		//DBG_printval(TOUCH_VrefMv);
		//DBG_printfn(";B=", 3);
		//DBG_printval(TOUCH_VbatMv);        
		//DBG_printfn(";\r\n", 3);

	}
    
//deinit modules here




}









#ifdef SIMULATOR
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
	/* User can add his own implementation to report the file name and line number,
	ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	//printf("Wrong parameters value: file %s on line %d\r\n", file, line);
	/* Infinite loop */
	while (1)
	{
	}
}
#endif //SIMULATOR

