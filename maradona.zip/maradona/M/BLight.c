/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for  subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "BLight.h"
#include "clock_.h"

//FUNCTIONS
/******************************************************************************
BackLight timer configuration: PWM 50% at 100Hz 

*******************************************************************************/
void BACKLIGHT_Init(u16 clkMode)
{
   GPIO_InitTypeDef GPIO_InitStructure;
   TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
   TIM_OCInitTypeDef  TIM_OCInitStructure;

  /* TIM3 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

  //pin for backlight
  /*GPIOA Configuration: TIM3 channel 1 as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  //******** Timer3_1 PWM configuration ***********
  u32 tmp;
  //overall PWM = 1000Hz for reduce EMI. With 256 taps it be 256000Hz  
  if(clkMode == CLKMODE_72) tmp = 36000000/256000; //clk=36m=pclk1; tmp=36000000 / 256000= 
      else if(clkMode == CLKMODE_48) tmp = 24000000/256000; //clk=24m
      else if(clkMode == CLKMODE_24) tmp = 24000000/256000; //clk=24m
          else tmp = 12000000/256000; //clk=12mhz
    
  /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = 256;//PWM period 256 clocks
  TIM_TimeBaseStructure.TIM_Prescaler = tmp; //input timer clock 36mhz/1400 = 25600hz / 256 taps = 100Hz
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  /* PWM1 Mode configuration: Channel1 */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 128; //1000Hz with 50% PWM 
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

  TIM_OC1Init(TIM3, &TIM_OCInitStructure);

  TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);

  TIM_ARRPreloadConfig(TIM3, ENABLE);

  /* TIM3 enable counter */
  TIM_Cmd(TIM3, ENABLE);
}

void BACKLIGHT_Exit()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	//reset timer
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_TIM3, DISABLE);
	  /* TIM3 clock disable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, DISABLE);
	//disable pin
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}


//Set backlight level (1..255)
void  APIEXPORT BACKLIGHT_Set(u32 level)
{
    TIM_SetCompare1(TIM3, (u16)level); //new pwm value TIMx->CCR1 = Compare1;
	//volatile u16* addr = TIM3_CCR1;
    //*addr = (u16) level;
    return;
}

#define TIMER3_CCR1 (u16*) 0x40000434

//get current backlight level
u32  APIEXPORT BACKLIGHT_Get()
{
	volatile u16* addr = TIMER3_CCR1;
    u16 res = *addr;//return TIM3->CCR1 0x40000434
	return (u32)res;
}



