/***********************************************************

// Copyright (C) 2012-2013 Pavel Selyakov
// Source for MATH subsystem of Maradona project
// Nov 22, 2012: refactoring


***********************************************************/

//INCLUDES
#include "Math_.h"
#include "debugTerm.h"
//GLOBAL VARIABLES

//FUNCTIONS
//#include <fastmath.h>
//double wX, wY;
//const double pi = M_PI; //3.1415926535;
//double tX, tY;

//void WorldToTilePos(double lon, double lat, u32 zoom)
// {
	// tX = ((lon + 180.0) / 360.0) * (1 << zoom);
	// tY = ((1.0 - log(tan(lat * pi / 180.0) + 1.0 / cos(lat * pi /180.0)) / pi) / 2.0 * (1 << zoom));
	// return;
// }

// void TileToWorldPos(double tileX, double tileY, u32 zoom)
// {
	// double p = pow(2.0, zoom);
	// double n = pi - ((2.0 * pi * tileY) / p);

	// wX = ((tileX / p * 360.0) - 180.0);
	// wY = (180.0 / pi * atan(0.5 * (exp(n) - exp(-n))));
// }

// void printfp(double val)
// {
	// double v, t, d;
	// u32 i, ii;
	// if(val < 0.0)
    // {
        // DBG_putchar((u8) '-');
        // v = fabs(val);
    // }
    // else
        // v = val;
    
	// d = 1000000.0;
	// i = 14;
	// while(i)
	// {
		// t = v / d;
		// ii = (u32) t;
		// DBG_putchar((u8) (ii + '0'));
		// v = fmod(v, d);
		// d = d / 10;
		// if(d == 0.1)  DBG_putchar((u8) '.');
	// }
	// return;
// }

//NR-test coord calculation
// void TestMathCoord()
// {
    //convert world to tilepos
	// u32 i;
    // for(i = 1; i < 20; i++)
	// {
		// wX = 36.6;
		// wY = 36.6;
   		// DBG_printf((u8*)"Zoom="); DBG_printval(i);
		// DBG_printf((u8*)"\r\nWorld to tile:\r\n");
 		// WorldToTilePos(wX, wY, i);
		//printf("wX= %f \t\twY= %f\n", wX, wY);
        // printf("tX= %f \t\ttY= %f\n", tX, tY);   
		// DBG_printf((u8*) "wX=");
        // printfp(wX);
    	// DBG_printf((u8*) "\r\nwY=");    
		// printfp(wY);
    	// DBG_printf((u8*) "\r\n");         

		//convert tilepos to world
		// TileToWorldPos(tX, tY, i);
		// DBG_printf((u8*)"Tile to world:\r\n");
		//printf("tX= %f \t\ttY= %f\n", tX, tY);
		//printf("wX= %f \t\twY= %f\n", wX, wY);
    	// DBG_printf((u8*) "tX=");
        // printfp(tX);
    	// DBG_printf((u8*) "\r\ntY=");    
		// printfp(tY);
    	// DBG_printf((u8*) "\r\n"); 
	// }
    // return;
// }


/**
  * @brief  Returns the power of two for specified number
  * @param  num: number.
  */
u32  APIEXPORT MATH_power2(u32 num)
{
  u32 count = 0;

  while (num != 1)
  {
    num >>= 1;
    count++;
  }
  return count;
}








