//************************************************************
// Maradona.h  
// Copyright (C) 2011 Pavel Selyakov
// Main header for project
// July 30, 2011: initial

//************************************************************
#ifndef MARADONAH
#define MARADONAH

#ifdef __cplusplus
 extern "C" {
#endif
 
#include "stm32f10x.h"
#include "types.h" //macro and types

#include "debugTerm.h" //debug functions

#include "time_.h" //delay and time functions
#include "ram_.h" // sysflags, memcopy, memalloc functions
#include "strings.h" //string functions

#include "BLight.h" //backlight functions

#include "draw_.h"    //drawing functions
#include "TFT.h" //tft functions
//TODO: insert more subsystems here...

#ifdef __cplusplus
 }
#endif

#endif // MARADONAH
