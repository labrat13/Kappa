//main code file for user app
#include "API.h"

//defines
u32 wndProc(PWND, u32, u16, u16);
const u32 hInstance = 1;
void onInit(PWND);
void onPaint(PWND);

u32 __attribute__ ((used)) main(u8* args, u32 argn) 
{
	DBG_printfn((u8*)"U1", 2);
    //1 - register window class
	u32 classId = WND_RegisterClass(
		hInstance,	//app instance = 1
		wndProc,	//wnd proc address
		0);			//class styles - no styles defined
    DBG_printfn((u8*)"U2", 2);
	//2 - create window
    PWND pWnd;
	u32 wndStyle = 0; //window styles
    PWND pParent = 0; //parent window is shell window?
	u32  pMenu = 0;		//window menu?
	pWnd = WND_CreateWindow(
		classId,	//class identifier
		wndStyle,	//window styles
		0,			//X
		0,			//Y
		100,		//Width of window
		100,		//Height of window
		pParent,	//Parent wnd
		pMenu,		//Menu of window ?
		hInstance); //app instance = 1
	if(pWnd == 0) return 0;
	DBG_printfn((u8*)"U3", 2);
	//3 - init app resources
	onInit(pWnd);

	//4 - show window
	WND_ShowWindow(pWnd, 1); //set or clear window show state flag
	DBG_printfn((u8*)"U4", 2);
    WND_UpdateWindow(pWnd);//send PAINT and NCPAINT message directly to window procedure
    DBG_printfn((u8*)"U5", 2);
	//5 - message loop
	HUB_MSG Msg;
	
    while(1);
        
    while(HUB_GetMessage(&Msg, pWnd, MSG_MIN, MSG_MAX))
	{
		DBG_printfn((u8*)"U9", 2);
        //add some msg translators here
		HUB_DispatchMessage(&Msg);
	}

	//release application resources here?

	//return valX value as result
	return (u32) Msg.ValueX;

}

void onInit(PWND pWnd)
{
	//add application init code here
}

void onPaint(PWND pWnd)
{
	GDATA_RECT rc;
    DBG_printfn((u8*)"U6", 2);
	RAM_memZero(&rc, sizeof(GDATA_RECT));
    WND_GetClientRect(pWnd, &rc);  //window client rectangle for drawing
	//TODO: add application drawing code here
    DRAW_FillRect(&rc, COLOR_WhiteSmoke);
}

void onNcPaint(PWND pWnd)
{
	//GDATA_RECT rc;
	//WND_GetWindowRect(pWnd, &rc);  //window client rectangle for drawing
	//TODO: add application drawing code here

}

u32 wndProc(PWND pWnd, u32 msgCode, u16 Xval, u16 Yval)
{
	DBG_printfn((u8*)"U7", 2);
    switch(msgCode)
	{
	case MSG_COMMAND: //menu processing
		break;
	case MSG_PAINT:
		onPaint(pWnd); //����������
		break;
	case MSG_NCPAINT:
		onNcPaint(pWnd);
		break;
	case MSG_TOUCHSCREEN_SCREEN_DOWN:
		//��������� ��������� �������
		break;
	case MSG_TOUCHSCREEN_SCREEN_MOVE:
		//��������� ��������� � ������������ �������
		break;
	case MSG_TOUCHSCREEN_SCREEN_UP:
		//��������� ��������� �������
        HUB_PostMessage(pWnd, MSG_CLOSE, 0, 0);
		break;
	case MSG_CLOSE:
		//prompt to confirm closing window
		WND_DestroyWindow(pWnd);
		break;
	case MSG_DESTROY:
		//PostQuitMessage(0); //0=app result code
		HUB_PostMessage(pWnd, MSG_QUIT, 0, 0);
		break;
	default:
		return 0; //DefWindowProc(pWnd, msgCode, Xval, Yval);
	}
	return 0;
}
