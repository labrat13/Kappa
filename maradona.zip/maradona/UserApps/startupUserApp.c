//this file for init/deinit and call user application
//this file must be excluded from link.
//use startupUserApp.o object file for linking as startup file
#include "API.h" //header from main system

extern u32 main(u8* str, u32 len);
static u32 ApplicationStart(u8* str, u32 len);
extern unsigned long _etext;     //end of text section
extern unsigned long _sidata;    /* start address for the initialization values of the .data section. defined in linker script */
extern unsigned long _sdata;     /* start address for the .data section. defined in linker script */
extern unsigned long _edata;     /* end address for the .data section. defined in linker script */
extern unsigned long _sbss;      /* start address for the .bss section. defined in linker script */
extern unsigned long _ebss;      /* end address for the .bss section. defined in linker script */
extern void _estack;             // init value for the stack pointer. defined in linker script. Not used. 

extern tAPI_Func M_API[]; //extern array of pointers
tAPI_Func(*ptrM_API)[]; //declare pointer to API array


//array of pointers to function
__attribute__ ((section(".isr_vector")))
void (* const g_pfnVectors[])(void) =
{ 
    ApplicationStart   
};

//entry point od ELF file
static u32 ApplicationStart(u8* str, u32 len)
{
    //do some inits
    //unsigned long* pulSrc;
    unsigned long* pulDest;

    // Zero fill the bss segment
    //for( pulDest = &_sbss; pulDest < &_ebss; )
    //    {
    //    *(pulDest++) = 0;
    //    }
    //set api array address for system interrupt table at 0x20000000
    ptrM_API =  *((tAPI_Func (**) []) (0x20000000 + (77 * 4)));
    
    return   main(str, len);
    
}

